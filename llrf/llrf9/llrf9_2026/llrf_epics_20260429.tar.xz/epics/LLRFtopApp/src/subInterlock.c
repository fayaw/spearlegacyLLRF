/*
 Interlock summary generator, reset master
 
 Copyright (c) 2012-2015 Dimtel, Inc., All Rights Reserved

 $Id: subInterlock.c,v 1.5 2022/11/12 21:38:43 dim Exp $
 $Date: 2022/11/12 21:38:43 $
 $Author: dim $
 $Revision: 1.5 $
 $Log: subInterlock.c,v $
 Revision 1.5  2022/11/12 21:38:43  dim
 Added variable CIC_DECIM factor

 Revision 1.4  2020/07/17 17:36:45  dim
 Interlock summary cleanup

 Revision 1.3  2019/11/13 03:50:58  dim
 Fixed maximum output number bug

 Revision 1.2  2019/08/24 18:32:24  dim
 Fixed slow ADC labels

 Revision 1.1  2017/03/10 19:44:58  dim
 Initial import

*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <dbAccess.h>

#include "map.h"

#define BOARDS		3
#define IL_CHANS	13
#define IL_INPUTS	3
#define IL_REF		3
#define IL_GLOBAL	4
#define IL_SADC		8
#define IL_TOTAL	(BOARDS*IL_CHANS)
#define IL_MAX		19 /* 9 input channels + 2 external + 8 slow ADC */
#define IL_OUTS		10 /* aSub outputs in summary */
#define ASUB_OUTPUTS	21

static long subInterlockSummary(aSubRecord *pasub)
{
  /*
   * Input:   A = Board 1 trip mask (13 bits)
   *          B = Board 2 trip mask (13 bits)
   *          C = Board 3 trip mask (13 bits)
   *          D = Board 1 timestamps (13 values)
   *          E = Board 2 timestamps (13 values)
   *          F = Board 3 timestamps (13 values)
   *          G = Board 1 CIC decimation
   *          J = Board 1 channel 0 label
   *          K = Board 2 channel 0 label
   *          L = Board 3 channel 0 label
   *          M = Board 1 channel 1 label
   *          N = Board 2 channel 1 label
   *          O = Board 3 channel 1 label
   *          P = Board 1 channel 2 label
   *          Q = Board 2 channel 2 label
   *          R = Board 3 channel 2 label
   *          S = Board 1 fsamp
   *          T = Slow ADC labels
   *           
   * Outputs: A = trip 1 label
   *          B = trip 1 time (us)
   *          C = trip 2 label
   *          D = trip 2 time (us)
   *          E = trip 3 label
   *          F = trip 3 time (us)
   *          G = trip 4 label
   *          H = trip 4 time (us)
   *          I = trip 5 label
   *          J = trip 5 time (us)
   *          K = trip 6 label
   *          L = trip 6 time (us)
   *          M = trip 7 label
   *          N = trip 7 time (us)
   *          O = trip 8 label
   *          P = trip 8 time (us)
   *          Q = trip 9 label
   *          R = trip 9 time (us)
   *          S = trip 10 label
   *          T = trip 10 time (us)
   *          U = OR of all interlock inputs
   *        
   */
  void **ll = &(pasub->j);
  char mask[IL_TOTAL], *labels[IL_TOTAL];
  uint32_t ts[IL_TOTAL], ts_min, ts_max, *output_or = (uint32_t *)pasub->valu;
  int32_t cic_decim = *(int32_t *)pasub->g;
  int chan, k, m, n, trip_ch[IL_MAX], ch_min;
  int summary[IL_MAX];
  double T0 = 2.0 / *(double *)pasub->s;
  char *sadc_labels[IL_SADC];

  /* Assign label pointers */
  sadc_labels[0] = (char *)pasub->t;
  for (k = 1; k < IL_SADC; k++)
    sadc_labels[k] = sadc_labels[k-1] + strlen(sadc_labels[k-1]) + 1;

  /* Collect all trip bits, labels, and timestamps */
  for (chan = 0; chan < IL_CHANS; chan++)
  {
    mask[chan]              = ((*(uint32_t *)pasub->a) >> chan) & 1;
    mask[IL_CHANS + chan]   = ((*(uint32_t *)pasub->b) >> chan) & 1;
    mask[2*IL_CHANS + chan] = ((*(uint32_t *)pasub->c) >> chan) & 1;
    ts[chan]                = *((uint32_t *)pasub->d + chan);
    ts[IL_CHANS + chan]     = *((uint32_t *)pasub->e + chan);
    ts[2*IL_CHANS + chan]   = *((uint32_t *)pasub->f + chan);
    if (chan < IL_INPUTS)
    {
      labels[chan]              = (char *)(*ll++);
      labels[IL_CHANS + chan]   = (char *)(*ll++);
      labels[2*IL_CHANS + chan] = (char *)(*ll++);
    }
    else if (chan == IL_REF) /* Reference channel */
    {
      labels[chan]              = "RF REFERENCE 1";
      labels[IL_CHANS + chan]   = "RF REFERENCE 2";
      labels[2*IL_CHANS + chan] = "RF REFERENCE 3";
    }
    else if (chan == IL_GLOBAL) /* External interlock */
    {
      labels[chan]              = "GLOBAL 1";
      labels[IL_CHANS + chan]   = "GLOBAL 2";
      labels[2*IL_CHANS + chan] = "GLOBAL 3";
    }
    else /* Slow ADC interlock */
    {
      labels[chan]              = sadc_labels[chan - IL_GLOBAL - 1];
      labels[IL_CHANS + chan]   = sadc_labels[chan - IL_GLOBAL - 1];
      labels[2*IL_CHANS + chan] = sadc_labels[chan - IL_GLOBAL - 1];
    }
  }

  /* Unwrap the timestamps. Assume all events are less than 
     Tmax/2 apart (0.808 s) */
  for (chan = 0, ts_min = UINT32_MAX, ts_max = 0; chan < IL_TOTAL; chan++)
  {
    if (mask[chan])
    {
      if (ts[chan] < ts_min)
        ts_min = ts[chan];
      if (ts[chan] > ts_max)
        ts_max = ts[chan];
    }
  }
  if (ts_max-ts_min > (cic_decim*(ILOCKTS_V_COARSE+1)/2))
  {
    for (chan = 0; chan < IL_TOTAL; chan++)
      if (ts[chan] < (cic_decim*(ILOCKTS_V_COARSE+1)/2))
        ts[chan] += cic_decim*(ILOCKTS_V_COARSE+1);
  }

  /* Special handling for global (board external) interlocks */
  if (mask[IL_GLOBAL] & mask[IL_CHANS+IL_GLOBAL] & mask[2*IL_CHANS+IL_GLOBAL])
  {
    mask[IL_CHANS+IL_GLOBAL] = mask[2*IL_CHANS+IL_GLOBAL] = 0;
    labels[IL_GLOBAL] = "GLOBAL";
  }
  
  /* Now process interlock information */
  *output_or = 0;
  for (chan = 0, k = 0; chan < IL_TOTAL; chan ++)
  {
    if (mask[chan]) /* Trip asserted */
    {
      *output_or = 1;
      trip_ch[k++] = chan;
    }
  }

  n = 0;
  while (1)
  {
    for (m = 0, ts_min = UINT32_MAX; m < k; m++)
      if (mask[trip_ch[m]]) /* Not handled yet */
      {
        if (trip_ch[m] % IL_CHANS == IL_GLOBAL && n) /* Global and not first */
          mask[trip_ch[m]] = 0;
        else if (ts[trip_ch[m]] < ts_min)
        {
          ts_min = ts[trip_ch[m]];
          ch_min = trip_ch[m];
        }
      }
    
    /* Found minimum timestamp */
    if (ts_min < UINT32_MAX)
    {
      summary[n++]   = ch_min;
      mask[ch_min] = 0; /* Reset after processing */
    }
    else
      break;
  }

  /* Only use summary index if it is initialized */
  if (n)
    ts_min = ts[summary[0]];

  n = (n > IL_OUTS) ? IL_OUTS : n;
  for (m = 0, ll = &(pasub->vala); m < n; m++)
  {
    strcpy((char *)(*ll++), labels[summary[m]]);
    /* Add a tiny delta to the value, so that exact zero does
       not happen - EDM display blanks on 0 */
    *(double *)(*ll++) = (ts[summary[m]] - ts_min)*T0 + 1e-8;
  }
  
  /* Clear inactive entries */
  for (; m < IL_OUTS; m++)
  {
    *(char *)(*ll++) = 0;
    *(double *)(*ll++) = 0.0;
  }

  return 0;
}

static long subInterlockReset(aSubRecord *pasub)
{
  /*
   * Input:   A = Reset input
   *           
   * Outputs: A-U = Fanout
   *        
   */
  void **ll = &(pasub->vala);
  int k;
  
  for (k = 0; k < ASUB_OUTPUTS; k++)
    *(char *)(*ll++) = *(char *)pasub->a;

  return 0;
}

static long subInterlockSlowADCLabels(aSubRecord *pasub)
{
  /*
   * Input:   A = PCH0 DESC
   *          B = PCH1 DESC
   *          C = PCH2 DESC
   *          D = PCH3 DESC
   *          E = PCH4 DESC
   *          F = PCH5 DESC
   *          G = PCH6 DESC
   *          H = PCH7 DESC
   *           
   * Outputs: A = All labels in one buffer
   *        
   */
  char *pout = (char *)pasub->vala;
  int len;

  len = strlen((char *)pasub->a)+1;
  memcpy(pout, (char *)pasub->a, len);
  pout += len;
  len = strlen((char *)pasub->b)+1;
  memcpy(pout, (char *)pasub->b, len);
  pout += len;
  len = strlen((char *)pasub->c)+1;
  memcpy(pout, (char *)pasub->c, len);
  pout += len;
  len = strlen((char *)pasub->d)+1;
  memcpy(pout, (char *)pasub->d, len);
  pout += len;
  len = strlen((char *)pasub->e)+1;
  memcpy(pout, (char *)pasub->e, len);
  pout += len;
  len = strlen((char *)pasub->f)+1;
  memcpy(pout, (char *)pasub->f, len);
  pout += len;
  len = strlen((char *)pasub->g)+1;
  memcpy(pout, (char *)pasub->g, len);
  pout += len;
  len = strlen((char *)pasub->h)+1;
  memcpy(pout, (char *)pasub->h, len);
  pout += len;

  return 0;
}

static registryFunctionRef subInterlockRef[] = {
  {"subInterlockSummary", (REGISTRYFUNCTION)subInterlockSummary},
  {"subInterlockSlowADCLabels", (REGISTRYFUNCTION)subInterlockSlowADCLabels},
  {"subInterlockReset", (REGISTRYFUNCTION)subInterlockReset}
};

static void subInterlockRegistrar(void)
{
  registryFunctionRefAdd(subInterlockRef, NELEMENTS(subInterlockRef));
}
epicsExportRegistrar(subInterlockRegistrar);
