/*
 Subroutines for frequency tracking loop, incomplete...
 
 Copyright (c) 2015 Dimtel, Inc., All Rights Reserved

 $Id: subFtrk.c,v 1.1 2017/03/10 19:44:58 dim Exp $
 $Date: 2017/03/10 19:44:58 $
 $Author: dim $
 $Revision: 1.1 $
 $Log: subFtrk.c,v $
 Revision 1.1  2017/03/10 19:44:58  dim
 Initial import

*/

#include   <stdlib.h>
#include   <unistd.h>
#include   <stdio.h>
#include   <string.h>

#include   <dbDefs.h>
#include   <registryFunction.h>
#include   <aSubRecord.h>
#include   <epicsExport.h>
#include   <dbAccess.h>

#include   <pthread.h>
#include   <termios.h>
#include   <sys/time.h>
#include   "hwmon.h"
#include   "LLRFhw.h"

static long subFtrkLoop(aSubRecord *pasub)
{
  /*
   * Input:   A = Detuning (kHz)
   *          B = Direct phase (deg)
   *          C = Direct loop delay (ns)
   *          D = Loop mode, 1 = closed
   *           
   * Outputs: A = Closed-loop phase
   *          B = Calculated loop phase offset
   */

  double detuning = *(double *)pasub->a;
  double phase    = *(double *)pasub->b;
  double delay    = *(double *)pasub->c;
  char mode       = *(char *)pasub->d;
  double *offset  = (double *)pasub->valb;

  if (mode == 0)
    *offset = 0.0;
  else
    *offset = detuning * delay * 1.0e6 * 360.0;

  *(double *)pasub->vala  = phase + *offset;

  return 0;
}


static registryFunctionRef subFtrkRef[] = {
  {"subFtrkLoop", (REGISTRYFUNCTION)subFtrkLoop}
};

static void subFtrkRegistrar(void)
{
  registryFunctionRefAdd(subFtrkRef, NELEMENTS(subFtrkRef));
}

epicsExportRegistrar(subFtrkRegistrar);
