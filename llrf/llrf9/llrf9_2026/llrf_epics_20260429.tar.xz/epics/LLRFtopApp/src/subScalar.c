/*
 Channel synchronization, vector sum calculation subroutines
 
 Copyright (c) 2012-2015 Dimtel, Inc., All Rights Reserved

 $Id: subScalar.c,v 1.4 2025/11/07 18:21:17 dim Exp $
 $Date: 2025/11/07 18:21:17 $
 $Author: dim $
 $Revision: 1.4 $
 $Log: subScalar.c,v $
 Revision 1.4  2025/11/07 18:21:17  dim
 Converted to asynchronous processing

 Revision 1.3  2022/11/12 21:38:23  dim
 Added variable CIC_DECIM factor, fixed f_if/f_s bug

 Revision 1.2  2021/11/04 06:56:03  dim
 Vector sum calculation extended

 Revision 1.1  2017/03/10 19:44:58  dim
 Initial import

*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <stdint.h>

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <epicsThread.h>
#include <dbAccess.h>
#include <recSup.h>
#include "subScalar.h"
#include "cmath.h"
#include "map.h"
#include "LLRFhw.h"

static long subVectorSum(aSubRecord *pasub)
{
  /*
   * Input:   A = Amplitude 1
   *          B = Phase 1 (deg)
   *          C = Amplitude 2
   *          D = Phase 2 (deg)
   *          E = Amplitude 3
   *          F = Phase 3 (deg)
   *          G = Amplitude 4
   *          H = Phase 4 (deg)
   *          I = Cavity count
   *           
   * Outputs: A = Sum amplitude
   *          B = Sum phase (deg)
   */
  int k;
  double a[4], p[4];

  int32_t count = *(int32_t *)pasub->i;
  
  a[0] = *(double *)pasub->a;
  a[1] = *(double *)pasub->c;
  p[0] = *(double *)pasub->b;
  p[1] = *(double *)pasub->d;

  if (count >= 3)
  {
    a[2] = *(double *)pasub->e;
    p[2] = *(double *)pasub->f;
    if (count == 4)
    {
      a[3] = *(double *)pasub->g;
      p[3] = *(double *)pasub->h;
    }
  }
      
  double complex sum;
  
  for (k = 0, sum = 0.0; k < count; k++)
    sum += a[k]*cexp_loc(I*M_PI*p[k]/180.0);

  *(double *)pasub->vala = cabs(sum);
  *(double *)pasub->valb = carg(sum)/M_PI*180.0;

  return 0;
}

static double compute_IQ_scale(double fs, double fif)
{
  double theta = M_PI * fif / fs / 500.0;
  double scale = 1.0 / sin(theta);

#if 0  
  scale /= sqrt(2.0 - 2.0 * cos(theta)) / 2.0;
#endif
  
  return scale;
}

#if 1
static void *subScalarSync_async(void *arg)
{
  /*
   * Input:   A = I/Q/TS block, BRD1
   *          B = BRD1 F_s
   *          C = BRD1 F_if
   *          D = I/Q/TS block, BRD2
   *          E = BRD2 F_s
   *          F = BRD2 F_if
   *          G = I/Q/TS block, BRD3
   *          H = BRD3 F_s
   *          I = BRD3 F_if
   *          J = BRD1 CIC decimation
   *           
   * Outputs: A = Converted BRD1 I (x5 double)
   *          B = Converted BRD1 Q (x5 double)
   *          C = Converted BRD2 I (x5 double)
   *          D = Converted BRD2 Q (x5 double)
   *          E = Converted BRD3 I (x5 double)
   *          F = Converted BRD3 Q (x5 double)
   *          G = Converted combined block (B1CH0I, B1CH0Q, B1CH1I, ..., B3CH4Q)
   *          H = last_ts
   *          I = Sequence error flag
  */

  sync_state state = SYNC_IDLE;
  async_comm *async = (async_comm *)arg;
  aSubRecord *pasub = (aSubRecord *)async->pasub;

  int32_t *last_ts = (int32_t *) pasub->valh;
  int32_t *seq_error = (int32_t *) pasub->vali;
  int k, m, ch, cp[BRD_COUNT], delta, ts[BRD_COUNT];
  int cp_old[BRD_COUNT], ts_old[BRD_COUNT];
  long len;

  i_q_ts buf, block[BRD_COUNT][SCALAR_N];
  int ts_min, ts_max;
  setptr ptr[BRD_COUNT];
  double *pfs[BRD_COUNT], *pfif[BRD_COUNT], *pI[BRD_COUNT], *pQ[BRD_COUNT];
  all_i_q_ts *pG = (all_i_q_ts *)pasub->valg;
  int32_t cic_decim;
  void **pin, **pval, *pinp;
  DBLINK *in_link[BRD_COUNT];
  
  double fs[BRD_COUNT], fif[BRD_COUNT], iq_scale[BRD_COUNT];

  pin = &pasub->b; pval = &pasub->vala; pinp = &pasub->inpa;
  *last_ts = -1;
  for (k = 0; k < BRD_COUNT; k++)
  {
    ptr[k].p   = 0;
    in_link[k] = (DBLINK *)pinp; pinp += 3*sizeof(DBLINK);
    pfs[k]     = (double *)*pin++;
    pfif[k]    = (double *)*pin++; pin++;
    pI[k]      = (double *)*pval++;
    pQ[k]      = (double *)*pval++;
    for (m = 0; m < SCALAR_N; m++)
      block[k][m].ts = -1;
  }
  
  /* Perform initial setup here */
  for (k = 0; k < BRD_COUNT; k++)
  {
    fs[k] = *pfs[k]; fif[k] = *pfif[k];
    iq_scale[k] = compute_IQ_scale(fs[k], fif[k]);
  }
    
  /* Synchronization state machine */
  while (1)
  {
    switch (state)
    {
      case SYNC_IDLE:
        pthread_mutex_lock(&async->mutex);
        if (async->trigger != ASYNC_TRIGGER)
          pthread_cond_wait(&async->cond, &async->mutex);
        state = SYNC_CAPTURE;
      case SYNC_CAPTURE:
        cic_decim = *(int32_t *)pasub->j;
        for (k = 0; k < BRD_COUNT; k++)
        {
          len = sizeof(i_q_ts);
          dbGetLinkValue(in_link[k], DBR_LONG, &buf, NULL, &len);
          if ((delta = buf.ts - block[k][ptr[k].p].ts) != 0 || (*last_ts == -1))
          {
            if (delta < 0) delta += TS_WRAP;
            if (delta != 1 && (*last_ts != -1))
            {
              printf("Board %d timestamp sequence error, %d->%d\n",
                     k, block[k][ptr[k].p].ts, buf.ts);
              fflush(stdout);
            }
            /* New I/Q block received */
/*            printf("Link %p len %ld board %d ts %d I0=%d Q0=%d\n", in_link[k], len, k, buf.ts, buf.iq[0]._I, buf.iq[0]._Q); */
            memcpy(&block[k][++ptr[k].p], &buf, sizeof(i_q_ts));
          }
        }
        /* Now find synchronous blocks */
        for (k = 0, ts_min = TS_WRAP, ts_max = -1; k < BRD_COUNT; k++)
        {
          ts_old[k] = ts[k];
          cp_old[k] = cp[k];
          ts[k] = block[k][ptr[k].p].ts;
          if (ts[k] > ts_max)
            ts_max = ts[k];
          if (ts[k] < ts_min)
            ts_min = ts[k];
        }

        /* Swap on wraparound */
        if (ts_min == 0 && ts_max == 15)
        {
          ts_min = 15;
          ts_max = 0;
        }

        if (ts_min != *last_ts) /* New timestamp found */
        {
          for (k = 0; k < 3; k++)
            if (ts[k] == ts_min) /* Current timestamp */
              cp[k] = ptr[k].p;
            else
            {
              for (m = 0, cp[k] = -1; m < SCALAR_N; m++)
                if (block[k][m].ts == ts_min)
                {
                  cp[k] = m;
                  break;
                }
            }
          if ((cp[0] != -1) && (cp[1] != -1) && (cp[2] != -1))
            /* New data found, copy and convert */
            state = SYNC_COPY;
        }
        if (state == SYNC_CAPTURE)
        {
          usleep(T_WAIT);
          break;
        }
        
      case SYNC_COPY:
        for (k = 0, m = 0; k < BRD_COUNT; k++)
        {
          /* Check for changes in F_s or F_if */
          if ((fs[k] != *pfs[k]) || (fif[k] != *pfif[k]))
          {
            fs[k] = *pfs[k]; fif[k] = *pfif[k];
            iq_scale[k] = compute_IQ_scale(fs[k], fif[k]);
          }
          for (ch = 0; ch < 5; ch++)
          {
            pI[k][ch]      = (double)block[k][cp[k]].iq[ch]._I * 
                                (iq_scale[k]/cic_decim*32);
            pQ[k][ch]      = (double)block[k][cp[k]].iq[ch]._Q *
                                (iq_scale[k]/cic_decim*32);
            pG->iq[m]._I   = pI[k][ch]; 
            pG->iq[m++]._Q = pQ[k][ch];
          }
        }
        pG->ts = (double)ts_min;
        if (*last_ts != -1)
        {
          delta = ts_min - *last_ts;
          if (delta < 0) delta += 16;
          if (delta != 1)
            *seq_error = 1;
          else
            *seq_error = 0;
        }
        else
          *seq_error = 0;
          
        *last_ts = ts_min;
        state = SYNC_PROCESS;
      case SYNC_PROCESS:
        async->rc      = 0;
        async->trigger = ASYNC_DONE;
        pthread_mutex_unlock(&async->mutex);

        /* Call process() to finish record processing */
        struct dbCommon *precord = (struct dbCommon *)pasub;
        struct rset *prset=(struct rset *)(precord->rset);
        dbScanLock(precord);
        (*prset->process)(precord);
        dbScanUnlock(precord);
        state = SYNC_IDLE;
        break;
      }
    }
  /* Never reached */
  return NULL;
}

static long subScalarSync(aSubRecord *pasub)
{
  static int first = 1;
  int rc = 0;
  static async_comm async;
  static pthread_t async_thread;

  if (isfinite(*(double *)pasub->b) && isfinite(*(double *)pasub->c) &&
      isfinite(*(double *)pasub->e) && isfinite(*(double *)pasub->f) &&
      isfinite(*(double *)pasub->h) && isfinite(*(double *)pasub->i))
  {
    /* Good to go */
  }
  else
    return 1;
  
  if (first)
  {
    pthread_mutex_init(&async.mutex, NULL);
    pthread_cond_init(&async.cond, NULL);
    async.pasub = pasub;
    async.trigger = ASYNC_IDLE;
    pthread_create(&async_thread, NULL, subScalarSync_async, (void *)&async);
    first = 0;
  }
  
  pthread_mutex_lock(&async.mutex);
  if (async.trigger == ASYNC_DONE)
  {
    /* Completion processing call from _async */
    async.trigger = ASYNC_IDLE;
    pasub->pact   = 0;
    rc            = async.rc;
  }
  else if (async.trigger == ASYNC_IDLE)
  {
    /* Initial processing call, let _async know */
    pasub->pact   = 1;
    async.trigger = ASYNC_TRIGGER;
    pthread_cond_signal(&async.cond); /* Send a signal to the async thread */
  }
  else
  {
    fprintf(stderr, "Unexpected trigger state ASYNC_TRIGGER in subScalarSync()\n");
    rc = 1;
  }
  pthread_mutex_unlock(&async.mutex);

  return rc;
}

#else

static long subScalarSync(aSubRecord *pasub)
{
  /*
   * Input:   A = I/Q/TS block, BRD1
   *          B = BRD1 F_s
   *          C = BRD1 F_if
   *          D = I/Q/TS block, BRD2
   *          E = BRD2 F_s
   *          F = BRD2 F_if
   *          G = I/Q/TS block, BRD3
   *          H = BRD3 F_s
   *          I = BRD3 F_if
   *          J = BRD1 CIC decimation
   *           
   * Outputs: A = Converted BRD1 I (x5 double)
   *          B = Converted BRD1 Q (x5 double)
   *          C = Converted BRD2 I (x5 double)
   *          D = Converted BRD2 Q (x5 double)
   *          E = Converted BRD3 I (x5 double)
   *          F = Converted BRD3 Q (x5 double)
   *          G = Converted combined block (B1CH0I, B1CH0Q, B1CH1I, ..., B3CH4Q)
   *          H = last_ts
   *          I = Sequence error flag
  */

  int32_t *last_ts   = (int32_t *) pasub->valh;
  int32_t *seq_error = (int32_t *) pasub->vali;
  int k, m, ch, delta, cp[BRD_COUNT];
  int ts[BRD_COUNT], ts_min, ts_max;
  i_q_ts *pblk[BRD_COUNT];
  double *pfs[BRD_COUNT], *pfif[BRD_COUNT], *pI[BRD_COUNT], *pQ[BRD_COUNT], *pG;
  int32_t cic_decim = *(int32_t *)pasub->j;
  
  static int first = 1;
  static i_q_ts brd_block[BRD_COUNT][SCALAR_N];
  static setptr ptr[BRD_COUNT];
  static double fs[BRD_COUNT], fif[BRD_COUNT], iq_scale[BRD_COUNT];

  pblk[0] = (i_q_ts *)pasub->a;
  pfs[0]  = (double *)pasub->b;
  pfif[0] = (double *)pasub->c;
  pblk[1] = (i_q_ts *)pasub->d;
  pfs[1]  = (double *)pasub->e;
  pfif[1] = (double *)pasub->f;
  pblk[2] = (i_q_ts *)pasub->g;
  pfs[2]  = (double *)pasub->h;
  pfif[2] = (double *)pasub->i;
  
  pI[0]   = (double *)pasub->vala;
  pQ[0]   = (double *)pasub->valb;
  pI[1]   = (double *)pasub->valc;
  pQ[1]   = (double *)pasub->vald;
  pI[2]   = (double *)pasub->vale;
  pQ[2]   = (double *)pasub->valf;
  pG      = (double *)pasub->valg;

  if (first)
  {
    *last_ts = -1;
    for (k = 0; k < BRD_COUNT; k++)
    {
      memcpy(brd_block[k], pblk[k], sizeof(i_q_ts));
      ptr[k].p = 0;
      for (m = 1; m < SCALAR_N; m++)
        brd_block[k][m].ts = *last_ts; /* Mark invalid */
      fs[k]  = *pfs[k];
      fif[k] = *pfif[k];
      iq_scale[k] = compute_IQ_scale(fs[k], fif[k]);
    }
    first = 0;
  }
  else
  {
    for (k = 0; k < BRD_COUNT; k++)
    {
      /* Check for changes in F_s or F_if */
      if ((fs[k] != *pfs[k]) || (fif[k] != *pfif[k]))
      {
        fs[k]       = *pfs[k];
        fif[k]      = *pfif[k];
        iq_scale[k] = compute_IQ_scale(fs[k], fif[k]);
      }
    
      /* Compare the timestamps, save new data */
      if ((delta = pblk[k]->ts - brd_block[k][ptr[k].p].ts) != 0)
      {
        if (delta < 0) delta += TS_WRAP;
        if (delta != 1 && (*last_ts != -1))
        {
          printf("Board %d timestamp sequence error, %d->%d\n",
                 k, brd_block[k][ptr[k].p].ts, pblk[k]->ts);
          fflush(stdout);
        }
        ptr[k].p++;
        memcpy(&brd_block[k][ptr[k].p], pblk[k], sizeof(i_q_ts));
      }
    }
  }

  /* Now find synchronous blocks */
  for (k = 0, ts_min = TS_WRAP, ts_max = -1; k < BRD_COUNT; k++)
  {
    ts[k] = brd_block[k][ptr[k].p].ts;
    if (ts[k] > ts_max)
      ts_max = ts[k];
    if (ts[k] < ts_min)
      ts_min = ts[k];
  }

  /* Swap on wraparound */
  if (ts_min == 0 && ts_max == 15)
  {
    ts_min = 15;
    ts_max = 0;
  }

  if (ts_min != *last_ts) /* New timestamp found */
  {
    for (k = 0; k < BRD_COUNT; k++)
      if (ts[k] == ts_min) /* Current timestamp */
        cp[k] = ptr[k].p;
      else
      {
        for (m = 0, cp[k] = -1; m < SCALAR_N; m++)
          if (brd_block[k][m].ts == ts_min)
          {
            cp[k] = m;
            break;
          }
       }
    if ((cp[0] != -1) && (cp[1] != -1) && (cp[2] != -1))
    {
      /* New data found, copy and convert */
      for (k = 0; k < BRD_COUNT; k++)
        for (ch = 0; ch < 5; ch++)
        {
          pI[k][ch] = (double)brd_block[k][cp[k]].iq[ch]._I *
                      (iq_scale[k]/cic_decim*32);
          pQ[k][ch] = (double)brd_block[k][cp[k]].iq[ch]._Q *
                      (iq_scale[k]/cic_decim*32);
          *pG++ = pI[k][ch]; *pG++ = pQ[k][ch];
        }
      *pG++ = (double)ts_min;
      if (*last_ts != -1)
      {
        int delta = ts_min - *last_ts;
        if (delta < 0) delta += TS_WRAP;
        if (delta != 1)
          *seq_error = 1;
        else
          *seq_error = 0;
      }
      else
        *seq_error = 0;

      *last_ts = ts_min;
      return 0;
    }
  }

  /* No new data, skip updates */
  return 1;
}
#endif

static registryFunctionRef subScalarRef[] = {
  {"subVectorSum", (REGISTRYFUNCTION)subVectorSum},
  {"subScalarSync", (REGISTRYFUNCTION)subScalarSync}
};

static void subScalarRegistrar(void)
{
  registryFunctionRefAdd(subScalarRef, NELEMENTS(subScalarRef));
}
epicsExportRegistrar(subScalarRegistrar);
