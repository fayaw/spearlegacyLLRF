/*
 Tuner loop
 
 Copyright (c) 2012 Dimtel, Inc., All Rights Reserved

 $Id$
 $Date$
 $Author$
 $Revision$
 $Log$

*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <stdint.h>

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <dbAccess.h>

#include "cmath.h"

#define MAX_STEPS 600.0
#define STOP_INT  500.0

static long subTunerLoop(aSubRecord *pasub)
{
  /*
   * Input:   A = Combined I/Q vector (in sync)
   *          B = Probe index
   *          C = Load angle offset (deg)
   *          D = Deadband (deg)
   *          E = Minimum forward power (kW)
   *          F = Forward magnitude (kW)
   *          G = Integral gain (motor rotational degrees/degree)
   *          H = Loop control (0 - off, 1 - on)
   *          I = Sign (0 - 1, 1 - -1)
   *          J = Differential offsets
   *          K = Tuner motor 1 steps left
   *          L = Tuner motor 2 steps left
   *          M = Anti-windup gain
   *          N = Differential gain
   *          O = Proportional gain
   *          P = Forward index
   *          Q = Probe phase offset
   *          R = Forward phase offset
   *          S = Probe reference index
   *          T = Forward reference index
   *           
   * Outputs: A = Tuner motor 1 relative position control
   *          B = Tuner motor 2 relative position control
   *          C = Error signal
   *          D = Integrator
   *          E = Tuner motor 1 position
   *          F = Tuner motor 2 position
   *          G = Integrated difference
   *          H = Flag storage
   *        
   */

  double *pIQ = (double *)pasub->a;
  double deadbnd = *(double *)pasub->d;
  double pwrfwd  = *(double *)pasub->f;
  double minfwd  = *(double *)pasub->e;
  double gain_i  = *(double *)pasub->g;
  double gain_p  = *(double *)pasub->o;
  double gain_d  = *(double *)pasub->n;
  double gain_w  = *(double *)pasub->m;
  long ctrl      = *(uint32_t *)pasub->h;
  long sign      = *(uint32_t *)pasub->i;
  double delta   = *(double *)pasub->j;
  double m1diff  = *(double *)pasub->k;
  double m2diff  = *(double *)pasub->l;

  double prop = 0.0, diff = 0.0;
  double integrator = *(double *)pasub->ovld;
  double delta_int  = *(double *)pasub->ovlg;
  
  /* Compute probe and forward phases, calculate tuning error */
  double probe_phase, fwd_phase, err, antiwindup;
  double complex z;
  
  z = pIQ[*(long *)pasub->b] - pIQ[*(long *)pasub->b+1]*I;
  probe_phase = carg(z)/M_PI*180.0 + *(double *)pasub->q;
  z = pIQ[*(long *)pasub->s] - pIQ[*(long *)pasub->s+1]*I;
  probe_phase -= carg(z)/M_PI*180.0;
  z = pIQ[*(long *)pasub->p] - pIQ[*(long *)pasub->p+1]*I;
  fwd_phase = carg(z)/M_PI*180.0 + *(double *)pasub->r;
  z = pIQ[*(long *)pasub->t] - pIQ[*(long *)pasub->t+1]*I;
  fwd_phase -= carg(z)/M_PI*180.0;

  err = phase_clip(fwd_phase - probe_phase - *(double *)pasub->c);

  if (pwrfwd < minfwd)
  {
    ctrl  = 0;
    delta = 0.0;
  }
  
  if (fabs(m1diff) >= STOP_INT || fabs(m2diff) >= STOP_INT)
  {
    ctrl = 0;
    delta = 0;
  }

  if (err <= -360.0)
    err += 360.0;
  else if (err >= 360.0)
    err -= 360.0;

  if (ctrl == 1)
  {
    if (fabs(err) > deadbnd) /* Need to update tuner loop */
    {
      double sgn = (1.0 - (sign<<1));
      prop        = sgn * err * gain_p;
      diff        = (err - *(double *)pasub->ovlc) * sgn * gain_d;
      integrator += err * sgn * gain_i;
      antiwindup  = 0;
    }
    delta_int   += delta; /* Update balancing loop integrator */
  }
  else
  {
    integrator = delta_int = 0.0;
  }
    
  /* Output the new value */
  *(double *)pasub->vale = prop + integrator + diff + delta_int - antiwindup;
  *(double *)pasub->valf = prop + integrator + diff - delta_int - antiwindup;

  if (ctrl == 1)
  {
    /* Make it incremental */
    *(double *)pasub->vala = *(double *)pasub->vale - *(double *)pasub->ovle;
    *(double *)pasub->valb = *(double *)pasub->valf - *(double *)pasub->ovlf;
  }
  else
  {
    *(double *)pasub->vala = 0.0;
    *(double *)pasub->valb = 0.0;
  }

  *(double *)pasub->valc = err;
  *(double *)pasub->vald = integrator;
  *(double *)pasub->valg = delta_int;

  
#if 0
  printf("%s: fwd=%.1f, err=%.1f, prop=%.1f, int=%.1f, diff=%.1f, gain_i=%.1f\n",
         pasub->name, pwrfwd, err, prop, integrator, diff, gain_i);
#endif
  
  return 0;
}

static long subTunerBalanceLoop(aSubRecord *pasub)
{
  /*
   * Input:   A = Probe 2 magnitude
   *          B = Probe 3 (center) magnitude
   *          C = Ratio
   *          D = Deadband (kV)
   *          E = Gain
   *          F = Loop control (0 - off, 1 - on)
   *          G = Sign (0 - 1, 1 - -1)
   *           
   * Outputs: A = Differential drive to subTunerLoop
   *          B = Error value (kV)
   */

  double v2       = *(double *)pasub->a;
  double v3       = *(double *)pasub->b;
  double ratio    = *(double *)pasub->c;
  double deadband = *(double *)pasub->d;
  double gain     = *(double *)pasub->e;
  long ctrl       = *(uint32_t *)pasub->f;
  long sign       = *(uint32_t *)pasub->g;

  double err, step;
  
  err = v2 - v3*ratio;
  
  if (fabs(err) < deadband)
    step = 0.0;
  else
    step = gain * err;

  if (ctrl == 0)
    step = 0.0;
  
  if (sign)
    step = - step;

  *(double *)pasub->vala = step;
  *(double *)pasub->valb = err;

  return 0;
}

static long subTunerCtrl(aSubRecord *pasub)
{
  /*
   * Input:   A = Incremental distance value
   *          C = In range bit
   *          D = Interlock bit
   *           
   * Outputs: A = Tuner motor enable
   *          B = Tuner motor direction
   *          C = Distance remaining
   */

  double delta_dist  = *(double *)pasub->a;
  int in_range    = *(int32_t *)pasub->c;
  int interlock   = *(int32_t *)pasub->d;
  int enable, dir;
  double dist;

  dist = *(double *)pasub->ovlc;
  dist += delta_dist;
  if (dist > MAX_STEPS)
    dist = MAX_STEPS;
  
  if (dist < -MAX_STEPS)
    dist = -MAX_STEPS;

  if (in_range & interlock) /* Both must be set to proceed */
  {
    if (fabs(dist) >=  1.0)
    {
      if (dist > 0.0)
      {
        dir = 0;
        dist -= 1.0;
      }
      else
      {
        dir = 1;
        dist += 1.0;
      }
      enable = 0;
    }
    else
      enable = 1;
  }
  else
    enable = 1; /* Motor disabled */
    
  *(int16_t *)pasub->vala = enable;
  *(int16_t *)pasub->valb = dir;
  *(double *)pasub->valc  = dist;

  return 0;
}

static registryFunctionRef subTunerRef[] = {
  {"subTunerLoop", (REGISTRYFUNCTION)subTunerLoop},
  {"subTunerCtrl", (REGISTRYFUNCTION)subTunerCtrl},
  {"subTunerBalanceLoop", (REGISTRYFUNCTION)subTunerBalanceLoop}
};

static void subTunerRegistrar(void)
{
  registryFunctionRefAdd(subTunerRef, NELEMENTS(subTunerRef));
}
epicsExportRegistrar(subTunerRegistrar);
