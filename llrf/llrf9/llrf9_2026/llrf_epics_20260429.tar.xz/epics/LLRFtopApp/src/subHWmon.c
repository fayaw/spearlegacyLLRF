/*
 Subroutines for hardware monitoring (motherboard)
 
 Copyright (c) 2008-2012 Dimtel, Inc., All Rights Reserved

 $Id: subHWmon.c,v 1.1 2017/03/10 19:44:58 dim Exp $
 $Date: 2017/03/10 19:44:58 $
 $Author: dim $
 $Revision: 1.1 $
 $Log: subHWmon.c,v $
 Revision 1.1  2017/03/10 19:44:58  dim
 Initial import

*/

#include   <stdlib.h>
#include   <unistd.h>
#include   <stdio.h>
#include   <string.h>

#include   <dbDefs.h>
#include   <registryFunction.h>
#include   <subRecord.h>
#include   <epicsExport.h>
#include   <dbAccess.h>

#include   <pthread.h>
#include   <termios.h>
#include   <sys/time.h>
#include   "hwmon.h"
#include   "LLRFhw.h"

static int hwmon_initialized = -1;
static pthread_mutex_t init_mutex = PTHREAD_MUTEX_INITIALIZER;

typedef long (*processMethod)(subRecord *precord);

static long subHWmonInit(subRecord *psub, processMethod process)
{
  pthread_mutex_lock(&init_mutex);
  if (hwmon_initialized == -1)
    hwmon_initialized = hwmon_init();
  pthread_mutex_unlock(&init_mutex);

  return (hwmon_initialized != -1);
}

/* Amplifier poll */
static long subHWmonRead(subRecord *psub)
{
  /*
   * Outputs: A = CPU temperature
   *          B = CPU fan speed
   *          C = Chassis fan speed
   */
  hwmon_data data;

  if (hwmon_read(&data) < 0)
    return 1;
    
  dbPutLink(&psub->inpa, DBR_DOUBLE, &data.cpu_temp, 1);
  dbPutLink(&psub->inpb, DBR_LONG, &data.cpu_fan, 1);
  dbPutLink(&psub->inpc, DBR_LONG, &data.chassis_fan, 1);
  
  return 0;
}

static registryFunctionRef subHWmonRef[] = {
  {"subHWmonInit", (REGISTRYFUNCTION)subHWmonInit},
  {"subHWmonRead", (REGISTRYFUNCTION)subHWmonRead}
};

static void subHWmonRegistrar(void)
{
  registryFunctionRefAdd(subHWmonRef, NELEMENTS(subHWmonRef));
}

epicsExportRegistrar(subHWmonRegistrar);
