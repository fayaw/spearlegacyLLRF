/*
 Top level IOC. Executes startup script and pauses
 
 Copyright (c) 2012 Dimtel, Inc., All Rights Reserved

 $Id: LLRFtopMain.c,v 1.2 2021/11/04 06:53:15 dim Exp $
 $Date: 2021/11/04 06:53:15 $
 $Author: dim $
 $Revision: 1.2 $
 $Log: LLRFtopMain.c,v $
 Revision 1.2  2021/11/04 06:53:15  dim
 Enabled IOC shell

 Revision 1.1  2017/03/10 19:44:58  dim
 Initial import

*/

#include <stddef.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

#include "epicsExit.h"
#include "epicsThread.h"
#include "iocsh.h"

int main(int argc,char *argv[])
{
    if (argc >= 2)
    {
        iocsh(argv[1]);
        epicsThreadSleep(.2);
    }
    /* Running under screen, enable shell */
    if (1)
      iocsh(NULL);
    else
      pause();

    epicsExit(0);
    return(0);
}
