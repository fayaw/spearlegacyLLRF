/*
 HVPS loop to maintain drive power in closed loop operation
 
 Copyright (c) 2021 Dimtel, Inc., All Rights Reserved

 $Id: subHVPS.c,v 1.1 2021/11/04 06:52:55 dim Exp $
 $Date: 2021/11/04 06:52:55 $
 $Author: dim $
 $Revision: 1.1 $
 $Log: subHVPS.c,v $
 Revision 1.1  2021/11/04 06:52:55  dim
 Initial commit


*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <stdbool.h>

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <dbAccess.h>

static long subHVPSLoop(aSubRecord *pasub)
{
  /*
   * Input:   A = Drive power measurement (W, double)
   *          B = Klystron forward measurement (kW, double)
   *          C = Klystron forward hysteresis (kW, double)
   *          D = Feedback loop control (long)
   *          E = Low drive power setting (W, double)
   *          F = High drive power setting (W, double)
   *          G = Deadband (W, double)
   *          H = Loop gain (conversion factor, W/kV, double)
   *          I = Maximum delta (kV, double)
   *          J = High drive forward power point (kW, double)
   *          K = HVPS control setting (kV, double)
   *          L = HVPS minimum (kV, double)
   *          M = HVPS maximum (kV, double)
   *          N = Interlock (0 - cleared, 1 - tripped, long)
   *          O = Collector power from the PLC (kW, double)
   *          P = Collector power limit (kW, double)
   *          Q = Loop control
   *           
   * Outputs: A = HVPS incremental control signal (kV, double)
   *          B = HVPS control setting (kV, double)
   *          C = Drive setpoint (W, double)
   *          D = Drive setpoint selector (0 low, 1, high, long)
   *          E = Loop error (W, double)
   *          F = Status message (string)
   *          G = Update flag (0 - write, 1 - disable, long)
   *          H = Interlock state storage
   */

  static bool first = true;
  double drive     = *(double *)pasub->a;
  double klyfwd    = *(double *)pasub->b;
  double klyhist   = *(double *)pasub->c;
  long ctrl        = *(uint32_t *)pasub->d;
  double deadband  = *(double *)pasub->g;
  double gain      = *(double *)pasub->h;
  double max_delta = *(double *)pasub->i;
  double klyhigh   = *(double *)pasub->j;
  double hvps_in   = *(double *)pasub->k;
  double hvps_min  = *(double *)pasub->l;
  double hvps_max  = *(double *)pasub->m;
  long   interlock = *(uint32_t *)pasub->n;
  double plcpc     = *(double *)pasub->o;
  double plcpc_lim = *(double *)pasub->p;
  long   mode      = *(uint32_t *)pasub->q;
  
  double *delta           = (double *)  pasub->vala;
  double *hvps_out        = (double *)  pasub->valb;
  double *setpt           = (double *)  pasub->valc;
  uint32_t *sp_sel        = (uint32_t *)pasub->vald;
  double *err             = (double *)  pasub->vale;
  char *msg               = (char *)    pasub->valf;
  uint32_t *flag          = (uint32_t *)pasub->valg;
  uint32_t *interlock_old = (uint32_t *)pasub->valh;

  double drv_sp[2];
  drv_sp[0] = *(double *)pasub->e;
  drv_sp[1] = *(double *)pasub->f;
  
  char buf[30];
  
  if (first)
    *sp_sel = 0;

  *flag = 1; /* No update by default */
  
  /* First figure out the setpoint */
  if (klyfwd >= klyhigh)
    *sp_sel = 1;
  else if (sp_sel && (klyfwd >= klyhigh - klyhist))
    *sp_sel = 1;
  else
    *sp_sel = 0;
    
  *setpt = drv_sp[*sp_sel];
  
  /* Calculate the error */
  *err = *setpt - drive;
  
  /* Do not run if:
     mode set to 0 (drive power loop open)
     interlock is tripped
     field control loop is open */
  if (mode == 0)
    sprintf(msg, "Disabled: open loop");
  else if (interlock)
  {
    if (*interlock_old)
      sprintf(msg, "Disabled: interlock tripped");
    else
    {
      *hvps_out = hvps_min;
      *flag     = 0;
      sprintf(msg, "Disabling: setting HVPS to %.1f kV", *hvps_out);
    }
  }
  else if (ctrl)
  {
    /* Update if we exceed the deadband */
    if (fabs(*err) > deadband)
    {
      *buf = 0;
      *delta = *err * gain;
      if (*delta > max_delta)
      {
        *delta = max_delta;
        strcpy(buf, ": positive rate limited");
      }
      if (*delta < -max_delta)
      {
        *delta = -max_delta;
        strcpy(buf, ": negative rate limited");
      }
      if (plcpc > plcpc_lim)
      {
        /* Only apply downward adjustments to the HVPS */
        if (*delta < 0.0) *delta = 0.0;
        strcpy(buf, ": collector power limit");
      }
      *hvps_out = hvps_in - *delta;
      if (*hvps_out < hvps_min)
      {
        *hvps_out = hvps_min;
        sprintf(msg, "Active: at the minimum (%.1f kV)", hvps_min);
      }
      else if (*hvps_out > hvps_max)
      {
        *hvps_out = hvps_max;
        sprintf(msg, "Active: at the maximum (%.1f kV)", hvps_max);
      }
      else
        sprintf(msg, "Active%s", buf);
      *flag = 0;
    }
    else
    {
      *delta = 0.0;
      sprintf(msg, "Active: in deadband");
    }
  }
  else
    sprintf(msg, "Disabled: field control loop is open");

  /* Save interlock state */
  if (first)
  {
    *interlock_old = 1;
    first = false;
  }
  else
    *interlock_old = interlock;

/*  printf("update %d, hvps_out %.1f, msg %s\n", *flag, *hvps_out, msg); */
  
  return 0;
}

static long subHVPSUpdate(aSubRecord *pasub)
{
  /*
   * Input:   A = HVPS setting (kV, double)
   *          B = Update flag (ulong)
   *
   * Outputs: A = HVPS control setting (kV, double)
   */

  double hvps = *(double *)pasub->a;
  long   flag = *(uint32_t *)pasub->b;
  
  double *hvps_out = (double *)pasub->vala;
  
  *hvps_out = hvps;

  return flag;
}

static registryFunctionRef subHVPSRef[] = {
  {"subHVPSLoop", (REGISTRYFUNCTION)subHVPSLoop},
  {"subHVPSUpdate", (REGISTRYFUNCTION)subHVPSUpdate}
};

static void subHVPSRegistrar(void)
{
  registryFunctionRefAdd(subHVPSRef, NELEMENTS(subHVPSRef));
}
epicsExportRegistrar(subHVPSRegistrar);
