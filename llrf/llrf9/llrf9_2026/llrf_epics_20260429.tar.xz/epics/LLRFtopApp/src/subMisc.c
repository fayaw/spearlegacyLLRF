/*
 Miscellaneous subroutines
 
 Copyright (c) 2019 Dimtel, Inc., All Rights Reserved

 $Id: subMisc.c,v 1.6 2025/11/07 18:21:51 dim Exp $
 $Date: 2025/11/07 18:21:51 $
 $Author: dim $
 $Revision: 1.6 $
 $Log: subMisc.c,v $
 Revision 1.6  2025/11/07 18:21:51  dim
 Expanded string copy

 Revision 1.5  2021/11/04 06:55:34  dim
 Two more outputs added to string copy aSub

 Revision 1.4  2019/11/19 04:35:31  dim
 Update units copy routine

 Revision 1.3  2019/11/13 03:51:21  dim
 Added fourth output to EGU copy

 Revision 1.2  2019/09/18 14:59:14  dim
 Units copy extended to 3 outputs, state machine added

 Revision 1.1  2019/08/24 18:24:39  dim
 Units copy subroutine, should really be merged with the one in LLRFhwApp


*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <netdb.h>

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <dbAccess.h>

typedef long (*processMethod)(subRecord *precord);

static long subMiscInit(subRecord *psub, processMethod process)
{
  psub->val = 0;
  return 0;
}

static long subMiscStringCp(aSubRecord *pgsub)
{
  /*
   * Input:   A = Input string
   * Outputs: A = Output copy 1
   *          B = Output copy 2
   *          C = Output copy 3
   *          D = Output copy 4
   *          E = Output copy 5
   *          F = Output copy 6
   *          G = Output copy 7
   *          H = Output copy 8
   *          I = Output copy 9
   */
  
  strncpy(pgsub->vala, pgsub->a, 39);
  
  if (pgsub->ftvb == DBR_STRING) /* Check if we need the second output */
    strncpy(pgsub->valb, pgsub->a, 39);
  if (pgsub->ftvc == DBR_STRING) /* Check if we need the third output */
    strncpy(pgsub->valc, pgsub->a, 39);
  if (pgsub->ftvd == DBR_STRING) /* Check if we need the fourth output */
    strncpy(pgsub->vald, pgsub->a, 39);
  if (pgsub->ftve == DBR_STRING) /* Check if we need the fifth output */
    strncpy(pgsub->vale, pgsub->a, 39);
  if (pgsub->ftvf == DBR_STRING) /* Check if we need the sixth output */
    strncpy(pgsub->valf, pgsub->a, 39);
  if (pgsub->ftvg == DBR_STRING) /* Check if we need the seventh output */
    strncpy(pgsub->valg, pgsub->a, 39);
  if (pgsub->ftvh == DBR_STRING) /* Check if we need the eighth output */
    strncpy(pgsub->valh, pgsub->a, 39);
  if (pgsub->ftvi == DBR_STRING) /* Check if we need the eighth output */
    strncpy(pgsub->vali, pgsub->a, 39);
  
  return 0;
}

static registryFunctionRef subMiscRef[] = {
  {"subMiscInit", (REGISTRYFUNCTION)subMiscInit},
  {"subMiscStringCp", (REGISTRYFUNCTION)subMiscStringCp}
};

static void subMiscRegistrar(void)
{
  registryFunctionRefAdd(subMiscRef, NELEMENTS(subMiscRef));
}
epicsExportRegistrar(subMiscRegistrar);
