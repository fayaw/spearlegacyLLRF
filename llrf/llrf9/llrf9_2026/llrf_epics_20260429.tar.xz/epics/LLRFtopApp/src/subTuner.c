/*
 Tuner loop
 
 Copyright (c) 2012-2016 Dimtel, Inc., All Rights Reserved

 $Id: subTuner.c,v 1.4 2022/11/13 23:36:33 dim Exp $
 $Date: 2022/11/13 23:36:33 $
 $Author: dim $
 $Revision: 1.4 $
 $Log: subTuner.c,v $
 Revision 1.4  2022/11/13 23:36:33  dim
 Dual tuner support, with probe balancing loop

 Revision 1.3  2021/11/04 06:58:47  dim
 Added SPEAR3 tuner control loop (demo)

 Revision 1.2  2019/08/24 18:28:12  dim
 Renamed LNLS to Velocity

 Revision 1.1  2017/03/10 19:44:58  dim
 Initial import

*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <stdint.h>

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <dbAccess.h>

#include "cmath.h"

static long subTunerLoop_motorRecord(aSubRecord *pasub)
{
  /*
   * Input:   A = Combined I/Q vector (in sync)
   *          B = Probe index
   *          C = Load angle offset (deg)
   *          D = Deadband (deg)
   *          E = Minimum forward power (kW)
   *          F = Forward magnitude (kW)
   *          G = Integral gain (motor rotational degrees/degree)
   *          H = Loop control (0 - off, 1 - on)
   *          I = Sign (0 - 1, 1 - -1)
   *          J = Differential offsets
   *          K = Tuner motor 1 diff
   *          L = Tuner motor 2 diff
   *          M = Anti-windup gain
   *          N = Differential gain
   *          O = Proportional gain
   *          P = Forward index
   *          Q = Probe phase offset
   *          R = Forward phase offset
   *          S = Probe reference index
   *          T = Forward reference index
   *           
   * Outputs: A = Tuner motor 1 relative position control
   *          B = Tuner motor 2 relative position control
   *          C = Error signal
   *          D = Integrator
   *          E = Tuner motor 1 position
   *          F = Tuner motor 2 position
   *          G = Integrated difference
   *        
   */

  double *pIQ = (double *)pasub->a;
  double deadbnd = *(double *)pasub->d;
  double pwrfwd  = *(double *)pasub->f;
  double minfwd  = *(double *)pasub->e;
  double gain_i  = *(double *)pasub->g;
  double gain_p  = *(double *)pasub->o;
  double gain_d  = *(double *)pasub->n;
  double gain_w  = *(double *)pasub->m;
  long ctrl      = *(uint32_t *)pasub->h;
  long sign      = *(uint32_t *)pasub->i;
  double delta   = *(double *)pasub->j;
  double m1diff  = *(double *)pasub->k;
  double m2diff  = *(double *)pasub->l;

  double prop = 0.0, diff = 0.0;
  double integrator = *(double *)pasub->ovld;
  double delta_int  = *(double *)pasub->ovlg;
  
  /* Compute probe and forward phases, calculate tuning error */
  double probe_phase, fwd_phase, err, antiwindup;
  double complex z;
  
  z = pIQ[*(long *)pasub->b] - pIQ[*(long *)pasub->b+1]*I;
  probe_phase = carg(z)/M_PI*180.0 + *(double *)pasub->q;
  z = pIQ[*(long *)pasub->s] - pIQ[*(long *)pasub->s+1]*I;
  probe_phase -= carg(z)/M_PI*180.0;
  z = pIQ[*(long *)pasub->p] - pIQ[*(long *)pasub->p+1]*I;
  fwd_phase = carg(z)/M_PI*180.0 + *(double *)pasub->r;
  z = pIQ[*(long *)pasub->t] - pIQ[*(long *)pasub->t+1]*I;
  fwd_phase -= carg(z)/M_PI*180.0;

  err = phase_clip(fwd_phase - probe_phase - *(double *)pasub->c);

  if (pwrfwd < minfwd)
  {
    ctrl  = 0;
    delta = 0.0;
  }

  if (err <= -360.0)
    err += 360.0;
  else if (err >= 360.0)
    err -= 360.0;

  if (ctrl == 1)
  {
    if (fabs(err) > deadbnd) /* Need to update tuner loop */
    {
      double sgn = (1.0 - (sign<<1));
      prop        = sgn * err * gain_p;
      diff        = (err - *(double *)pasub->ovlc) * sgn * gain_d;
      integrator += err * sgn * gain_i;
      antiwindup  = gain_w * (m1diff + m2diff)/2;
      integrator -= antiwindup;
    }
    delta_int   += delta; /* Update balancing loop integrator */
  }
  else
  {
    /* Incremental output mode allows us to reset integrators */
    integrator = 0.0;
    delta_int  = 0.0;
  }

  /* Output the new value */
  *(double *)pasub->vale = prop + integrator + diff + delta_int;
  *(double *)pasub->valf = prop + integrator + diff - delta_int;

  if (ctrl == 1)
  {
    /* Make it incremental */
    *(double *)pasub->vala = *(double *)pasub->vale - *(double *)pasub->ovle;
    *(double *)pasub->valb = *(double *)pasub->valf - *(double *)pasub->ovlf;
  }
  else
  {
    *(double *)pasub->vala = 0.0;
    *(double *)pasub->valb = 0.0;
  }

  *(double *)pasub->valc = err;
  *(double *)pasub->vald = integrator;
  *(double *)pasub->valg = delta_int;

  
#if 0
  printf("%s: fwd=%.1f, err=%.1f, prop=%.1f, int=%.1f, diff=%.1f, gain_i=%.1f\n",
         pasub->name, pwrfwd, err, prop, integrator, diff, gain_i);
#endif
  
  return 0;
}

#define STOP_INT  500.0

static long subTunerLoop_DLSB(aSubRecord *pasub)
{
  /*
   * DLS booster tuner control
   * Input:   A = Combined I/Q vector (in sync)
   *          B = Probe index
   *          C = Load angle offset (deg)
   *          D = Deadband (deg)
   *          E = Minimum forward power (kW)
   *          F = Forward magnitude (kW)
   *          G = Integral gain (motor rotational degrees/degree)
   *          H = Loop control (0 - off, 1 - on)
   *          I = Sign (0 - 1, 1 - -1)
   *          J = Differential offsets
   *          K = Tuner motor 1 steps left
   *          L = Tuner motor 2 steps left
   *          M = Anti-windup gain
   *          N = Differential gain
   *          O = Proportional gain
   *          P = Forward index
   *          Q = Probe phase offset
   *          R = Forward phase offset
   *          S = Probe reference index
   *          T = Forward reference index
   *           
   * Outputs: A = Tuner motor 1 relative position control
   *          B = Tuner motor 2 relative position control
   *          C = Error signal
   *          D = Integrator
   *          E = Tuner motor 1 position
   *          F = Tuner motor 2 position
   *          G = Integrated difference
   *          H = Flag storage
   *        
   */

  double *pIQ = (double *)pasub->a;
  double deadbnd = *(double *)pasub->d;
  double pwrfwd  = *(double *)pasub->f;
  double minfwd  = *(double *)pasub->e;
  double gain_i  = *(double *)pasub->g;
  double gain_p  = *(double *)pasub->o;
  double gain_d  = *(double *)pasub->n;
  long ctrl      = *(uint32_t *)pasub->h;
  long sign      = *(uint32_t *)pasub->i;
  double delta   = *(double *)pasub->j;
  double m1diff  = *(double *)pasub->k;
  double m2diff  = *(double *)pasub->l;

  double prop = 0.0, diff = 0.0;
  double integrator = *(double *)pasub->ovld;
  double delta_int  = *(double *)pasub->ovlg;
  
  /* Compute probe and forward phases, calculate tuning error */
  double probe_phase, fwd_phase, err, antiwindup;
  double complex z;
  
  z = pIQ[*(long *)pasub->b] - pIQ[*(long *)pasub->b+1]*I;
  probe_phase = carg(z)/M_PI*180.0 + *(double *)pasub->q;
  z = pIQ[*(long *)pasub->s] - pIQ[*(long *)pasub->s+1]*I;
  probe_phase -= carg(z)/M_PI*180.0;
  z = pIQ[*(long *)pasub->p] - pIQ[*(long *)pasub->p+1]*I;
  fwd_phase = carg(z)/M_PI*180.0 + *(double *)pasub->r;
  z = pIQ[*(long *)pasub->t] - pIQ[*(long *)pasub->t+1]*I;
  fwd_phase -= carg(z)/M_PI*180.0;

  err = phase_clip(fwd_phase - probe_phase - *(double *)pasub->c);

  if (pwrfwd < minfwd)
  {
    ctrl  = 0;
    delta = 0.0;
  }
  
  if (fabs(m1diff) >= STOP_INT || fabs(m2diff) >= STOP_INT)
  {
    ctrl = 0;
    delta = 0;
  }

  if (err <= -360.0)
    err += 360.0;
  else if (err >= 360.0)
    err -= 360.0;

  if (ctrl == 1)
  {
    if (fabs(err) > deadbnd) /* Need to update tuner loop */
    {
      double sgn = (1.0 - (sign<<1));
      prop        = sgn * err * gain_p;
      diff        = (err - *(double *)pasub->ovlc) * sgn * gain_d;
      integrator += err * sgn * gain_i;
      antiwindup  = 0;
    }
    delta_int   += delta; /* Update balancing loop integrator */
  }
  else
  {
    integrator = delta_int = 0.0;
  }
    
  /* Output the new value */
  *(double *)pasub->vale = prop + integrator + diff + delta_int - antiwindup;
  *(double *)pasub->valf = prop + integrator + diff - delta_int - antiwindup;

  if (ctrl == 1)
  {
    /* Make it incremental */
    *(double *)pasub->vala = *(double *)pasub->vale - *(double *)pasub->ovle;
    *(double *)pasub->valb = *(double *)pasub->valf - *(double *)pasub->ovlf;
  }
  else
  {
    *(double *)pasub->vala = 0.0;
    *(double *)pasub->valb = 0.0;
  }

  *(double *)pasub->valc = err;
  *(double *)pasub->vald = integrator;
  *(double *)pasub->valg = delta_int;

  
#if 0
  printf("%s: fwd=%.1f, err=%.1f, prop=%.1f, int=%.1f, diff=%.1f, gain_i=%.1f\n",
         pasub->name, pwrfwd, err, prop, integrator, diff, gain_i);
#endif
  
  return 0;
}

static long subTunerLoop_ANKA(aSubRecord *pasub)
{
  /*
   * Input:   A = Combined I/Q vector (in sync)
   *          B = Probe index
   *          C = Load angle offset (deg)
   *          D = Deadband (deg)
   *          E = Minimum forward power (kW)
   *          F = Forward magnitude (kW)
   *          G = Integral gain (motor rotational degrees/degree)
   *          H = Loop control (0 - off, 1 - on)
   *          I = Sign (0 - 1, 1 - -1)
   *          J = Differential offsets
   *          M = Anti-windup gain
   *          N = Differential gain
   *          O = Proportional gain
   *          P = Forward index
   *          Q = Probe phase offset
   *          R = Forward phase offset
   *          S = Probe reference index
   *          T = Forward reference index
   *           
   * Outputs: A = Tuner position
   *          C = Error signal
   *          D = Integrator
   *          G = Integrated difference
   *          I = First flag (set to 1 after first processing cycle)
   *          J = Previous ctrl value
   *        
   */

  long nRequest;
  double *pIQ = (double *)pasub->a;
  double deadbnd = *(double *)pasub->d;
  double pwrfwd  = *(double *)pasub->f;
  double minfwd  = *(double *)pasub->e;
  double gain_i  = *(double *)pasub->g;
  double gain_p  = *(double *)pasub->o;
  double gain_d  = *(double *)pasub->n;
  double gain_w  = *(double *)pasub->m;
  int ctrl       = *(uint32_t *)pasub->h;
  int sign       = *(uint32_t *)pasub->i;
  double delta   = *(double *)pasub->j;

  double prop = 0.0, diff = 0.0, pos_err, pos_rdbk;
  double integrator = *(double *)pasub->ovld;
  int32_t first = *(int32_t *)pasub->ovli;
  int32_t *old_ctrl = pasub->ovlj;
  int rc;
  
  /* Compute probe and forward phases, calculate tuning error */
  double probe_phase, fwd_phase, err, antiwindup;
  double complex z;
  
  z = pIQ[*(long *)pasub->b] - pIQ[*(long *)pasub->b+1]*I;
  probe_phase = carg(z)/M_PI*180.0 + *(double *)pasub->q;
  z = pIQ[*(long *)pasub->s] - pIQ[*(long *)pasub->s+1]*I;
  probe_phase -= carg(z)/M_PI*180.0;
  z = pIQ[*(long *)pasub->p] - pIQ[*(long *)pasub->p+1]*I;
  fwd_phase = carg(z)/M_PI*180.0 + *(double *)pasub->r;
  z = pIQ[*(long *)pasub->t] - pIQ[*(long *)pasub->t+1]*I;
  fwd_phase -= carg(z)/M_PI*180.0;

  err = phase_clip(fwd_phase - probe_phase - *(double *)pasub->c);

  if (pwrfwd < minfwd)
  {
    ctrl  = 0;
    delta = 0.0;
  }

  if (err <= -360.0)
    err += 360.0;
  else if (err >= 360.0)
    err -= 360.0;

  /* If first pass or going from open loop to closed loop, set integrator
     to current position readback.
  */
  if ((first == 0) | (ctrl & !*old_ctrl))
  {
  
    nRequest = 1;
    dbGetLinkValue(&pasub->outa, DBR_DOUBLE, &integrator, NULL, &nRequest);
    *(int32_t *)pasub->vali = 1;
  }
  
  /* Store current ctrl value */
  *(int32_t *)pasub->valj = ctrl;
  
  rc = 1;
  if (ctrl == 1)
  {
    if (fabs(err) > deadbnd) /* Need to update tuner loop */
    {
      /* Read back position control, subract from requested value */
      nRequest = 1;
      dbGetLinkValue(&pasub->outa, DBR_DOUBLE, &pos_rdbk, NULL, &nRequest);
      pos_err = *(double *)pasub->vala - pos_rdbk;
      
      if (fabs(pos_err) < 1)
      {
        double sgn = (1.0 - (sign<<1));
        prop        = sgn * err * gain_p;
        diff        = (err - *(double *)pasub->ovlc) * sgn * gain_d;
        integrator += err * sgn * gain_i;
        antiwindup  = gain_w * delta;
        integrator -= antiwindup;
        rc = 0;
      }
    }
  }

  *(double *)pasub->vala = prop + integrator + diff;
  *(double *)pasub->valc = err;
  dbPutLink(&pasub->outc, DBR_DOUBLE, &err, 1);
  *(double *)pasub->vald = integrator;

  
#if 0
  printf("%s: fwd=%.2f, err=%.1f, vala=%.1f, pos_err=%.1f, pos_rdbk=%.1f\n",
         pasub->name, pwrfwd, err, *(double *)pasub->vala, pos_err, pos_rdbk);
#endif

  return rc;
}

static long subTunerLoop_Velocity(aSubRecord *pasub)
{
  /*
   * Input:   A = Combined I/Q vector (in sync)
   *          B = Probe index
   *          C = Load angle offset (deg)
   *          D = Deadband (deg)
   *          E = Minimum forward power (kW)
   *          F = Forward magnitude (kW)
   *          G = Integral gain (motor rotational degrees/degree)
   *          H = Loop control (0 - off, 1 - on)
   *          I = Sign (0 - 1, 1 - -1)
   *          J = Differential offsets
   *          K = 
   *          L = 
   *          M = Anti-windup gain (UNUSED)
   *          N = Differential gain
   *          O = Proportional gain
   *          P = Forward index
   *          Q = Probe phase offset
   *          R = Forward phase offset
   *          S = Probe reference index
   *          T = Forward reference index
   *          U = Control signal deadband (need at least +/-D to move)
   *           
   * Outputs: A = Tuner 1 motor speed control
   *          B = Tuner 2 motor speed control
   *          C = Error signal
   *          D = Integrator
   *          E = 
   *          F = 
   *          G = 
   *          H = Loop control 1 pipeline (to ao OMSL)
   *          K = Loop control 2 pipeline (to ao OMSL)
   */

  double *pIQ = (double *)pasub->a;
  double deadbnd = *(double *)pasub->d;
  double pwrfwd  = *(double *)pasub->f;
  double minfwd  = *(double *)pasub->e;
  double gain_i  = *(double *)pasub->g;
  double gain_p  = *(double *)pasub->o;
  double gain_d  = *(double *)pasub->n;
  long ctrl      = *(uint32_t *)pasub->h;
  long sign      = *(uint32_t *)pasub->i;
  double delta   = *(double *)pasub->j;
  double ctrl_dead = *(double *)pasub->u;

  double prop = 0.0, diff = 0.0;
  double integrator = *(double *)pasub->ovld;
  double speed;
  
  /* Compute probe and forward phases, calculate tuning error */
  double probe_phase, fwd_phase, err;
  double complex z;
  
  z = pIQ[*(long *)pasub->b] - pIQ[*(long *)pasub->b+1]*I;
  probe_phase = carg(z)/M_PI*180.0 + *(double *)pasub->q;
  z = pIQ[*(long *)pasub->s] - pIQ[*(long *)pasub->s+1]*I;
  probe_phase -= carg(z)/M_PI*180.0;
  z = pIQ[*(long *)pasub->p] - pIQ[*(long *)pasub->p+1]*I;
  fwd_phase = carg(z)/M_PI*180.0 + *(double *)pasub->r;
  z = pIQ[*(long *)pasub->t] - pIQ[*(long *)pasub->t+1]*I;
  fwd_phase -= carg(z)/M_PI*180.0;

  err = phase_clip(fwd_phase - probe_phase - *(double *)pasub->c);

  if (pwrfwd < minfwd)
  {
    ctrl  = 0;
  }

  if (err <= -360.0)
    err += 360.0;
  else if (err >= 360.0)
    err -= 360.0;

  if (ctrl == 1)
  {
    if (fabs(err) > deadbnd) /* Need to update tuner loop */
    {
      double sgn = (1.0 - (sign<<1));
      prop        = sgn * err * gain_p;
      diff        = (err - *(double *)pasub->ovlc) * sgn * gain_d;
      integrator += err * sgn * gain_i;
    }
    else
      ctrl_dead = 0.0;
  }
  else
  {
    /* Incremental output mode allows us to reset integrators */
    integrator = 0.0;
  }

  /* Output the new value */
  speed = prop + integrator + diff;

  if (ctrl == 1)
  {
    *(double *)pasub->vala = speed + delta + copysign(ctrl_dead, speed);
    *(double *)pasub->valb = speed - delta + copysign(ctrl_dead, speed);
  }
  else
  {
    *(double *)pasub->vala = *(double *)pasub->valb = 0.0;
  }

  *(double *)pasub->valc = err;
  *(double *)pasub->vald = integrator;
  
  if ((*(double *)pasub->ovla != 0.0) && (ctrl == 0))
    *(char *)pasub->valh = 1;
  else
    *(char *)pasub->valh = ctrl;

  if ((*(double *)pasub->ovlb != 0.0) && (ctrl == 0))
    *(char *)pasub->valk = 1;
  else
    *(char *)pasub->valk = ctrl;
  
#if 0
  printf("%s: fwd=%.1g,err=%.1f,P=%.1g,I=%.1g,D=%.1g,S=%.1f\n",
         pasub->name, pwrfwd, err, prop, integrator, diff, speed);
#endif
  
  return 0;
}

static long subTunerBalanceLoop(aSubRecord *pasub)
{
  /*
   * Input:   A = Probe 2 magnitude
   *          B = Probe 3 (center) magnitude
   *          C = Ratio
   *          D = Deadband (kV)
   *          E = Gain
   *          F = Loop control (0 - off, 1 - on)
   *          G = Sign (0 - 1, 1 - -1)
   *           
   * Outputs: A = Differential drive to subTunerLoop
   *          B = Error value (kV)
   */

  double v2       = *(double *)pasub->a;
  double v3       = *(double *)pasub->b;
  double ratio    = *(double *)pasub->c;
  double deadband = *(double *)pasub->d;
  double gain     = *(double *)pasub->e;
  long ctrl       = *(uint32_t *)pasub->f;
  long sign       = *(uint32_t *)pasub->g;

  double err, step;
  
  err = v2 - v3*ratio;
  
  if (fabs(err) < deadband)
    step = 0.0;
  else
    step = gain * err;

  if (ctrl == 0)
    step = 0.0;
  
  if (sign)
    step = - step;

  *(double *)pasub->vala = step;
  *(double *)pasub->valb = err;

  return 0;
}

static long subTunerLoop_SPEAR3(aSubRecord *pasub)
{
  /*
   * Input:   A = Combined I/Q vector (in sync)
   *          B = Probe index
   *          C = Load angle offset (deg)
   *          D = Deadband (deg)
   *          E = Minimum forward power (kW)
   *          F = Forward magnitude (kW)
   *          G = Integral gain (motor rotational degrees/degree)
   *          H = Loop control (0 - off, 1 - on)
   *          I = Sign (0 - 1, 1 - -1)
   *          J = Differential offsets (UNUSED)
   *          K = Tuner motor 1 readback
   *          L = Tuner motor 2 readback (UNUSED)
   *          M = Anti-windup gain
   *          N = Differential gain
   *          O = Proportional gain
   *          P = Forward index
   *          Q = Probe phase offset
   *          R = Forward phase offset
   *          S = Probe reference index
   *          T = Forward reference index
   *           
   * Outputs: A = Tuner motor 1 position control
   *          B = Tuner motor 2 position control (UNUSED)
   *          C = Error signal
   *          D = Integrator
   *          E = Tuner motor 1 position
   *          F = Tuner motor 2 position (UNUSED)
   *          H = Loop control pipeline (OMSL)
   *        
   */

  double *pIQ = (double *)pasub->a;
  double deadbnd = *(double *)pasub->d;
  double pwrfwd  = *(double *)pasub->f;
  double minfwd  = *(double *)pasub->e;
  double gain_i  = *(double *)pasub->g;
  double gain_p  = *(double *)pasub->o;
  double gain_d  = *(double *)pasub->n;
  double gain_w  = *(double *)pasub->m;
  long ctrl      = *(uint32_t *)pasub->h;
  long sign      = *(uint32_t *)pasub->i;
  double rbv     = *(double *)pasub->k;
  double old_pos = *(double *)pasub->ovla;
  long old_ctrl  = *(char *)pasub->ovlh;

  double prop = 0.0, diff = 0.0;
  double integrator = *(double *)pasub->ovld;

  /* Compute probe and forward phases, calculate tuning error */
  double probe_phase, fwd_phase, err, antiwindup;
  double complex z;
  
  z = pIQ[*(long *)pasub->b] - pIQ[*(long *)pasub->b+1]*I;
  probe_phase = carg(z)/M_PI*180.0 + *(double *)pasub->q;
  z = pIQ[*(long *)pasub->s] - pIQ[*(long *)pasub->s+1]*I;
  probe_phase -= carg(z)/M_PI*180.0;
  z = pIQ[*(long *)pasub->p] - pIQ[*(long *)pasub->p+1]*I;
  fwd_phase = carg(z)/M_PI*180.0 + *(double *)pasub->r;
  z = pIQ[*(long *)pasub->t] - pIQ[*(long *)pasub->t+1]*I;
  fwd_phase -= carg(z)/M_PI*180.0;

  err = phase_clip(fwd_phase - probe_phase - *(double *)pasub->c);

  if (pwrfwd < minfwd)
    ctrl  = 0;

  if (err <= -360.0)
    err += 360.0;
  else if (err >= 360.0)
    err -= 360.0;

  if (ctrl == 1)
  {
    if (fabs(err) > deadbnd) /* Need to update tuner loop */
    {
      double sgn = (1.0 - (sign<<1));
      prop        = sgn * err * gain_p;
      diff        = (err - *(double *)pasub->ovlc) * sgn * gain_d;
      integrator += err * sgn * gain_i;
      antiwindup  = gain_w * (old_pos - rbv);
      integrator -= antiwindup;
    }
  }
  else
  {
    /* Incremental output mode allows us to reset integrators */
    integrator = 0.0;
  }

  /* Output the new control value */
  *(double *)pasub->vale = prop + integrator + diff;

  if (ctrl == 1)
    /* Drive the motor, incremental output */
    *(double *)pasub->vala = *(double *)pasub->vale;
  else
   *(double *)pasub->vala = 0.0;

  *(double *)pasub->valc = err;
  *(double *)pasub->vald = integrator;
  
  /* Control pipeline */
  *(char *)pasub->valh = ctrl;

#if 0
  printf("%s: fwd=%.1f, err=%.1f, prop=%.1f, int=%.1f, diff=%.1f, gain_i=%.1f\n",
         pasub->name, pwrfwd, err, prop, integrator, diff, gain_i);
#endif
  
  return 0;
}

static registryFunctionRef subTunerRef[] = {
  {"subTunerLoop_motorRecord", (REGISTRYFUNCTION)subTunerLoop_motorRecord},
  {"subTunerLoop_DLSB", (REGISTRYFUNCTION)subTunerLoop_DLSB},
  {"subTunerLoop_ANKA", (REGISTRYFUNCTION)subTunerLoop_ANKA},
  {"subTunerLoop_Velocity", (REGISTRYFUNCTION)subTunerLoop_Velocity},
  {"subTunerLoop_SPEAR3", (REGISTRYFUNCTION)subTunerLoop_SPEAR3},
  {"subTunerBalanceLoop", (REGISTRYFUNCTION)subTunerBalanceLoop}
};

static void subTunerRegistrar(void)
{
  registryFunctionRefAdd(subTunerRef, NELEMENTS(subTunerRef));
}
epicsExportRegistrar(subTunerRegistrar);
