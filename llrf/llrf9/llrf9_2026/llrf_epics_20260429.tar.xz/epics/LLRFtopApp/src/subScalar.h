/*
 Scalar synchronization structures and constants
 
 Copyright (c) 2023 Dimtel, Inc., All Rights Reserved

 $Id: subScalar.h,v 1.1 2025/11/07 18:12:53 dim Exp $
 $Date: 2025/11/07 18:12:53 $
 $Author: dim $
 $Revision: 1.1 $
 $Log: subScalar.h,v $
 Revision 1.1  2025/11/07 18:12:53  dim
 Initial commit


*/

#ifndef _SUBSCALAR_H_
#define _SUBSCALAR_H_

#include <pthread.h>

#define BRD_COUNT	3
#define CHAN_COUNT	5
#define SCALAR_N	4
#define TS_WRAP		16

/* Polling period, 50 ms */
#define T_WAIT		50000

typedef struct setptr
{
  unsigned int p : 2;
} setptr;

struct i_q
{
  int32_t _I;
  int32_t _Q;
};

struct i_q_double
{
  double _I;
  double _Q;
};

typedef struct i_q_ts
{
  struct i_q iq[CHAN_COUNT];
  int32_t ts;
} i_q_ts;

typedef struct all_i_q_ts
{
  struct i_q_double iq[CHAN_COUNT*BRD_COUNT];
  double ts;
} all_i_q_ts;

typedef struct async_comm
{
  void            *pasub;
  int             rc; /* Return value after processing */
  pthread_mutex_t mutex;
  pthread_cond_t  cond;
  
  int             trigger;
} async_comm;

enum async_trigger_state {
  ASYNC_IDLE,
  ASYNC_TRIGGER,
  ASYNC_DONE
};

typedef enum sync_state {
  SYNC_IDLE,
  SYNC_CAPTURE,
  SYNC_COPY,
  SYNC_PROCESS
} sync_state;

#endif /* _SUBSCALAR_H_ */
