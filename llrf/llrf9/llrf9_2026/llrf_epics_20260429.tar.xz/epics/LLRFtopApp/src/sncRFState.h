/* === Constants === */
#define MAX_NUM_CAV 4
#define RAMP_LEN    512

/* === setpoint setting/ramping === */
#define V_EPSILON 0.5 /* Typically kV */
#define P_EPSILON 0.5 /* Degrees */

/* Interlock reset delay time */
#define INTERLOCK_RESET_DELAY 0.5

/* Vector sum tracking loop update period */
#define TRACK_DELAY 0.1

/* Ramp generating macro */
#define RAMP_GEN(ramp, in)	for(k=0;k<RAMP_LEN;k++){ramp[k]=in;} pvPut(ramp);

/* === States === */
#define STATE_INITIAL 		0
#define STATE_OFF		1
#define STATE_OL_TUNE		2
#define STATE_INTERLOCK_RESET	3
#define STATE_TUNING		4
#define STATE_LOOP_CLOSE	5
#define STATE_RAMPING		6
#define STATE_TMO_OFF		7
#define STATE_ON		8
#define STATE_WINDOW_TOP	9
#define STATE_WINDOW_CROSS	10
#define STATE_RAMPDOWN		12
#define STATE_TRACK		13
#define STATE_BOOSTER		14
#define STATE_BOOSTER_UPDATE	15

/* === Messages === */
#define MSG_INITIAL		"Initial IOC startup (%d cavit%s)"
#define MSG_RST_INTERLOCK	"Resetting interlock"
#define MSG_TURNING_ON_OL	"Turning on open-loop for cavity tuning"
#define MSG_INTERLOCK_TRIP	"Interlock trip at %.0f %s"
#define MSG_TUNING		"Tuning at %.0f %2s"
#define MSG_SETPT_TIMEOUT	"Timeout, set %.0f %s, reached %.0f %s"
#define MSG_TURN_ON_ABORT	"Turn-on sequence aborted by user"
#define MSG_RST_INTERLOCK_COUNT	"Resetting, rst_count=%d, rst_max=%d"
#define MSG_RST_COMPLETE	"Clock sync & interlock reset complete"
#define MSG_RST_INTERLOCK_TMO	"Interlock reset timed out"
#define MSG_TUNED		"Tuned to %.1f deg"
#define MSG_TUNING_TIMEOUT	"Tuning timeout, err=%.1f deg"
#define MSG_LOOP_CLOSED		"Loop closed, ramping up"
#define MSG_RAMP_DONE		"Reached %.0f %s, %.1f deg"
#define MSG_SETPT_UPDATE	"Updating setpoint to %.0f %s, %.1f deg"
#define MSG_TURNING_OFF		"Turning off"
#define MSG_TURNING_OFF_SLOW	"Turning off with slow window"
#define MSG_SET_TO_ZERO		"Station is at zero setpoint"
#define MSG_IN_WINDOW		"In voltage window"
#define MSG_BELOW_WINDOW	"Below voltage window"
#define MSG_STATION_OFF		"Station turned off, field loop open"
#define MSG_SP_SERVO		"Vector sum tracking: %.0f %s, %.1f deg"
#define MSG_BOOSTER		"Ramp profiles loaded, external trigger"
#define MSG_INTERLOCK_TRIP_BO	"Interlock trip in booster mode"
#define MSG_BO_UPDATE		"Updating ramp profile"
