subScalar.o: ../subScalar.c /opt/epics/base/include/dbDefs.h \
 /opt/epics/base/include/registryFunction.h \
 /opt/epics/base/include/shareLib.h /opt/epics/base/include/subRecord.h \
 /opt/epics/base/include/epicsTypes.h /opt/epics/base/include/link.h \
 /opt/epics/base/include/dbDefs.h /opt/epics/base/include/epicsMutex.h \
 /opt/epics/base/include/epicsAssert.h \
 /opt/epics/base/include/os/Linux/osdMutex.h \
 /opt/epics/base/include/ellLib.h /opt/epics/base/include/epicsTime.h \
 /opt/epics/base/include/os/Linux/osdTime.h \
 /opt/epics/base/include/aSubRecord.h \
 /opt/epics/base/include/epicsExport.h /opt/epics/base/include/shareLib.h \
 /opt/epics/base/include/epicsThread.h \
 /opt/epics/base/include/os/Linux/osdThread.h \
 /opt/epics/base/include/dbAccess.h /opt/epics/base/include/caeventmask.h \
 /opt/epics/base/include/dbFldTypes.h /opt/epics/base/include/dbBase.h \
 /opt/epics/base/include/dbAddr.h /opt/epics/base/include/dbLock.h \
 /opt/epics/base/include/dbAccessDefs.h /opt/epics/base/include/errMdef.h \
 /opt/epics/base/include/dbCa.h /opt/epics/base/include/dbCommon.h \
 /opt/epics/base/include/db_field_log.h /opt/epics/base/include/recSup.h \
 ../subScalar.h ../../../LLRFhwApp/src/cmath.h \
 ../../../LLRFhwApp/src/map.h ../../../LLRFhwApp/src/LLRFhw.h
