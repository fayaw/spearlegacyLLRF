# 0 "../sncRFState.st"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "../sncRFState.st"
# 37 "../sncRFState.st"
program sncRFState

%%#include <stdlib.h>
%%#include <math.h>
%%#include <complex.h>
%%#include "cmath.h"
# 1 "../sncRFState.h" 1
# 44 "../sncRFState.st" 2


%{

static int tuner_error_in_range(double *err, int numcav, double error_range)
{
  int rc = 1, cav;

  for (cav = 0; cav < numcav; cav++)
  {
    if (fabs(err[cav]) >= error_range)
    {
      rc = 0;
      break;
    }
  }
  return rc;
}


static double max_tuner_error(double *err, int numcav)
{
  int cav;
  double max_err = 0.0;

  for (cav = 0; cav < numcav; cav++)
  {
    double aerr = fabs(err[cav]);
    if (aerr > max_err)
      max_err = aerr;
  }
  return max_err;
}

}%




int interlock;
assign interlock to "{sys}:ILOCK:ALL";
monitor interlock;


double err[4];
assign err to {};


double error_range;
assign error_range to "{sys}:STATE:ST{stn}:TUNE_LIMIT";
monitor error_range;


double timeout;
assign timeout to "{sys}:STATE:ST{stn}:TIMEOUT";
monitor timeout;


double vset_mon;
assign vset_mon to "{sys}:BRD{stn}:SETPT:AMP";
monitor vset_mon;

double pset_mon;
assign pset_mon to "{sys}:BRD{stn}:SETPT:PHASE";
monitor pset_mon;


double max_vset_step, max_pset_step;
assign max_vset_step to "{sys}:BRD{stn}:RAMP:AMPRATE";
assign max_pset_step to "{sys}:BRD{stn}:RAMP:PHASERATE";
monitor max_vset_step; monitor max_pset_step;


int turn_on;
assign turn_on to "{sys}:STATE:ST{stn}:TURN_ON";
monitor turn_on;


int turn_off;
assign turn_off to "{sys}:STATE:ST{stn}:TURN_OFF";
monitor turn_off;


double vset_goal;
assign vset_goal to "{sys}:STATE:ST{stn}:VSET_GOAL";
monitor vset_goal;


double pset_goal;
assign pset_goal to "{sys}:STATE:ST{stn}:PSET_GOAL";
monitor pset_goal;


double vset_ol;
assign vset_ol to "{sys}:STATE:ST{stn}:VSET_OL";
monitor vset_ol;


string vset_egu;
assign vset_egu to "{sys}:STATE:ST{stn}:VSET_OL.EGU";
monitor vset_egu;


double vset_off[2];
assign vset_off[0] to "{sys}:STATE:ST{stn}:VSET_OFF1";
assign vset_off[1] to "{sys}:STATE:ST{stn}:VSET_OFF2";
monitor vset_off;


int dw_enable;
assign dw_enable to "{sys}:STATE:ST{stn}:DW_EN";
monitor dw_enable;


int sp_track;
assign sp_track to "{sys}:STATE:ST{stn}:SP_TRACK";
monitor sp_track;


double gain, loop_deadband;
assign loop_deadband to "{sys}:STATE:ST{stn}:DEADBAND";
assign gain to "{sys}:STATE:ST{stn}:GAIN";
monitor loop_deadband; monitor gain;


double vst, pst;
assign vst to "";
assign pst to "";


double vset[2];
assign vset[0] to "{sys}:BRD{stn}:RAMP:ASTART";
assign vset[1] to "{sys}:BRD{stn}:RAMP:AEND";

double pset[2];
assign pset[0] to "{sys}:BRD{stn}:RAMP:PH_BASE";
assign pset[1] to "{sys}:BRD{stn}:RAMP:PH_DELTA";

double vcurr, dump_rate;
assign dump_rate to "{sys}:STATE:ST{stn}:DUMP_RATE";
monitor dump_rate;

int vset_load;
assign vset_load to "{sys}:BRD{stn}:RAMP:LOAD";
monitor vset_load;

int interlock_reset;
assign interlock_reset to "{sys}:ILOCK:RESET";

int clock_sync;
assign clock_sync to "{sys}:CLOCKS:SYNC";

int loop_ctrl;
assign loop_ctrl to "{sys}:BRD{stn}:FB:CTRL";
monitor loop_ctrl;

int bo_ctrl;
assign bo_ctrl to "{sys}:STATE:ST{stn}:BOOSTER";
monitor bo_ctrl;

int trig_en;
assign trig_en to "{sys}:BRD{stn}:RAMP:TRIGEN";

double booster_amp[512], booster_phase[512];
assign booster_amp to "{sys}:STATE:ST{stn}:BO:AMP";
assign booster_phase to "{sys}:STATE:ST{stn}:BO:PHASE";
monitor booster_amp;
monitor booster_phase;

double ramp_amp[512], ramp_phase[512];
assign ramp_amp to "{sys}:BRD{stn}:RAMP:AMP";
assign ramp_phase to "{sys}:BRD{stn}:RAMP:PHASE";


string message;
assign message to "{sys}:STATE:ST{stn}:MSG";

int current_state = 0, last_state = 0;
assign current_state to "{sys}:STATE:ST{stn}:CURRENT";
assign last_state to "{sys}:STATE:ST{stn}:LAST";



double vgoal_mon, pgoal_mon;
assign vgoal_mon to "{sys}:STATE:ST{stn}:VTRK";
assign pgoal_mon to "{sys}:STATE:ST{stn}:PTRK";


int k, rst_count, rst_max, num_cav, cav, stn;
char *stn_macro, *cav_macro, *sys_name, chname[64];

typename complex goal, vsum, loop_err;

ss RF_State_Control {
  state INITIAL
  {
    when (1)
    {

      sys_name = macValueGet("sys");
      cav_macro = macValueGet("nc");
      stn_macro = macValueGet("stn");
      num_cav = atoi(cav_macro); stn = atoi(stn_macro);
      for (cav = 0; cav < num_cav; cav++)
      {




         sprintf(chname, "%s:TUNER:C%d:LOOP:ERROR", sys_name, cav+stn);
         pvAssign(err[cav], chname);
         pvMonitor(err[cav]);
      }
      if (cav == 1)
      {
         sprintf(chname, "%s:VC%d:MAG", sys_name, stn);
         pvAssign(vst, chname);
         sprintf(chname, "%s:VC%d:PHASE", sys_name, stn);
         pvAssign(pst, chname);
      }
      else
      {
         sprintf(chname, "%s:VST:MAG", sys_name);
         pvAssign(vst, chname);
         sprintf(chname, "%s:VST:PHASE", sys_name);
         pvAssign(pst, chname);
      }
      pvMonitor(pst); pvMonitor(vst);
      sprintf(message, "Initial IOC startup (%d cavit%s)", num_cav, (num_cav==1)?"y":"ies");
      pvPut(message);
    } state OFF
  }
  state OFF
  {
    entry
    {
      last_state = current_state; current_state = 1;
      pvPut(last_state); pvPut(current_state);
    }
    when (turn_on && interlock)
    {

      clock_sync = 1; pvPut(clock_sync);
      loop_ctrl = 0; pvPut(loop_ctrl);
      sprintf(message, "Resetting interlock"); pvPut(message);
      rst_max = (int)(timeout/0.5+0.5);
      rst_count = 0;
    } state INTERLOCK_RESET
    when (turn_on && (interlock == 0))
    {
      sprintf(message, "Turning on open-loop for cavity tuning"); pvPut(message);
      loop_ctrl = 0; pvPut(loop_ctrl);
      vset[0] = vset[1] = vset_ol; pvPut(vset[0]); pvPut(vset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      vset_load = 1; pvPut(vset_load);
    } state OL_TUNE
    when (turn_off)
    {
      turn_off = 0; pvPut(turn_off);
    } state OFF
  }
  state OL_TUNE
  {
    entry
    {
      last_state = current_state; current_state = 2;
      pvPut(last_state); pvPut(current_state);
    }
    when (interlock)
    {
      sprintf(message, "Interlock trip at %.0f %s", vset_mon, vset_egu); pvPut(message);
      turn_on = 0; pvPut(turn_on);
    } state OFF
    when (fabs(vset_mon - vset[0]) < 0.5)
    {
      sprintf(message, "Tuning at %.0f %2s", vset_mon, vset_egu); pvPut(message);
    } state TUNING
    when (delay(timeout))
    {
      sprintf(message, "Timeout, set %.0f %s, reached %.0f %s",
              vset[0], vset_egu, vset_mon, vset_egu); pvPut(message);
      vset[0] = vset[1] = 0.0; pvPut(vset[0]); pvPut(vset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      vset_load = 1; pvPut(vset_load);
      turn_on = 0; pvPut(turn_on);
      turn_off = 1; pvPut(turn_off);
    } state TMO_OFF
    when (turn_off)
    {
      sprintf(message, "Turn-on sequence aborted by user"); pvPut(message);
      turn_on = 0; pvPut(turn_on);
    } state RAMPDOWN
  }
  state INTERLOCK_RESET
  {
    entry
    {
      last_state = current_state; current_state = 3;
      pvPut(last_state); pvPut(current_state);
    }

    when (delay(0.5))
    {
      interlock_reset = 1; pvPut(interlock_reset);
      rst_count++;
      rst_max = (int)(timeout/0.5 + 0.5);
      sprintf(message, "Resetting, rst_count=%d, rst_max=%d", rst_count, rst_max);
      pvPut(message);
    } state INTERLOCK_RESET
    when (interlock == 0)
    {
      vset[0] = vset[1] = vset_ol; pvPut(vset[0]); pvPut(vset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      vset_load = 1; pvPut(vset_load);

      sprintf(message, "Clock sync & interlock reset complete"); pvPut(message);
    } state OL_TUNE
    when (rst_count >= rst_max)
    {
      sprintf(message, "Interlock reset timed out"); pvPut(message);
      turn_on = 0; pvPut(turn_on);
    } state OFF
    when (turn_off)
    {
      sprintf(message, "Turn-on sequence aborted by user"); pvPut(message);
      turn_on = 0; pvPut(turn_on);
      turn_off = 0; pvPut(turn_off);
    } state OFF
  }
  state TUNING
  {
    entry
    {
      last_state = current_state; current_state = 4;
      pvPut(last_state); pvPut(current_state);
    }
    when (interlock)
    {
      sprintf(message, "Interlock trip at %.0f %s", vset_mon, vset_egu); pvPut(message);
      turn_on = 0; pvPut(turn_on);
    } state OFF
    when (tuner_error_in_range(err, num_cav, error_range))
    {
      vset[0] = vset[1] = 0.0; pvPut(vset[0]); pvPut(vset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      vset_load = 1; pvPut(vset_load);
      sprintf(message, "Tuned to %.1f deg", max_tuner_error(err, num_cav));
      pvPut(message);
    } state LOOP_CLOSE
    when (delay(timeout))
    {
      sprintf(message, "Tuning timeout, err=%.1f deg", max_tuner_error(err, num_cav));
      pvPut(message);
      vset[0] = vset[1] = 0.0; pvPut(vset[0]); pvPut(vset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      vset_load = 1; pvPut(vset_load);
      turn_on = 0; pvPut(turn_on);
      turn_off = 1; pvPut(turn_off);
    } state TMO_OFF
    when (turn_off)
    {
      sprintf(message, "Turn-on sequence aborted by user"); pvPut(message);
      turn_on = 0; pvPut(turn_on);
    } state RAMPDOWN
  }
  state LOOP_CLOSE
  {
    entry
    {
      last_state = current_state; current_state = 5;
      pvPut(last_state); pvPut(current_state);
    }
    when (interlock)
    {
      sprintf(message, "Interlock trip at %.0f %s", vset_mon, vset_egu); pvPut(message);
      turn_on = 0; pvPut(turn_on);
    } state OFF
    when (vset_mon == 0.0)
    {
      loop_ctrl = 1; pvPut(loop_ctrl);
      vset[0] = vset[1] = vset_goal; pvPut(vset[0]); pvPut(vset[1]);
      pset[0] = pset_goal; pset[1] = 0.0; pvPut(pset[0]); pvPut(pset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      for(k=0;k<512;k++){ramp_phase[k]=pset[0];} pvPut(ramp_phase);;
      vset_load = 1; pvPut(vset_load);
      sprintf(message, "Loop closed, ramping up"); pvPut(message);
    } state RAMPING
    when (delay(timeout))
    {
      sprintf(message, "Timeout, set %.0f %s, reached %.0f %s",
              vset[0], vset_egu, vset_mon, vset_egu); pvPut(message);
      turn_on = 0; pvPut(turn_on);
    } state OFF
    when (turn_off)
    {
      sprintf(message, "Turn-on sequence aborted by user"); pvPut(message);
      turn_on = 0; pvPut(turn_on);
      turn_off = 0; pvPut(turn_off);
    } state OFF
  }
  state RAMPING
  {
    entry
    {
      last_state = current_state; current_state = 6;
      pvPut(last_state); pvPut(current_state);
    }
    when (interlock)
    {
      sprintf(message, "Interlock trip at %.0f %s", vset_mon, vset_egu); pvPut(message);
      turn_on = 0; pvPut(turn_on);
    } state OFF
    when (fabs(vset_mon-vset[0]) < 0.5 &&
          fabs(pset_mon-pset[0]) < 0.5)
    {
      sprintf(message, "Reached %.0f %s, %.1f deg", vset_mon, vset_egu, pset_mon);
      pvPut(message);
      turn_on = 0; pvPut(turn_on);
    } state ON
    when (delay(timeout))
    {
      sprintf(message, "Timeout, set %.0f %s, reached %.0f %s",
              vset[0], vset_egu, vset_mon, vset_egu); pvPut(message);
      vset[0] = vset[1] = 0.0; pvPut(vset[0]); pvPut(vset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      vset_load = 1; pvPut(vset_load);
      turn_on = 0; pvPut(turn_on);
      turn_off = 1; pvPut(turn_off);
    } state TMO_OFF
    when (turn_off)
    {
      sprintf(message, "Turn-on sequence aborted by user"); pvPut(message);
      turn_on = 0; pvPut(turn_on);
    } state RAMPDOWN
  }
  state TMO_OFF
  {
    entry
    {
      last_state = current_state; current_state = 7;
      pvPut(last_state); pvPut(current_state);
    }
    when (interlock)
    {
      sprintf(message, "Interlock trip at %.0f %s", vset_mon, vset_egu); pvPut(message);
      turn_on = 0; pvPut(turn_on);
      turn_off = 0; pvPut(turn_off);
    } state OFF
    when (delay(30.0) || vset_mon == 0.0)
    {

      loop_ctrl = 0; pvPut(loop_ctrl);
      turn_on = 0; pvPut(turn_on);
      turn_off = 0; pvPut(turn_off);
    } state OFF
  }
  state ON
  {
    entry
    {
      last_state = current_state; current_state = 8;
      pvPut(last_state); pvPut(current_state);
    }
    when (interlock)
    {
      sprintf(message, "Interlock trip at %.0f %s", vset_mon, vset_egu); pvPut(message);
    } state OFF
    when (sp_track)
    {
      sprintf(message, "Vector sum tracking: %.0f %s, %.1f deg", vset_goal, vset_egu, pset_goal);
      pvPut(message);
      goal = vset_goal * cexp_loc(I*M_PI*pset_goal/180.0);
      vgoal_mon = vset_goal; pvPut(vgoal_mon);
      pgoal_mon = pset_goal; pvPut(pgoal_mon);
    } state TRACK
    when (bo_ctrl)
    {
      sprintf(message, "Ramp profiles loaded, external trigger");
      pvPut(message);
      for (k = 0; k < 512; k++)
      {
        ramp_amp[k] = booster_amp[k];
        ramp_phase[k] = booster_phase[k];
      }
      pvPut(ramp_amp); pvPut(ramp_phase);
      vset_load = 1; pvPut(vset_load);
      trig_en = 1; pvPut(trig_en);
    } state BOOSTER
    when (turn_on)
    {
      sprintf(message, "Updating setpoint to %.0f %s, %.1f deg", vset_goal, vset_egu, pset_goal);
      pvPut(message);
      vset[0] = vset[1] = vset_goal; pvPut(vset[0]); pvPut(vset[1]);
      pset[0] = pset_goal; pset[1] = 0.0; pvPut(pset[0]); pvPut(pset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      for(k=0;k<512;k++){ramp_phase[k]=pset[0];} pvPut(ramp_phase);;
      vset_load = 1; pvPut(vset_load);
    } state RAMPING
    when (turn_off == 1 && ((dw_enable == 0)||(vset_mon < vset_off[0])))
    {
      sprintf(message, "Turning off"); pvPut(message);
    } state RAMPDOWN
    when (turn_off == 1 && dw_enable && (vset_mon > vset_off[0]))
    {
      sprintf(message, "Turning off with slow window"); pvPut(message);
      vset[0] = vset[1] = vset_off[0]; pvPut(vset[0]); pvPut(vset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      vset_load = 1; pvPut(vset_load);
    } state WINDOW_TOP
    when (vset_mon == 0.0)
    {
      sprintf(message, "Station is at zero setpoint"); pvPut(message);
    } state OFF
  }
  state TRACK
  {
    entry
    {
      last_state = current_state; current_state = 13;
      pvPut(last_state); pvPut(current_state);
    }
    when (interlock)
    {
      sprintf(message, "Interlock trip at %.0f %s", vset_mon, vset_egu); pvPut(message);
    } state OFF
    when (turn_on)
    {
      sprintf(message, "Vector sum tracking: %.0f %s, %.1f deg", vset_goal, vset_egu, pset_goal);
      pvPut(message);
      goal = vset_goal * cexp_loc(I*M_PI*pset_goal/180.0);
      vgoal_mon = vset_goal; pvPut(vgoal_mon);
      pgoal_mon = pset_goal; pvPut(pgoal_mon);
      turn_on = 0; pvPut(turn_on);
    } state TRACK
    when (turn_off == 1 && ((dw_enable == 0)||(vset_mon < vset_off[0])))
    {
      sprintf(message, "Turning off"); pvPut(message);
    } state RAMPDOWN
    when (turn_off == 1 && dw_enable && (vset_mon > vset_off[0]))
    {
      sprintf(message, "Turning off with slow window"); pvPut(message);
      vset[0] = vset[1] = vset_off[0]; pvPut(vset[0]); pvPut(vset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      vset_load = 1; pvPut(vset_load);
    } state WINDOW_TOP
    when (vset_mon == 0.0)
    {
      sprintf(message, "Station is at zero setpoint"); pvPut(message);
    } state OFF
    when (sp_track == 0)
    {
      sprintf(message, "Updating setpoint to %.0f %s, %.1f deg", vset_goal, vset_egu, pset_goal);
      pvPut(message);
      vset[0] = vset[1] = vset_goal; pvPut(vset[0]); pvPut(vset[1]);
      pset[0] = pset_goal; pset[1] = 0.0; pvPut(pset[0]); pvPut(pset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      for(k=0;k<512;k++){ramp_phase[k]=pset[0];} pvPut(ramp_phase);;
      vset_load = 1; pvPut(vset_load);
    } state RAMPING
    when (delay(0.1))
    {
      vsum = vst * cexp_loc(I*M_PI*pst/180.0);
      loop_err = goal - vsum;
      if (vset_load == 0 && (cabs(loop_err) > loop_deadband))
      {


        vset[0] += gain * (cabs(goal) - vst);
        vset[1] = vset[0];



        pset[0] += gain * (carg(goal)/M_PI*180.0 - pst); pset[1] = 0.0;
        for (k = 0; k < 2; k++)
        {
          pvPut(vset[k]);
          pvPut(pset[k]);
        }

        for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
        for(k=0;k<512;k++){ramp_phase[k]=pset[0];} pvPut(ramp_phase);;
        vset_load = 1;
      }

      if (vset_load)
        pvPut(vset_load);
    } state TRACK
  }
  state BOOSTER
  {
    entry
    {
      last_state = current_state; current_state = 14;
      pvPut(last_state); pvPut(current_state);
    }
    when (interlock)
    {
      sprintf(message, "Interlock trip in booster mode"); pvPut(message);
    } state OFF
    when (turn_on)
    {
      sprintf(message, "Updating ramp profile");
      pvPut(message);
      for (k = 0; k < 512; k++)
      {
        ramp_amp[k] = booster_amp[k];
        ramp_phase[k] = booster_phase[k];
      }
      pvPut(ramp_amp); pvPut(ramp_phase);
      vset_load = 1; pvPut(vset_load);
    } state BOOSTER_UPDATE
    when (turn_off == 1 && ((dw_enable == 0)||(vset_mon < vset_off[0])))
    {
      sprintf(message, "Turning off"); pvPut(message);
      trig_en = 0; pvPut(trig_en);
    } state RAMPDOWN
    when (turn_off == 1 && dw_enable && (vset_mon > vset_off[0]))
    {
      sprintf(message, "Turning off with slow window"); pvPut(message);
      trig_en = 0; pvPut(trig_en);
      vset[0] = vset[1] = vset_off[0]; pvPut(vset[0]); pvPut(vset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      vset_load = 1; pvPut(vset_load);
    } state WINDOW_TOP
  }
  state BOOSTER_UPDATE
  {
    entry
    {
      last_state = current_state; current_state = 15;
      pvPut(last_state); pvPut(current_state);
    }
    when(1)
    {
      sprintf(message, "Ramp profiles loaded, external trigger");
      pvPut(message);
      turn_on = 0; pvPut(turn_on);
    } state BOOSTER
  }
  state WINDOW_TOP
  {
    entry
    {
      last_state = current_state; current_state = 9;
      pvPut(last_state); pvPut(current_state);
    }
    when (interlock)
    {
      sprintf(message, "Interlock trip at %.0f %s", vset_mon, vset_egu); pvPut(message);
      turn_off = 0; pvPut(turn_off);
    } state OFF
    when (fabs(vset_mon - vset[0]) < 0.5)
    {
      sprintf(message, "In voltage window"); pvPut(message);
      vcurr = vset_off[0];
    } state WINDOW_CROSS
  }
  state WINDOW_CROSS
  {
    entry
    {
      last_state = current_state; current_state = 10;
      pvPut(last_state); pvPut(current_state);
    }
    when (interlock)
    {
      sprintf(message, "Interlock trip at %.0f %s", vset_mon, vset_egu); pvPut(message);
      turn_off = 0; pvPut(turn_off);
    } state OFF
    when (vcurr <= vset_off[1])
    {
      sprintf(message, "Below voltage window"); pvPut(message);
    } state RAMPDOWN
    when (delay(0.25))
    {
      vcurr -= dump_rate/4;
      vset[0] = vset[1] = vcurr; pvPut(vset[0]); pvPut(vset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      vset_load = 1; pvPut(vset_load);
    } state WINDOW_CROSS
  }
  state RAMPDOWN
  {
    entry
    {
      last_state = current_state; current_state = 12;
      pvPut(last_state); pvPut(current_state);
      vset[0] = vset[1] = 0.0; pvPut(vset[0]); pvPut(vset[1]);

      for(k=0;k<512;k++){ramp_amp[k]=vset[0];} pvPut(ramp_amp);;
      vset_load = 1; pvPut(vset_load);
    }
    when (interlock)
    {
      sprintf(message, "Interlock trip at %.0f %s", vset_mon, vset_egu); pvPut(message);
      turn_off = 0; pvPut(turn_off);
    } state OFF
    when (vset_mon == 0.0)
    {
      sprintf(message, "Station turned off, field loop open"); pvPut(message);
      loop_ctrl = 0; pvPut(loop_ctrl);
      turn_off = 0; pvPut(turn_off);
    } state OFF
    when (delay(timeout))
    {
      sprintf(message, "Timeout, set %.0f %s, reached %.0f %s",
              vset[0], vset_egu, vset_mon, vset_egu); pvPut(message);
    } state TMO_OFF
  }
}
