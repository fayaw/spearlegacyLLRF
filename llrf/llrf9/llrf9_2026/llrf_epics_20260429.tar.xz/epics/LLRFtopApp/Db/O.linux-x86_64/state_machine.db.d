# DO NOT EDIT: This file created by mkmf.pl,v 1.5 2002/03/25 21:33:24 jba Exp $ 



../O.Common/state_machine.db : ../state_machine.template
state_machine.db.d: ../state_machine.template
