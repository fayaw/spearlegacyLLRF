# DO NOT EDIT: This file created by mkmf.pl,v 1.5 2002/03/25 21:33:24 jba Exp $ 



../O.Common/power_meter.db : ../power_meter.template
power_meter.db.d: ../power_meter.template
