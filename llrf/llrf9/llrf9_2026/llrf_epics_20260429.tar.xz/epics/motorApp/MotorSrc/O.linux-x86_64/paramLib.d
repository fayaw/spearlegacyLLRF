paramLib.o: ../paramLib.c /opt/epics/base/include/shareLib.h \
 ../paramLib.h
