motorUtil.o: ../motorUtil.cc /opt/epics/base/include/cadef.h \
 /opt/epics/base/include/epicsThread.h /opt/epics/base/include/shareLib.h \
 /opt/epics/base/include/epicsEvent.h \
 /opt/epics/base/include/epicsAssert.h \
 /opt/epics/base/include/os/Linux/osdEvent.h \
 /opt/epics/base/include/epicsMutex.h \
 /opt/epics/base/include/compilerDependencies.h \
 /opt/epics/base/include/os/Linux/osdMutex.h \
 /opt/epics/base/include/os/Linux/osdThread.h \
 /opt/epics/base/include/shareLib.h /opt/epics/base/include/caerr.h \
 /opt/epics/base/include/epicsTypes.h /opt/epics/base/include/db_access.h \
 /opt/epics/base/include/epicsTime.h \
 /opt/epics/base/include/os/Linux/osdTime.h \
 /opt/epics/base/include/caeventmask.h /opt/epics/base/include/dbDefs.h \
 /opt/epics/base/include/epicsString.h \
 /opt/epics/base/include/cantProceed.h /opt/epics/base/include/iocsh.h \
 /opt/epics/base/include/epicsExport.h /opt/epics/base/include/errlog.h \
 ../motor.h /opt/epics/base/include/dbScan.h \
 /opt/epics/base/include/menuScan.h /opt/epics/base/include/devSup.h \
 /opt/epics/base/include/errMdef.h \
 /opt/epics/base/include/os/Linux/osiUnistd.h \
 /opt/epics/base/include/epicsVersion.h \
 /opt/epics/base/include/epicsEndian.h \
 /opt/epics/base/include/os/Linux/osdWireConfig.h
