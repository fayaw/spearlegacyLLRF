motordrvCom.o: ../motordrvCom.cc /opt/epics/base/include/callback.h \
 /opt/epics/base/include/shareLib.h /opt/epics/base/include/epicsThread.h \
 /opt/epics/base/include/epicsEvent.h \
 /opt/epics/base/include/epicsAssert.h \
 /opt/epics/base/include/os/Linux/osdEvent.h \
 /opt/epics/base/include/epicsMutex.h \
 /opt/epics/base/include/compilerDependencies.h \
 /opt/epics/base/include/os/Linux/osdMutex.h \
 /opt/epics/base/include/os/Linux/osdThread.h \
 /opt/epics/base/include/shareLib.h /opt/epics/base/include/epicsExport.h \
 ../motor.h /opt/epics/base/include/dbScan.h \
 /opt/epics/base/include/menuScan.h /opt/epics/base/include/devSup.h \
 /opt/epics/base/include/errMdef.h \
 /opt/epics/base/include/os/Linux/osiUnistd.h \
 /opt/epics/base/include/epicsVersion.h \
 /opt/epics/base/include/epicsEndian.h \
 /opt/epics/base/include/os/Linux/osdWireConfig.h ../motordrvCom.h \
 /opt/epics/base/include/epicsTypes.h \
 /opt/epics/base/include/epicsEvent.h /opt/epics/base/include/epicsTime.h \
 /opt/epics/base/include/epicsTypes.h \
 /opt/epics/base/include/os/Linux/osdTime.h \
 /opt/epics/base/include/epicsMessageQueue.h \
 /opt/epics/base/include/locationException.h \
 /opt/epics/base/include/cantProceed.h /opt/epics/base/include/errlog.h \
 /opt/epics/base/include/os/Linux/osdMessageQueue.h
