# DO NOT EDIT: This file created by mkmf.pl,v 1.5 2002/03/25 21:33:24 jba Exp $ 

../O.Common/motorRecord.h : /opt/epics/base/dbd/menuYesNo.dbd
../O.Common/motorRecord.h : /opt/epics/base/dbd/menuOmsl.dbd
../O.Common/motorRecord.h : /opt/epics/base/dbd/dbCommon.dbd


../O.Common/motorRecord.h : ../Makefile
