motorUtilAux.o: ../motorUtilAux.cc /opt/epics/base/include/cantProceed.h \
 /opt/epics/base/include/shareLib.h /opt/epics/base/include/dbStaticLib.h \
 /opt/epics/base/include/dbFldTypes.h /opt/epics/base/include/dbBase.h \
 /opt/epics/base/include/epicsTypes.h /opt/epics/base/include/ellLib.h \
 /opt/epics/base/include/dbDefs.h /opt/epics/base/include/link.h \
 /opt/epics/base/include/errMdef.h /opt/epics/base/include/cantProceed.h \
 /opt/epics/base/include/errlog.h \
 /opt/epics/base/include/compilerDependencies.h \
 /opt/epics/base/include/dbAccessDefs.h \
 /opt/epics/base/include/epicsTime.h \
 /opt/epics/base/include/os/Linux/osdTime.h
