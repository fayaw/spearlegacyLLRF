asynMotorAxis.o: ../asynMotorAxis.cpp \
 /opt/epics/base/include/epicsThread.h /opt/epics/base/include/shareLib.h \
 /opt/epics/base/include/epicsEvent.h \
 /opt/epics/base/include/epicsAssert.h \
 /opt/epics/base/include/os/Linux/osdEvent.h \
 /opt/epics/base/include/epicsMutex.h \
 /opt/epics/base/include/compilerDependencies.h \
 /opt/epics/base/include/os/Linux/osdMutex.h \
 /opt/epics/base/include/os/Linux/osdThread.h \
 /opt/epics/base/include/shareLib.h \
 ../../../../asyn/include/asynPortDriver.h \
 /opt/epics/base/include/epicsTypes.h \
 /opt/epics/base/include/epicsMutex.h \
 ../../../../asyn/include/asynStandardInterfaces.h \
 ../../../../asyn/include/asynDriver.h \
 /opt/epics/base/include/epicsStdio.h /opt/epics/base/include/epicsTime.h \
 /opt/epics/base/include/epicsTypes.h \
 /opt/epics/base/include/os/Linux/osdTime.h \
 /opt/epics/base/include/ellLib.h \
 ../../../../asyn/include/asynUInt32Digital.h \
 ../../../../asyn/include/asynInt32.h \
 ../../../../asyn/include/asynInt8Array.h \
 ../../../../asyn/include/asynInt16Array.h \
 ../../../../asyn/include/asynInt32Array.h \
 ../../../../asyn/include/asynFloat32Array.h \
 ../../../../asyn/include/asynFloat64.h \
 ../../../../asyn/include/asynFloat64Array.h \
 ../../../../asyn/include/asynGenericPointer.h \
 ../../../../asyn/include/asynEnum.h ../../../../asyn/include/asynOctet.h \
 ../../../../asyn/include/asynDrvUser.h \
 ../../../../asyn/include/asynOption.h \
 ../../../../asyn/include/paramVal.h \
 ../../../../asyn/include/asynParamType.h \
 ../../../../asyn/include/asynDriver.h ../asynMotorAxis.h \
 /opt/epics/base/include/epicsEvent.h ../asynMotorController.h
