motorSimRegister.o: ../motorSimRegister.cc \
 /opt/epics/base/include/iocsh.h /opt/epics/base/include/shareLib.h \
 ../drvMotorSim.h /opt/epics/base/include/epicsExport.h \
 /opt/epics/base/include/shareLib.h
