drvMotorSim.o: ../drvMotorSim.c ../drvMotorSim.h \
 ../../../include/paramLib.h /opt/epics/base/include/shareLib.h \
 /opt/epics/base/include/epicsFindSymbol.h \
 /opt/epics/base/include/shareLib.h /opt/epics/base/include/epicsTime.h \
 /opt/epics/base/include/epicsTypes.h \
 /opt/epics/base/include/os/Linux/osdTime.h \
 /opt/epics/base/include/epicsThread.h \
 /opt/epics/base/include/os/Linux/osdThread.h \
 /opt/epics/base/include/epicsMutex.h \
 /opt/epics/base/include/epicsAssert.h \
 /opt/epics/base/include/os/Linux/osdMutex.h \
 /opt/epics/base/include/ellLib.h /opt/epics/base/include/drvSup.h \
 /opt/epics/base/include/errMdef.h /opt/epics/base/include/epicsExport.h \
 ../../../include/motor_interface.h ../route.h
