/*
=============================================================

  Abs:  restore utils "C" routine prototypes

  Name: restore_utils.h
        dynamic_restore - entry point
	(utility functions -- non-entry points)
	restore_line    - channel name/value read utility function 
	save_file_ok    - save file verfication function
	fopen_macro     - file open wrapper, handles error logging
	fclose_macro    - file close wrapper, handles error logging

  Auth: 01-Oct-2004, James Silva    (JSILVA)
  Rev : 04-Nov-2004, James Silva (jsilva)
         Added version argument to save_file_ok.
-------------------------------------------------------------
  Mod:


=============================================================
*/


#ifndef RESTORE_UTILS_H
#define RESTORE_UTILS_H


int dynamic_restore(char * filename);

int  restore_line(char *filename,FILE *input_fp,int len,char *buffer);

int save_file_ok(char *filename, char *version);  /* prototype for function defined in <save_restore.h> */


#define file_ok_tag     "FILE-WRITES-COMPLETED-SUCCESSFULLY"

#define fopen_macro(routine_name,file_descriptor,file_name,mode) {          \
  if ((file_descriptor = fopen(file_name,mode)) == NULL) {                  \
    epicsPrintf ("%s: unable to open file %s.\n", routine_name, file_name); \
    return (-1);                                                            \
    };                                                                      \
  } /* fopen_macro */


#define fclose_macro(routine_name,file_name,file_descriptor) {        \
  if ((fclose(file_descriptor)) == 0) {                               \
    /* file closed successfully */                                    \
    }                                                                 \
  else {                                                              \
    epicsPrintf ("%s: error closing %s.", routine_name, file_name);   \
    return (-1);                                                      \
    };                                                                \
  } /* fclose_macro */ 


#endif /* RESTORE_UTILS */
