/*
 Complex math
 
 Copyright (c) 2011 Dimtel, Inc., All Rights Reserved

 $Id: cmath.c,v 1.1 2017/03/10 19:44:56 dim Exp $
 $Date: 2017/03/10 19:44:56 $
 $Author: dim $
 $Revision: 1.1 $
 $Log: cmath.c,v $
 Revision 1.1  2017/03/10 19:44:56  dim
 Initial import

*/

#include <math.h>
#include <complex.h>

double creal_loc(complex z)
{
  return __real__ z;
}

double cimag_loc(complex z)
{
  return __imag__ z;
}

complex conj_loc(complex z)
{
  return __extension__ ~z;
}

complex cexp_loc(complex z)
{
  double scale = exp(creal_loc(z));

  return scale*(cos(cimag_loc(z)) + I*sin(cimag_loc(z)));
}

double carg_loc(complex z)
{
  return atan2(cimag_loc(z), creal_loc(z));
}

double phase_clip(double phase_deg)
{
  double rv = phase_deg - 360.0*floor(phase_deg / 360.0);
  
  if (rv >= 180.0)
    rv -= 360.0;

  return rv;
}