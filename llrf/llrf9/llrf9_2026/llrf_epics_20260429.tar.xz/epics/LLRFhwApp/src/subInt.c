/*
 Subroutines for integrator filter control: coefficient generation, transfer
 function calculation, etc.
 
 Copyright (c) 2012-2014 Dimtel, Inc., All Rights Reserved

 $Id: subInt.c,v 1.1 2017/03/10 19:44:56 dim Exp $
 $Date: 2017/03/10 19:44:56 $
 $Author: dim $
 $Revision: 1.1 $
 $Log: subInt.c,v $
 Revision 1.1  2017/03/10 19:44:56  dim
 Initial import

*/

#include   <stdio.h>
#include   <stdlib.h>
#include   <string.h>
#include   <math.h>
#include   <complex.h>

#include   <dbDefs.h>
#include   <registryFunction.h>
#include   <subRecord.h>
#include   <aSubRecord.h>
#include   <epicsExport.h>
#include   <dbAccess.h>

#include   <fftw3.h>

#include   "cmath.h"
#include   "map.h"

/* #define THIRD_ORDER	1 */

typedef long (*processMethod)(subRecord *precord);

static long subIntInit(subRecord *psub, processMethod process)
{
  psub->val = 0;
  return 0;
}

static long subIntGen(aSubRecord *pgsub)
{
  /*
   * Inputs: A - Radius

     Outputs:
             A - Coeffcient A1
  */
  
  double r;
  int a1;

  r       = *(double *)pgsub->a;
  
  a1 = (int)floor(-r*(1<<(INT_COEFF_BITS-1)) + 0.5);

  *(int32_t *)pgsub->vala = a1;

  return 0;
}

static long subIntCopy(aSubRecord *pgsub)
{
  /*
   * Inputs: A - A1
             C - Load
             D - Set select, 0 - OL, 1 - CL
             E - OL A1
             G - CL A1
     Outputs:
             A - OL A1
             C - CL A1
  */
  int32_t a1, set, load;
  

  a1   = *(int32_t *)pgsub->a;
  load = *(int32_t *)pgsub->c;
  set  = *(int32_t *)pgsub->d;

  /* Copy old values */
  *(int32_t *)pgsub->vala = *(int32_t *)pgsub->e;
  *(int32_t *)pgsub->valc = *(int32_t *)pgsub->g;

  if (load == 0)
    return 0;

  if (set == 0)
    *(int32_t *)pgsub->vala = a1;
  else
    *(int32_t *)pgsub->valc = a1;

  return 0;
}

/* Compute IIR filter TF */
static long subIntTF(aSubRecord *pgsub)
{
  /*
   * Inputs:  A = A1
   *          C = sampling frequency
   *          D = IF frequency
   *          E = span
   * Outputs: A = Magnitude vector
   *          B = Phase vector
   *          C = Frequency vector
   */
  int points = pgsub->nova, k;
  int32_t A1;
  double f_s, freq, f_span, a1_dbl;
  double complex z, H;
  
  A1     = *(int32_t *)pgsub->a;
  f_s    = *(double *)   pgsub->c * 1.0e3 / 2; /* Integrator runs at f_adc/2 */
  f_span = *(double *)   pgsub->e;
  
  a1_dbl = (double)A1 / INT_COEFF_MAXV;
  for (k = 0; k < points; k++)
  {
    freq = -f_span + k*2*f_span/(points - 1);
    z = cexp_loc(I*2*M_PI*freq/f_s);
    H = 1.0/(z + a1_dbl);
    *((double *)pgsub->vala + k) = 20.0*log10(cabs(H)+1.0e-4);
    *((double *)pgsub->valb + k) = 180*carg_loc(H)/M_PI;
    *((double *)pgsub->valc + k) = freq;
  }

  return 0;
}

static registryFunctionRef subIntRef[] = {
  {"subIntInit", (REGISTRYFUNCTION)subIntInit},
  {"subIntGen", (REGISTRYFUNCTION)subIntGen},
  {"subIntTF", (REGISTRYFUNCTION)subIntTF},
  {"subIntCopy", (REGISTRYFUNCTION)subIntCopy}
};

static void subIntRegistrar(void)
{
  registryFunctionRefAdd(subIntRef, NELEMENTS(subIntRef));
}
epicsExportRegistrar(subIntRegistrar);
