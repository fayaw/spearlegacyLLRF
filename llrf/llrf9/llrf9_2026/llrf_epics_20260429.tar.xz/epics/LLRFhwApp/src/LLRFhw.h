/*
 System-wide definitions
 
 Copyright (c) 2008-2011 Dimtel, Inc., All Rights Reserved

 $Id: LLRFhw.h,v 1.1 2017/03/10 19:44:56 dim Exp $
 $Date: 2017/03/10 19:44:56 $
 $Author: dim $
 $Revision: 1.1 $
 $Log: LLRFhw.h,v $
 Revision 1.1  2017/03/10 19:44:56  dim
 Initial import

*/

#ifndef _LLRF_H_
#define _LLRF_H_

#define deltaT(tvp1, tvp2) (((tvp2)->tv_sec-(tvp1)->tv_sec)*1000000 + \
			      (tvp2)->tv_usec - (tvp1)->tv_usec)

typedef unsigned long ulong;
typedef unsigned char uchar;

enum pattern {
  WFM_SIN,
  WFM_SQUARE,
  WFM_SAWTOOTH,
  WFM_ARB
};
        
#define DAC_FS 8191
#define ADC_FS 8191

#define LLRF_REF_CHAN 3

/* Square root of 0.1 */
#define V_AMP_0DBM	0.316227766016838

#endif /* _LLRF_H_ */
