/*
 Complex math
 
 Copyright (c) 2011 Dimtel, Inc., All Rights Reserved

 $Id: cmath.h,v 1.1 2017/03/10 19:44:56 dim Exp $
 $Date: 2017/03/10 19:44:56 $
 $Author: dim $
 $Revision: 1.1 $
 $Log: cmath.h,v $
 Revision 1.1  2017/03/10 19:44:56  dim
 Initial import

*/

#ifndef _CMATH_H_
#define _CMATH_H_

double creal_loc(complex z);
double cimag_loc(complex z);
complex conj_loc(complex z);
complex cexp_loc(complex z);
double carg_loc(complex z);

double phase_clip(double phase_deg);

#endif /* CMATH_H_ */
