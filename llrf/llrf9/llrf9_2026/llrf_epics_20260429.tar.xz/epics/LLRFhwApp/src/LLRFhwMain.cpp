/*
 Top level IOC startup. Loads FFTW wisdom, then pauses forever
 
 Copyright (c) 2009-2015 Dimtel, Inc., All Rights Reserved

 $Id: LLRFhwMain.cpp,v 1.3 2023/09/08 19:19:08 dim Exp $
 $Date: 2023/09/08 19:19:08 $
 $Author: dim $
 $Revision: 1.3 $
 $Log: LLRFhwMain.cpp,v $
 Revision 1.3  2023/09/08 19:19:08  dim
 Series 2 and 3 merge

 Revision 1.2  2021/11/04 06:30:56  dim
 Enabled IOC shell

 Revision 1.1  2017/03/10 19:44:56  dim
 Initial import

*/

#include <stddef.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

#include <complex.h>
#include <fftw3.h>

#include <epicsExit.h>
#include <epicsThread.h>
#include <iocsh.h>

#include "LLRFhw.h"
#include "dacq.h"

int main(int argc,char *argv[])
{
  int rc;
  
  /* FFTW wisdom initialization */
  fftw_init_threads();
  fftw_plan_with_nthreads(DACQ_FFTW_THREADS);
  rc = fftw_import_system_wisdom();
  if (rc == 1)
    printf("main(): fftw wisdom read\n");
  else
    printf("main(): failed to read fftw wisdom\n");

    if(argc>=2) {    
        iocsh(argv[1]);
        epicsThreadSleep(.2);
    }
    /* Running under screen, enable shell */
    if (1)
      iocsh(NULL);
    else
      pause();
    epicsExit(0);
    return(0);
}
