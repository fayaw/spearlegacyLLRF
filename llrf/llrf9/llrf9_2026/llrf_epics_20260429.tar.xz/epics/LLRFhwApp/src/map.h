/*
 FPGA register map and bit masks. Unfortunately this map is not used directly
 by the database files, so certain register and memory addresses are
 hardcoded in .db files.
 
 Copyright (c) 2008-2016 Dimtel, Inc., All Rights Reserved

 $Id: map.h,v 1.8 2025/11/07 17:24:26 dim Exp $
 $Date: 2025/11/07 17:24:26 $
 $Author: dim $
 $Revision: 1.8 $
 $Log: map.h,v $
 Revision 1.8  2025/11/07 17:24:26  dim
 DDC acquisition support, LMK01801

 Revision 1.7  2025/09/27 23:34:34  dim
 Added DDC waveform acquisition mode, setpoint ramping moved from integer to double domain

 Revision 1.6  2023/09/08 19:19:08  dim
 Series 2 and 3 merge

 Revision 1.5  2022/11/13 23:34:47  dim
 Configuration register, baseband ADC acquisition and cleanup

 Revision 1.4  2022/08/31 18:35:35  dim
 Series 3 changes

 Revision 1.3  2019/11/15 06:00:44  dim
 New masks and bit positions for ramp counts and modes

 Revision 1.2  2018/09/03 08:38:46  dim
 Update bit maps to correspond to the FPGA setup

 Revision 1.1  2017/03/10 19:44:56  dim
 Initial import

*/

#ifndef _MAP_H_
#define _MAP_H_

#define CSR_A_CTRL  			0x0
#define CTRL_B_ADC0 0
#define CTRL_M_ADC0 (1<<CTRL_B_ADC0)
#define CTRL_B_ADC1 1
#define CTRL_M_ADC1 (1<<CTRL_B_ADC1)
#define CTRL_B_ADC2 2
#define CTRL_M_ADC2 (1<<CTRL_B_ADC2)
#define CTRL_B_ADC3 3
#define CTRL_M_ADC3 (1<<CTRL_B_ADC3)
#define CTRL_B_DAC  4
#define CTRL_M_DAC  (1<<CTRL_B_DAC)
#define CTRL_B_DCMRST 5
#define CTRL_M_DCMRST (1<<CTRL_B_DCMRST)

#define CSR_A_PHDCM0			0x2
#define CSR_A_SCALAR			0x3
#define CSR_A_DDS0			0x4
#define DDS0_B_ADV		0
#define DDS0_V_ADV		0x1ffff
#define DDS0_M_ADV		(DDS0_V_ADV << DDS_B_ADV)
#define DDS0_B_SQUARE		17
#define DDS0_B_MN		20
#define DDS0_V_MN		0xfff
#define DDS0_M_MN		(DDS0_V_MN << DDS_B_MN)
#define CSR_A_DDS1			0x5
#define DDS1_B_REM		0
#define DDS1_V_REM		0xfff
#define DDS1_M_REM		(DDS1_V_REM << DDS1_B_REM)
#define DDS1_B_AMP		16
#define DDS1_V_AMP		0x3fff
#define DDS1_M_AMP		(DDS1_V_AMP << DDS1_B_AMP)
#define CSR_A_DDS2			0x6
#define DDS2_B_INTER		0
#define DDS2_V_INTER		0xffff
#define DDS2_M_INTER		(DDS2_V_INTER << DDS2_B_INTER)
#define DDS_V_AMPFS		4970
#define DDS_N_FS		4096

#define	DAC_V_AMPFS		8191

#define CSR_A_LMK01801_EXT		0xc
#define CSR_A_LMK01801_INT		0xd

#define AD5644_A_CH0			0x10
#define AD5644_A_CH1			0x11
#define AD5644_A_CH2			0x12
#define AD5644_A_CH3			0x13
#define AD5644_A_CH4			0x14
#define AD5644_A_CH5			0x15
#define AD5644_A_CH6			0x16
#define AD5644_A_CH7			0x17
#define AD5644_A_CH8			0x18
#define AD5644_A_CH9			0x19
#define AD5644_A_CH10			0x1a
#define AD5644_A_CH11			0x1b
#define AD5644_A_REF0			0x1c
#define AD5644_A_REF1			0x1d
#define AD5644_A_REF2			0x1e
#define AD5644_A_TEST			0x1f

#define CSR_A_ROTP			0x100
#define CSR_A_ROTI			0x102
#define CSR_A_C2			0x104
#define CSR_A_C3			0x106

#define ROT_COEFF_BITS			16
#define CSR_A_ROT0			0x110
#define CSR_A_ROT1			0x111
#define CSR_A_ROT2			0x112

#define CSR_A_CFG			0x200
#define CFG_B_DECIM		0
#define CFG_V_DECIM		0x7fffff
#define CFG_M_DECIM		(CFG_V_DECIM << CFG_B_DECIM)
#define CFG_B_REV		24
#define CFG_V_REV		0xff
#define CFG_M_REV		(CFG_V_REV << CFG_B_REV)

#define CSR_A_STAT			0x201

#define DACQ_A_CTRL0			0x300
#define DCTRL0_B_POSTLEN		0
#define DCTRL0_V_POSTLEN		0x1ffff
#define DCTRL0_M_POSTLEN		(DCTRL0_V_POSTLEN << DCTRL0_B_POSTLEN)
#define DCTRL0_B_FSMRST			17
#define DCTRL0_V_FSMRST			1
#define DCTRL0_M_FSMRST			(DCTRL0_V_FSMRST << DCTRL0_B_FSMRST)
#define DCTRL0_B_TRIGMUX		18
#define DCTRL0_V_TRIGMUX		7
#define DCTRL0_M_TRIGMUX		(DCTRL0_V_TRIGMUX << DCTRL0_B_TRIGMUX)
#define DCTRL0_B_TRIGSEL		21
#define DCTRL0_V_TRIGSEL		1
#define DCTRL0_M_TRIGSEL		(DCTRL0_V_TRIGSEL << DCTRL0_B_TRIGSEL)
#define DCTRL0_B_DDCACQ			22
#define DCTRL0_V_DDCACQ			1
#define DCTRL0_M_DDCACQ			(DCTRL0_V_DDCACQ << DCTRL0_B_DDCACQ)
#define DACQ_A_CTRL1			0x301
#define DCTRL1_B_DDCCNT			0
#define DCTRL1_V_DDCCNT			0x1fff
#define DCTRL1_M_DDCCNT			(DCTRL1_V_DDCCNT << DCTRL1_B_DDCCNT)
#define DCTRL1_B_DDCSFT			13
#define DCTRL1_V_DDCSFT			0xf
#define DCTRL1_M_DDCSFT			(DCTRL1_V_DDCSFT << DCTRL1_B_DDCSFT)
#define DACQ_A_TRIG  			0x302
#define DACQ_A_RDBK			0x303
#define DACQ_A_START			0x303
#define DRDBK_B_ADDR			0
#define DRDBK_V_ADDR			0xffff
#define DRDBK_M_ADDR			(DRDBK_V_ADDR << DRDBK_B_ADDR)
#define DRDBK_B_DONE			30
#define DRDBK_V_DONE			1
#define DRDBK_M_DONE			(DRDBK_V_DONE << DRDBK_B_DONE)
#define DRDBK_B_RUNNING			31
#define DRDBK_V_RUNNING			1
#define DRDBK_M_RUNNING			(DRDBK_V_RUNNING << DRDBK_B_RUNNING)

#define BBDACQ_A_CTRL			0x304
#define BBCTRL_B_POSTLEN		0
#define BBCTRL_V_POSTLEN		0x3fff
#define BBCTRL_M_POSTLEN		(BBCTRL_V_POSTLEN << BBCTRL_B_POSTLEN)
#define BBCTRL_B_FSMRST			17
#define BBCTRL_V_FSMRST			1
#define BBCTRL_M_FSMRST			(BBCTRL_V_FSMRST << BBCTRL_B_FSMRST)
#define BBCTRL_B_TRIGMUX		18
#define BBCTRL_V_TRIGMUX		7
#define BBCTRL_M_TRIGMUX		(BBCTRL_V_TRIGMUX << BBCTRL_B_TRIGMUX)
#define BBCTRL_B_TRIGSEL		21
#define BBCTRL_V_TRIGSEL		1
#define BBCTRL_M_TRIGSEL		(BBCTRL_V_TRIGSEL << BBCTRL_B_TRIGSEL)
#define BBDACQ_A_START			0x305
#define BBDACQ_A_TRIG  			0x306
#define BBDACQ_A_RDBK			0x307
#define BBRDBK_B_ADDR			0
#define BBRDBK_V_ADDR			0x3fff
#define BBRDBK_M_ADDR			(BBRDBK_V_ADDR << BBRDBK_B_ADDR)
#define BBRDBK_B_CHAN			14
#define BBRDBK_V_CHAN			7
#define BBRDBK_M_CHAN			(BBRDBK_V_CHAN << BBRDBK_B_CHAN)
#define BBRDBK_B_DONE			30
#define BBRDBK_V_DONE			1
#define BBRDBK_M_DONE			(BBRDBK_V_DONE << BBRDBK_B_DONE)
#define BBRDBK_B_RUNNING		31
#define BBRDBK_V_RUNNING		1
#define BBRDBK_M_RUNNING		(BBRDBK_V_RUNNING << BBRDBK_B_RUNNING)

#define CSR_A_AD9512			0x400
#define AD9512_LENGTH 0x5b
#define AD9512_A_SPICFG			0x0
#define AD9512_V_SPICFG			0x10
#define AD9512_A_BYPASS			0x34
#define AD9512_A_RAMP			0x35
#define AD9512_RAMP_B_IRAMP	0
#define AD9512_RAMP_B_CRAMP	3
#define AD9512_A_DELAY  		0x36
#define AD9512_DELAY_B_DELAY	1
#define AD9512_A_OUT0			0x3d
#define AD9512_OUT012_B_PD	1
#define AD9512_OUT012_B_LEVEL	2
#define AD9512_V_OUT012		0xb		/* Unused output power down */
#define AD9512_A_OUT1			0x3e
#define AD9512_A_OUT2			0x3f
#define AD9512_A_OUT3			0x40
#define AD9512_OUT34_B_PD	0
#define AD9512_OUT34_B_CURR	1
#define AD9512_OUT34_B_LOGIC	3
#define AD9512_OUT34_B_INV	4
#define AD9512_A_OUT4			0x41
#define AD9512_A_CLKSEL			0x45
#define AD9512_V_CLKSEL		2		/* Use CLK2, power down CLK1 */
#define AD9512_A_DIV0			0x4a
#define AD9512_A_DIV0			0x4a
#define AD9512_A_DIV1			0x4c
#define AD9512_A_DIV2			0x4e
#define AD9512_A_DIV3			0x50
#define AD9512_A_CFG3			0x51
#define AD9512_A_DIV4			0x52
#define AD9512_A_CFG4			0x53
#define AD9512_CFG_B_BYPASS	7
#define AD9512_V_DIV		0xff
#define AD9512_A_SYNC			0x58
#define AD9512_SYNC_B_SOFT	2
#define AD9512_A_UPD			0x5a

/* On-chip blockRAM starts at 0x100000.  For LLRF4.6, four buffers 24kx18
  start at 0x100000, 0x108000, 0x110000, 0x118000. With LLRF4.7 we have
  buffers of 62kx18 at 0x100000, 0x110000, 0x120000, 0x130000
*/
#define BLOCKRAM	0x100000

/* Baseband ADC waveform buffer is at 0x200000, length 8192, 18 bits wide.
   That's 4kx18 LSBs first, then 4kx18 MSBs
*/
#define BB_ADC_WFM	0x200000
#define BB_ADC_WFM_LEN	8192

#define SETPT_A_BLOCK	0x18000
#define RAMP_LENGTH	512
#define SETPT_A_CTRL	0x183fe
/* Control register fields (write) */
#define SETPT_B_TRIGEN	0
#define SETPT_V_TRIGEN	1
#define SETPT_M_TRIGEN	(SETPT_V_TRIGEN << SETPT_B_TRIGEN)
#define SETPT_B_TRIGDN	1
#define SETPT_V_TRIGDN	1
#define SETPT_M_TRIGDN	(SETPT_V_TRIGDN << SETPT_B_TRIGDN)
#define SETPT_B_TRIGUP	2
#define SETPT_V_TRIGUP	1
#define SETPT_M_TRIGUP	(SETPT_V_TRIGUP << SETPT_B_TRIGUP)
#define SETPT_B_WCNTR	3
#define SETPT_V_WCNTR	0x3ffffff
#define SETPT_M_WCNTR	(SETPT_V_WCNTR << SETPT_B_WCNTR)
#define SETPT_B_MODE	29
#define SETPT_V_MODE	0x7
#define SETPT_M_MODE	(SETPT_V_MODE << SETPT_B_MODE)
#define SETPT_MODE_DUAL	0
#define SETPT_MODE_SYMM	1
#define SETPT_MODE_UP   2
#define SETPT_MODE_CW	3
#define SETPT_MODE_BURST 4
/* Readback at 0x183fe */
#define SETPT_B_CNTR	0
#define SETPT_V_CNTR	0x3ffffff
#define SETPT_M_CNTR	(SETPT_V_CNTR << SETPT_B_CNTR)
/* Readback at 0x183ff, bits 0-2 same as write at 0x183fe */
#define SETPT_A_STAT	0x183ff 
#define SETPT_B_BUSY	3
#define SETPT_V_BUSY	1
#define SETPT_M_BUSY	(SETPT_V_BUSY << SETPT_B_BUSY)
#define SETPT_B_ADDR	4
#define SETPT_V_ADDR	0x1ff
#define SETPT_M_ADDR	(SETPT_V_ADDR << SETPT_B_ADDR)
#define SETPT_PHASE_180 65536

/* Scalar readout registers */
#define SCALAR_A_BASE   0x18400
#define SCALAR_A_TS	0x1840a
#define SCALAR_M_TS	0xf
#define SCALAR_B_SYNC	31
#define SCALAR_V_SYNC	1
#define SCALAR_M_SYNC	(SCALAR_V_SYNC << SCALAR_B_SYNC)
#define MCP3208_A_CH0	0x18410
#define MCP3208_A_CH1	0x18411
#define MCP3208_A_CH2	0x18412
#define MCP3208_A_CH3	0x18413
#define MCP3208_A_CH4	0x18414
#define MCP3208_A_CH5	0x18415
#define MCP3208_A_CH6	0x18416
#define MCP3208_A_CH7	0x18417
#define DS1822_A_ROM0	0x18418
#define DS1822_A_ROM1	0x18419
#define DS1822_A_TEMP	0x1841a
#define DS1822_A_STAT	0x1841b
#define FANMON_A_BASE	0x1841c
#define FANMON_LENGTH	1
#define FREQCNT_A_VAL	0x1841e
#define ILOCK_A_BASE	0x18420
#define ILOCK_LENGTH	4
#define ILOCK_B_CAPTURE	13
#define ILOCK_V_CAPTURE 0x1fff
#define ILOCK_M_CAPTURE (ILOCK_V_CAPTURE << ILOCK_B_CAPTURE)
#define ILOCKTS_A_BASE	0x18430
#define ILOCKTS_LENGTH	13
#define ILOCKTS_B_FINE	0
#define ILOCKTS_V_FINE	0xffffff
#define ILOCKTS_M_FINE	(ILOCKTS_V_FINE << ILOCKTS_B_FINE)
#define ILOCKTS_B_COARSE 28
#define ILOCKTS_V_COARSE 0xf
#define ILOCKTS_M_COARSE (ILOCKTS_V_COARSE << ILOCKTS_B_COARSE)
#define MAX1270_A_BASE	0x18440
#define MAX1270_LENGTH	8
#define MAX1270_B_BIP	0
#define MAX1270_V_BIP	1
#define MAX1270_M_BIP	(MAX1270_V_BIP << MAX1270_B_BIP)
#define MAX1270_B_RNG	1
#define MAX1270_V_RNG	1
#define MAX1270_M_RNG	(MAX1270_V_RNG << MAX1270_B_RNG)
#define MAX1270_B_SCN	2
#define MAX1270_V_SCN	3
#define MAX1270_M_SCN	(MAX1270_V_SCN << MAX1270_B_SCN)
#define MAX1270_B_VAL	4
#define MAX1270_V_VAL	0xfff
#define MAX1270_M_VAL	(MAX1270_V_VAL << MAX1270_B_VAL)
#define MAX1270CAP_B_VAL	16
#define MAX1270CAP_V_VAL	0xfff
#define MAX1270CAP_M_VAL	(MAX1270CAP_V_VAL << MAX1270CAP_B_VAL)

#define MAX1270_CHAN	8
#define MAX1270_FS(rng)	(rng ? 10.0 : 5.0)
#define MAX1270_COUNTS	4096
#define MAX1270_SEX	((-1)<<11)

#define SCALAR_LENGTH	(MAX1270_A_BASE + MAX1270_LENGTH - SETPT_A_CTRL + 1)

#define INT_COEFF_BITS	20
#define INT_COEFF_MAXV	(1 << (INT_COEFF_BITS - 1))

#define	RTNA_A_BASE	0x14000
#define RTNA_C_SIZE	0x400
#define RTNA_A_MEMBLK0	RTNA_A_BASE
#define RTNA_A_MEMBLK1	(RTNA_A_MEMBLK0 + RTNA_C_SIZE)
#define RTNA_A_MEMBLK2	(RTNA_A_MEMBLK1 + RTNA_C_SIZE)
#define RTNA_A_MEMBLK3	(RTNA_A_MEMBLK2 + RTNA_C_SIZE)
#define RTNAM_B_ADV	0
#define RTNAM_V_ADV	0x1ffff
#define RTNAM_M_ADV	(RTNAC_V_ADV << RTNAC_B_ADV)
#define RTNAM_B_MN	17
#define RTNAM_V_MN	0xfff
#define RTNAM_M_MN	(RTNAC_V_MN << RTNAC_B_MN)
#define RTNAM_B_REM	29
#define RTNAM_V_REM	0xfff
#define RTNAM_M_REM	(RTNAC_V_REM << RTNAC_B_REM)
#define RTNAM_B_CYC	41
#define RTNAM_V_CYC	0xffffff
#define RTNAM_M_CYC	(RTNAC_V_CYC << RTNAC_B_CYC)
#define RTNA_A_CTRL	(RTNA_A_MEMBLK3 + RTNA_C_SIZE)
#define RTNA_A_STAT	(RTNA_A_CTRL+1)
#define RTNAC_B_ACCDEL	0
#define RTNAC_V_ACCDEL	0xffff
#define RTNAC_M_ACCDEL	(RTNAC_V_ACCDEL << RTNAC_B_ACCDEL)
#define RTNAC_B_FSMRST  22
#define RTNAC_V_FSMRST	1
#define RTNAC_M_FSMRST	(RTNAC_V_FSMRST << RTNAC_B_FSMRST)
#define RTNAC_B_IDLEEN	23
#define RTNAC_V_IDLEEN	1
#define RTNAC_M_IDLEEN	(RTNAC_V_IDLEEN << RTNAC_B_IDLEEN)
#define RTNAC_B_OUTSFT	24
#define RTNAC_V_OUTSFT	0xf
#define RTNAC_M_OUTSFT	(RTNAC_V_OUTSFT << RTNAC_B_OUTSFT)
#define RTNAC_B_INMUX	28
#define RTNAC_V_INMUX	0x7
#define RTNAC_M_INMUX	(RTNAC_V_INMUX << RTNAC_B_INMUX)
#define RTNAC_B_START	31
#define RTNAC_V_START	0x1
#define RTNAC_M_START	(RTNAC_V_START << RTNAC_B_START)
#define RTNA_CICMAX	(RTNAM_V_CYC+2)

/* Channels: CH0 rotated, CH1 rotated, error, drive, cavity sum, loopback, 
   ADC2, ADC3 */
#define RTNA_DELAYS     {2, 2, 4, 9, 3, 2, 2, 2}
#define RTNA_GAINS      {4, 4, 4, 4, 4, 1, 4, 4} /* Power gains */

#endif /* _MAP_H_ */
