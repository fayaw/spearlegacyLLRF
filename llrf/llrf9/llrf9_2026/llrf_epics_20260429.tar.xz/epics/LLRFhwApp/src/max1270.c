#include <stdlib.h>
#include <stdio.h>
#include <libgen.h>
#include "map.h"

int main(int argc, char **argv)
{
  int32_t val;
  double voltage;

  if (argc < 2)
  {
    fprintf(stderr, "Usage: %s value\n", basename(argv[0]));
    return 0;
  }
  
  val = strtoul(argv[1], NULL, 0);

  int range   = (val >> MAX1270_B_RNG) & MAX1270_V_RNG;
  int bipolar = (val >> MAX1270_B_BIP) & MAX1270_V_BIP;
  int adc_val = (val >> MAX1270_B_VAL) & MAX1270_V_VAL;
    
  double  adc_lsb, adc_fs = range ? 10.0 : 5.0;
    
  if (bipolar)
  {
    adc_lsb = 2 * adc_fs / 4096;
    /* Perform sign extension */
    int mask = (-1)<<11;
    adc_val = (adc_val + mask) ^ mask;
  }
  else
    adc_lsb = adc_fs / 4096;

  voltage = adc_val * adc_lsb;
  
  printf("Input 0x%x, range %d, bipolar %d, adc_val %d, voltage %f\n",
         val, range, bipolar, adc_val, voltage);

  return 0;
}