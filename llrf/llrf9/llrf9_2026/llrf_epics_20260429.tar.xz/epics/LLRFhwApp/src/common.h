/*
  Common functions
 
  Copyright (c) 2012 Dimtel, Inc., All Rights Reserved

  $Id: common.h,v 1.1 2017/03/10 19:44:56 dim Exp $
  $Date: 2017/03/10 19:44:56 $
  $Author: dim $
  $Revision: 1.1 $
  $Log: common.h,v $
  Revision 1.1  2017/03/10 19:44:56  dim
  Initial import

*/

#ifndef _COMMON_H_
#define _COMMON_H_

#include "LLRFhw.h"

/* Units types for printFrequency() */
#define PRINT_HZ	0
#define PRINT_mHZ	1

/* Units types for printTime() */
#define PRINT_SEC	0
#define PRINT_MSEC	1
#define PRINT_USEC	2

/* Rational approximation of a value with denominator limit */
void cfrac(double ratio, int Nmax, unsigned int *M, unsigned int *N);
/* Print frequency as a string for easy reading */
void printFrequency(char *output, double freq, char units);
/* Print time as a string for easy reading */
void printTime(char *output, double time, char units);

void DDSConfig(double freq, double fsamp, int Nmax, double *fr_act,
                unsigned int *M, unsigned int *N);

#endif /* _COMMON_H_ */
