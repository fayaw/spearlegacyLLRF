/*
 Subroutines for data acquisition control and processing
 
 Copyright (c) 2008-2016 Dimtel, Inc., All Rights Reserved

 $Id: subUSBio.c,v 1.11 2025/12/02 08:17:30 dim Exp $
 $Date: 2025/12/02 08:17:30 $
 $Author: dim $
 $Revision: 1.11 $
 $Log: subUSBio.c,v $
 Revision 1.11  2025/12/02 08:17:30  dim
 Fixed wraparound problem for start/end point loading

 Revision 1.10  2025/11/07 17:24:26  dim
 DDC acquisition support, LMK01801

 Revision 1.9  2025/09/27 23:34:34  dim
 Added DDC waveform acquisition mode, setpoint ramping moved from integer to double domain

 Revision 1.8  2023/09/08 19:19:08  dim
 Series 2 and 3 merge

 Revision 1.7  2022/11/15 01:42:57  dim
 Fixed time scale computation errors

 Revision 1.6  2022/11/13 23:32:42  dim
 Baseband ADC waveform acquisition added

 Revision 1.5  2021/11/04 06:33:09  dim
 Added memory block output, more precise waiting time handling

 Revision 1.4  2019/11/19 04:27:50  dim
 Changed EEPROM format - output power meter offset is in uV/2

 Revision 1.3  2019/11/15 05:55:07  dim
 Updated ramp step counts calculation

 Revision 1.2  2019/08/24 17:00:42  dim
 Hardware offset handling for setpoint, complete power meter cal in EEPROM

 Revision 1.1  2017/03/10 19:44:57  dim
 Initial import

*/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <dbAccess.h>
#include <epicsExport.h>
#include <recSup.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>
#include <float.h> /* DBL_EPSILON */
#include <string.h>
#include <sys/time.h>
#include <pthread.h>

/* Local includes */
#include "LLRFhw.h"
#include "common.h"
#include "dacq.h"
#include "usbio.h"
#include "eeprom.h"
#include "map.h"
#include "cmath.h"

static int usb_initialized = 0;
static usbio_context *sys;
static pthread_mutex_t ctxt_mutex = PTHREAD_MUTEX_INITIALIZER;

/* subUSBacq_async acquires data and places it in the snapshot */
acq_data snapshot;
pthread_mutex_t snapshot_mutex = PTHREAD_MUTEX_INITIALIZER;

int USB_Debug = 0;

typedef long (*processMethod)(subRecord *precord);

static long subUSBinit(subRecord *psub, processMethod process)
{
  int rc;
  
/*  printf("subUSBinit: thread id 0x%08x\n", pthread_self()); */
  pthread_mutex_lock(&ctxt_mutex);

  if (usb_initialized == 0)
  {
    sys = usbio_open_serial(0, getenv("BOARD_SERNO"));
    if (sys != NULL)
      usb_initialized = 1;
  }
  rc = (sys == NULL);

  pthread_mutex_unlock(&ctxt_mutex);
  
  if (USB_Debug == 2)
  {
    printf("Record %s called subUSBinit(%p)\n",
            psub->name, (void*) psub);
    printf("subUSBinit: usbio_open() returned 0x%p, usb_initialized=%d\n", 
           sys, usb_initialized);
  }
  
  if (rc == 0)
  {
    unsigned x = 0;
    /* Reset test mode on AD5644 */
    usbio_block_write(sys, AD5644_A_TEST, &x, 1);
  }
    
  return rc;
}

static long subUSBwrite(subRecord *psub)
{
  /*
   * Inputs:  A = Value to write
   *          B = Address to write
   *          D = FLAG:
   *              bit 7:   readback disable (write only)
   *              bit 6:   unsigned select
   *              bit 4-0: sign extension width
   * Outputs: C = Readback
   *          VAL = 0 ok/1 nfg
   */
   
  int flag_rdbk     = (int)psub->d & 0x80;
  int flag_unsigned = (int)psub->d & 0x40;
  int flag_sex      = (int)psub->d & 0x1f;
  unsigned int val, in = (unsigned)psub->a;
  int addr = (int) psub->b, rc, mask;
 
  if (USB_Debug == 2)
  {
    printf("Record %s called subUSBwrite(%p)\n",
           psub->name, (void*) psub);
    printf("address = 0x%06x; val = 0x%08x\n", addr, in);
  }
  rc = usbio_block_write(sys, addr, &in, 1);
  if (rc != 1)
  {
    if (USB_Debug == 1)
      printf("Write error, resetting USB IO (1)\n");
    usbio_if_reset(sys);
  }
  if (flag_rdbk == 0)
  {
    rc = usbio_read(sys, addr, &val);
    if (rc != 1)
    {
      if (USB_Debug == 1)
        printf("Read error, resetting USB IO\n");
      usbio_if_reset(sys);
    }
    
    if (flag_unsigned == 0) /* Signed result, perform sign extension */
    {
      mask     = (-1)<<(flag_sex-1);
      psub->c  = (double)(((int)val + mask)^mask);
    }
    else
      psub->c = (double) val;
  
    if (USB_Debug == 2)
      printf("Readback = 0x%08x\n", val);

    if ((rc == 1) && (in == (unsigned)psub->c))
      psub->val=0;
    else  
      psub->val=1;
  }
  else
  {
    psub->val = 0;
    psub->c   = in;
  }

  return 0;
}

static long subUSBread(subRecord *psub)
{
  /*
   * Inputs:  A = Address to read
   *          C = FLAG:
   *              bit 7:   readback disable (write only)
   *              bit 6:   unsigned select
   *              bit 4-0: sign extension width
   * Outputs: VAL = B = Readback
   *          
   */
   
  int flag_unsigned = (int)psub->c & 0x40;
  int flag_sex      = (int)psub->c & 0x1f;
  unsigned int val;
  int addr = (int)psub->a, rc, mask;
  
  rc = usbio_read(sys, addr, &val);
  if (rc != 1)
   {
    if (USB_Debug == 1)
      printf("Read error, resetting USB IO\n");
    usbio_if_reset(sys);
  }

  if (flag_unsigned == 0) /* Signed result, perform sign extension */
  {
    mask      = (-1)<<(flag_sex-1);
    psub->val = psub->b = (double)(((int)val + mask)^mask);
  }
  else
    psub->val = psub->b = (double) val;
  
  if (USB_Debug == 2)
   {
        printf("Record %s called subUSBread(%p)\n",
               psub->name, (void*) psub);
        printf("address = 0x%07x; val = 0x%04x\n", addr, (int)psub->b);
   }

  return(0);
}

typedef enum acq_state {
  ACQ_IDLE,
  ACQ_START,
  ACQ_WAIT,
  ACQ_READ,
  ACQ_SORT,
  ACQ_PROCESS
} acq_state;

static void *subUSBacq_async(void *ptr)
{
  /*
   * Inputs:  A = Trigger selector (0 - software, 1 - hardware)
   *          B = Hardware trigger mux setting
   *	      C = Enable
   *          D = Single acquisition enable
   *          E = Post-trigger length
   *          F = Block length
   *          G = ADC data acquisition length
   *          H = DDC acquisition mode
   *          I = DDC integration count
   *          J = DDC bit shift
   *          K = Sampling frequency (MHz)
   * Outputs: A = Enable write-back
              B = DDC right shift value
              C = Stop address (addr0)
   *
   */

  static acq_state state = ACQ_IDLE;
  uint32_t dtrig[10];
  uint32_t ctrl[DACQ_A_RDBK - DACQ_A_CTRL0+1];
  int k, diff, rc;
  uint32_t atrig[10];
  async_comm *async = (async_comm *)ptr;
  aSubRecord *pasub = (aSubRecord *)async->pasub;
  uint32_t *trig_sel = (uint32_t *)pasub->a, trig_sel_hw;
  uint32_t *trig_mux = (uint32_t *)pasub->b;
  uint32_t *enable   = (uint32_t *)pasub->c;
  uint32_t *single   = (uint32_t *)pasub->d;
  uint32_t *postlen  = (uint32_t *)pasub->e;
  uint32_t *blklen   = (uint32_t *)pasub->f;
  uint32_t *adclen   = (uint32_t *)pasub->g;
  uint32_t *ddc_acq  = (uint32_t *)pasub->h;
  uint32_t *ddc_cnt  = (uint32_t *)pasub->i;
  uint32_t *ddc_sft  = (uint32_t *)pasub->j;
  double   *fsamp    = (double *)pasub->k;
  uint32_t *addr0    = (uint32_t *)pasub->valc;
  double t_acq_wait_max;
  
  int length;

  uint32_t *ds;
  
  /* Wait state timeout */
  struct timeval t_wait[2];
         
  /* Timing characterization structures */
  struct timeval t1, t2;

  /* Perform initial setup here */
  snapshot.trigger = 0;
  
  ds = (uint32_t *)malloc(*blklen*4*sizeof(uint32_t));
    
  /* Data acquisition and readback state machine */
  while (1)
  {
    switch (state)
    {
      case ACQ_IDLE:
        pthread_mutex_lock(&async->mutex);
        if (!async->trigger)
          pthread_cond_wait(&async->cond, &async->mutex);
    
        state = ACQ_START;
      case ACQ_START:
        if (*enable) /* Enabled */
        {
          if (USB_Debug & 0x10)
            gettimeofday(&t1, NULL);
          k = 0;
          /* Configure parameters */
          if (*trig_sel == 0)
            length = *adclen-2;
          else
            length = *postlen - 2;
          atrig[k]   = DACQ_A_CTRL0;
          dtrig[k++] = length | (*trig_mux << DCTRL0_B_TRIGMUX) |
                        (*trig_sel << DCTRL0_B_TRIGSEL) |
                        (*ddc_acq << DCTRL0_B_DDCACQ);
          atrig[k]   = DACQ_A_CTRL1;
          
          /* Clip DDC shift */
          *ddc_sft = (*ddc_sft < 0) ? 0 : (*ddc_sft > 15) ? 15 : *ddc_sft;
          dtrig[k++] = ((*ddc_cnt - 2) & DCTRL1_M_DDCCNT) |
                       (*ddc_sft << DCTRL1_B_DDCSFT);

          /* Start acquisition process (no effect, if already going) */
          atrig[k]   = DACQ_A_START;
          dtrig[k++] = 0; /* Does not matter */
          
          if (*trig_sel == 0) /* Internal trigger */
          {
            atrig[k]   = DACQ_A_TRIG;
            dtrig[k++] = 0;
          }
          
          /* Writing both start and trigger values at once does not give
             enough time for acquisition to start in the DDC mode */
          rc = usbio_mult_write(sys, atrig, dtrig, k-1);
          if (rc != k-1)
          {
            if (USB_Debug == 1)
              printf("Write error, resetting USB IO (2)\n");
            usbio_if_reset(sys);
          }
          usleep(1000); /* Wait 1 ms */
          rc = usbio_block_write(sys, atrig[k-1], dtrig + k - 1, 1);
          if (rc != 1)
          {
            if (USB_Debug == 1)
              printf("Write error, resetting USB IO (2)\n");
            usbio_if_reset(sys);
          }
          
          /* Twice the acquisition time in microseconds */
          t_acq_wait_max = 2.0 / *fsamp * *adclen;
          if (*ddc_acq)
            t_acq_wait_max *= *ddc_cnt;

          state = ACQ_WAIT;
          gettimeofday(t_wait, NULL);
        }
        else
          state = ACQ_PROCESS;
        break;
      case ACQ_WAIT:
        rc = usbio_block_read(sys, DACQ_A_CTRL0, ctrl,
                              DACQ_A_RDBK - DACQ_A_CTRL0 + 1);
        trig_sel_hw = (ctrl[0] >> DCTRL0_B_TRIGSEL) & DCTRL0_V_TRIGSEL;

/*        printf("t_acq_wait_max = %.0f us, DACQ_A_RDBK = 0x%08x\n",
               t_acq_wait_max, ctrl[DACQ_A_RDBK-DACQ_A_CTRL0]); */
        if ((ctrl[DACQ_A_RDBK-DACQ_A_CTRL0] & DRDBK_M_DONE) &&
            !(ctrl[DACQ_A_RDBK-DACQ_A_CTRL0] & DRDBK_M_RUNNING))
        {
/*          printf("DONE & ~RUNNING, ACQ_READ, DACQ_A_RDBK = 0x%08x\n",
                 ctrl[DACQ_A_RDBK-DACQ_A_CTRL0]); */
          state = ACQ_READ;
        }
        else if (!(ctrl[DACQ_A_RDBK-DACQ_A_CTRL0] & DRDBK_M_RUNNING))
        {
/*          printf("~DONE & ~RUNNING, ACQ_PROCESS\n"); */
          state = ACQ_PROCESS;
        }
        else if (trig_sel_hw != *trig_sel)
        {
/*          printf("Trigger source change, ACQ_PROCESS\n"); */
          /* Trigger source has changed, restart */
          state = ACQ_PROCESS;
        }
        else if (!trig_sel_hw)
        {
          /* Internal trigger, don't wait more than a limit (twice 
             the expected acquisition time) */
          gettimeofday(t_wait+1, NULL);
          if (deltaT(t_wait, t_wait+1) > t_acq_wait_max)
          {
            /* Reset the state machine */
            atrig[0] = DACQ_A_CTRL0; dtrig[0] = ctrl[0] | DCTRL0_M_FSMRST;
            atrig[1] = DACQ_A_CTRL0; dtrig[1] = ctrl[0] & ~DCTRL0_M_FSMRST;
            rc = usbio_mult_write(sys, atrig, dtrig, 2);
            if (rc != 2)
            {
              if (USB_Debug == 1)
                printf("Write error, resetting USB IO (2)\n");
              usbio_if_reset(sys);
            }
/*            printf("Timeout, ACQ_PROCESS\n"); */
            state     = ACQ_PROCESS;
          }
          else
            usleep(T_ACQ_WAIT);
        }
        else
          usleep(T_ACQ_WAIT); /* HW trigger, just wait */
        break;
      case ACQ_READ:
        rc = usbio_block_read(sys, BLOCKRAM, ds, *blklen*4);
        if (rc != *blklen*4)
        {
          usbio_if_reset(sys);
          if (USB_Debug & 0x10)
            printf("USB block read error, returned %d, asked for %d\n", rc, *blklen*4);
          state = ACQ_IDLE;
          return 0;
        }
        state = ACQ_SORT;
      case ACQ_SORT:
        /* Got everything, now arrange it right */
        *addr0 = ((ctrl[DACQ_A_RDBK-DACQ_A_CTRL0] & DRDBK_M_ADDR) >> DRDBK_B_ADDR) + 1;
        if (0)
        {
          int fd = open("data.dat", O_APPEND | O_WRONLY | O_CREAT, 0644);
          write(fd, ds, *blklen*4*sizeof(int32_t));
          write(fd, ctrl, 4*sizeof(int32_t));
          write(fd, addr0, sizeof(int32_t));
          close(fd);
        }
        pthread_mutex_lock(&snapshot_mutex);
        for (k = 0; k < *adclen; k++)
        {
          int p = (*addr0 + k) % *adclen;
          if (*ddc_acq)
          {
            int18_t x;
            snapshot.ddc[0][k] = x.x = ((int32_t)ds[p]             & 0x3ffff);
            snapshot.ddc[1][k] = x.x = ((int32_t)ds[p + *blklen]   & 0x3ffff);
            snapshot.ddc[2][k] = x.x = ((int32_t)ds[p + *blklen*2] & 0x3ffff);
            snapshot.ddc[3][k] = x.x = ((int32_t)ds[p + *blklen*3] & 0x3ffff);
          }
          else
          {
            snapshot.adc[0][k] = (ds[p]             & 0xffff);
            snapshot.adc[1][k] = (ds[p + *blklen]   & 0xffff);
            snapshot.adc[2][k] = (ds[p + *blklen*2] & 0xffff);
            snapshot.adc[3][k] = (ds[p + *blklen*3] & 0xffff);
          }
        }
        snapshot.postlen = (ctrl[0] & DCTRL0_M_POSTLEN) + 2;
        snapshot.ddc_acq = (ctrl[0] & DCTRL0_M_DDCACQ) >> DCTRL0_B_DDCACQ;
        snapshot.ddc_cnt = ((ctrl[DACQ_A_CTRL1-DACQ_A_CTRL0] & DCTRL1_M_DDCCNT) 
                           + 2) & DCTRL1_M_DDCCNT;
        snapshot.ddc_sft = (ctrl[DACQ_A_CTRL1-DACQ_A_CTRL0] & DCTRL1_M_DDCSFT) 
                            >> DCTRL1_B_DDCSFT;
        snapshot.trigger = 1;
        pthread_mutex_unlock(&snapshot_mutex);
        state = ACQ_PROCESS;
        
        if (USB_Debug == 1)
        {
          gettimeofday(&t2, NULL);
          diff = deltaT(&t1, &t2);
          printf("Elapsed time (acq): %.3f ms\n", ((double)diff)/1000.0);
        }
      case ACQ_PROCESS:
        if (*single)
        {
          /* When single acquisition is enabled, process output lin */
          *(long *)pasub->vala = 0;
          async->rc            = 0;
        }
        else
        {
          async->rc            = 1;
        }
        async->trigger = ASYNC_DONE;
        pthread_mutex_unlock(&async->mutex);

        /* Call process() to finish record processing */
        struct dbCommon *precord = (struct dbCommon *)pasub;
        struct rset *prset=(struct rset *)(precord->rset);
        dbScanLock(precord);
        (*prset->process)(precord);
        dbScanUnlock(precord);
        state = ACQ_IDLE;
    }
  }
  /* Never reached */
  return NULL;
}

static long subUSBacq(aSubRecord *pasub)
{
  static int first = 1;
  int rc = 0;
  static async_comm async;
  static pthread_t async_thread;
  
  if (first)
  {
    pthread_mutex_init(&async.mutex, NULL);
    pthread_cond_init(&async.cond, NULL);
    async.pasub = pasub;
    async.trigger = ASYNC_IDLE;
    pthread_create(&async_thread, NULL, subUSBacq_async, (void *)&async);
    first = 0;
  }
  
  /* As we get to this point, there are two possibilities
     1. This is an initial call to routine, need to trigger async thread
     2. A second call at the end of async processing
  */  
  pthread_mutex_lock(&async.mutex);
  if (async.trigger == ASYNC_DONE)
  {
    async.trigger = ASYNC_IDLE;
    pasub->pact   = 0;
    rc            = async.rc;
  }
  else if (async.trigger == ASYNC_IDLE)
  {
    pasub->pact   = 1;
    async.trigger = ASYNC_TRIGGER;
    pthread_cond_signal(&async.cond); /* Send a signal to the async thread */
  }
  else
  {
    fprintf(stderr, "Unexpected trigger state ASYNC_TRIGGER in subUSBacq()\n");
    rc = 1;
  }
  pthread_mutex_unlock(&async.mutex);

  return rc;
}

#define BBCLEN (BBDACQ_A_RDBK - BBDACQ_A_CTRL+1)

static void *subUSBbbacq_async(void *ptr)
{
  /*
   * Inputs:  A = Trigger selector (0 - software, 1 - hardware)
   *          B = Hardware trigger mux setting
   *	      C = Enable
   *          D = Single acquisition enable
   *          E = Post-trigger length
   *          
   * Outputs: A = Enable write-back
   *          B = Channel 0 values
   *          C = Channel 1 values
   *          D = Channel 2 values
   *          E = Channel 3 values
   *          F = Channel 4 values
   *          G = Channel 5 values
   *          H = Channel 6 values
   *          I = Channel 7 values
   *          J = Channel 0 time
   *          K = Channel 1 time
   *          L = Channel 2 time
   *          M = Channel 3 time
   *          N = Channel 4 time
   *          O = Channel 5 time
   *          P = Channel 6 time
   *          Q = Channel 7 time
   *          R = Raw buffer (int32, 8k)
   *          S = Linear space (int16, 12k)
   *          T = addr0
   *          U = chan0
   *
   */

  static acq_state state = ACQ_IDLE;
  uint32_t dtrig[10];
  uint32_t ctrl[BBCLEN], adc_cfg[MAX1270_CHAN];
  int k, m, diff, rc;
  uint32_t atrig[10];
  async_comm *async   = (async_comm *)ptr;
  aSubRecord *pasub   = (aSubRecord *)async->pasub;
  uint32_t *trig_sel  = (uint32_t *)pasub->a, trig_sel_hw;
  uint32_t *trig_mux  = (uint32_t *)pasub->b;
  uint32_t *enable    = (uint32_t *)pasub->c;
  uint32_t *single    = (uint32_t *)pasub->d;
  uint32_t *postlen   = (uint32_t *)pasub->e;
  int length, n_ch;
  int ch_mask[MAX1270_CHAN], ch_mask_old[MAX1270_CHAN];
  int addr0, chan, step, samples;
  int chan0, scan_mode, bip[MAX1270_CHAN], rng[MAX1270_CHAN];
         
  uint32_t ds[BB_ADC_WFM_LEN];
  short ds_lin[BB_ADC_LENGTH];
  
  /* Wait state timeout */
  struct timeval t_wait[2];
         
  /* Timing characterization structures */
  struct timeval t1, t2;

  /* Initialize the old mask for proper startup behavior */
  for (chan = 0; chan < MAX1270_CHAN; chan++)
    ch_mask_old[chan] = 1;

  /* Data acquisition and readback state machine */
  while (1)
  {
    switch (state)
    {
      case ACQ_IDLE:
        pthread_mutex_lock(&async->mutex);
        if (!async->trigger)
          pthread_cond_wait(&async->cond, &async->mutex);
    
        state = ACQ_START;
      case ACQ_START:
        if (*enable) /* Enabled */
        {
          if (USB_Debug & 0x10)
            gettimeofday(&t1, NULL);
          k = 0;
          /* Configure parameters */
          if (*trig_sel == 0)
          {
            /* Post-trigger acquisition */
            length = BB_ADC_LENGTH-2;
            *postlen = BB_ADC_LENGTH;
          }
          else
            length = *postlen - 2;
          atrig[k]   = BBDACQ_A_CTRL;
          dtrig[k++] = length | (*trig_mux << BBCTRL_B_TRIGMUX) |
                        (*trig_sel << BBCTRL_B_TRIGSEL);

          /* Start acquisition process (no effect, if already going) */
          atrig[k]   = BBDACQ_A_START;
          dtrig[k++] = 0; /* Does not matter */
          
          if (*trig_sel == 0) /* Internal trigger */
          {
            atrig[k]   = BBDACQ_A_TRIG;
            dtrig[k++] = 0;
          }
          
          /* Writing both values at once does not give
             enough time for acquisition to fill complete buffer */
          rc = usbio_mult_write(sys, atrig, dtrig, k);
          if (rc != k)
          {
            if (USB_Debug == 1)
              printf("Write error, resetting USB IO (2)\n");
            usbio_if_reset(sys);
          }
  
          state = ACQ_WAIT;
          gettimeofday(t_wait, NULL);
        }
        else
          state = ACQ_PROCESS;
        break;
      case ACQ_WAIT:
        rc = usbio_block_read(sys, BBDACQ_A_CTRL, ctrl, BBCLEN);
        trig_sel_hw = (ctrl[0] >> BBCTRL_B_TRIGSEL) & BBCTRL_V_TRIGSEL;

        if ((ctrl[BBDACQ_A_RDBK-BBDACQ_A_CTRL] & BBRDBK_M_DONE) &&
            !(ctrl[BBDACQ_A_RDBK-BBDACQ_A_CTRL] & BBRDBK_M_RUNNING))
          state = ACQ_READ;
        else if (!(ctrl[BBDACQ_A_RDBK-BBDACQ_A_CTRL] & BBRDBK_M_RUNNING))
          state = ACQ_PROCESS;
        else if (trig_sel_hw != *trig_sel)
          /* Trigger source has changed, restart */
          state = ACQ_PROCESS;
        else if (!trig_sel_hw)
        {
          /* Internal trigger, don't wait more than a limit */
          gettimeofday(t_wait+1, NULL);
          if (deltaT(t_wait, t_wait+1) > T_BBACQ_WAIT_MAX)
          {
            /* Reset the state machine */
            atrig[0] = BBDACQ_A_CTRL; dtrig[0] = ctrl[0] | BBCTRL_M_FSMRST;
            atrig[1] = BBDACQ_A_CTRL; dtrig[1] = ctrl[0] & ~BBCTRL_M_FSMRST;
            rc = usbio_mult_write(sys, atrig, dtrig, 2);
            if (rc != 2)
            {
              if (USB_Debug == 1)
                printf("Write error, resetting USB IO (2)\n");
              usbio_if_reset(sys);
            }
            state     = ACQ_PROCESS;
          }
          else
            usleep(T_ACQ_WAIT);
        }
        else
          usleep(T_ACQ_WAIT); /* HW trigger, just wait */
        break;
      case ACQ_READ:
        rc = usbio_block_read(sys, BB_ADC_WFM, ds, BB_ADC_WFM_LEN);
        if (rc != BB_ADC_WFM_LEN)
        {
          usbio_if_reset(sys);
          if (USB_Debug & 0x10)
            printf("USB block read error, returned %d, asked for %d\n", rc, BB_ADC_WFM_LEN);
          state = ACQ_IDLE;
          break;
        }
        rc = usbio_block_read(sys, MAX1270_A_BASE, adc_cfg, MAX1270_LENGTH);
        if (rc != MAX1270_LENGTH)
        {
          usbio_if_reset(sys);
          if (USB_Debug & 0x10)
            printf("USB block read error, returned %d, asked for %d\n", rc, MAX1270_LENGTH);
          state = ACQ_IDLE;
          break;
        }
        state = ACQ_SORT;
      case ACQ_SORT:
        /* Got everything, now arrange it right */
        addr0 = ((ctrl[BBDACQ_A_RDBK-BBDACQ_A_CTRL] & BBRDBK_M_ADDR) >> BBRDBK_B_ADDR) + 1;
        chan0 = (ctrl[BBDACQ_A_RDBK-BBDACQ_A_CTRL] & BBRDBK_M_CHAN) >> BBRDBK_B_CHAN;
        *(int32_t *)pasub->valt = addr0;
        *(int32_t *)pasub->valu = chan0;
        /* Create 12k long buffer of samples */
        for (k = 0; k < BB_ADC_WFM_LEN/2; k++)
        {
          ds_lin[k] = ds[k] & 0xfff;
          ds_lin[k+BB_ADC_WFM_LEN/2] = ((ds[k] >> 12) & 0x3f) | 
                                       ((ds[k + BB_ADC_WFM_LEN/2] & 0x3f) << 6);
          ds_lin[k+BB_ADC_WFM_LEN]   = (ds[k + BB_ADC_WFM_LEN/2] >> 6) & 0xfff;
        }
        memcpy(pasub->valr, ds, BB_ADC_WFM_LEN*sizeof(int32_t));
        memcpy(pasub->vals, ds_lin, BB_ADC_LENGTH*sizeof(short));
        scan_mode = (adc_cfg[0] >> MAX1270_B_SCN) & MAX1270_V_SCN;
        for (k = 0; k < MAX1270_CHAN; k++)
        {
          bip[k] = (adc_cfg[k] >> MAX1270_B_BIP) & MAX1270_V_BIP;
          rng[k] = (adc_cfg[k] >> MAX1270_B_RNG) & MAX1270_V_RNG;
        }
        /*
          Scan mode
            0 - 8 channels
            1 - 4 channels
            2 - 2 channels
            3 - 1 channel
        */
        n_ch    = 1<<(3-scan_mode);
        step    = 1<<scan_mode;
        samples = BB_ADC_LENGTH/n_ch;
        for (k = 0; k < MAX1270_CHAN; k++)
          ch_mask[k] = 0;
        for (k = 0; k < MAX1270_CHAN; k += step)
          ch_mask[k] = 1;
            
//        printf("scan_mode=%d, n_ch=%d, step=%d, addr0=0x%04x, chan0=%d\n", scan_mode,n_ch,step,addr0,chan0);
        chan0   = (chan0 + 2*step) % 8; /* First channel ID */
        void **p_val = &(pasub->valb); /* Pointer to value outputs */
        DBLINK *p_vln = &(pasub->outb);
        epicsUInt32 *p_nov = &(pasub->novb); /* Vector lengths */
        void **p_tsc = &(pasub->valj); /* Pointer to time outputs */
        void **p_ots = &(pasub->ovlj); /* Pointer to previous time outputs */
        DBLINK *p_tln = &(pasub->outj);
        
        for (k = m = 0, chan = chan0; k < BB_ADC_LENGTH; k++)
        {
          int idx = (addr0 + k) % BB_ADC_LENGTH;
          float adc_fs = MAX1270_FS(rng[chan]);
          float adc_lsb = (bip[chan]+1) * adc_fs / MAX1270_COUNTS;
          int val;
          if (bip[chan])
            /* Sign extension */
            val = (ds_lin[idx] + MAX1270_SEX) ^ MAX1270_SEX; 
          else
            val = ds_lin[idx];
            
          *((float *)p_val[chan]+m) = val * adc_lsb;
          *((float *)p_tsc[chan]+m) = (float)(BBACQ_TS*(idx + (int)*postlen - BB_ADC_LENGTH));

          chan = (chan + step) % MAX1270_CHAN;
          if (chan == chan0) m++;
        }
        
//        printf("samples=%d, m=%d\n", samples, m);
        
        /* Now replicate the last value */
        for (chan = 0; chan < MAX1270_CHAN; chan++)
        {
          int nmax = p_nov[chan];
          if (ch_mask[chan])
          {
            float last_v = *((float *)p_val[chan]+samples-1);
            float last_t = *((float *)p_tsc[chan]+samples-1);
//            printf("Channel %d: nmax=%d, last_v=%f, last_t=%f\n", chan,
//                   nmax, last_v, last_t);
            for (k = samples; k < nmax; k++)
            {
              *((float *)p_val[chan] + k) = last_v;
              *((float *)p_tsc[chan] + k) = last_t;
            }
            /* Update the active channel link */
            dbPutLink(&p_vln[chan], DBR_FLOAT, (float *)p_val[chan], nmax);
            
            /* Check if time scale is different */
            if (bcmp(p_tsc[chan], p_ots[chan], nmax*sizeof(float)))
              dbPutLink(&p_tln[chan], DBR_FLOAT, (float *)p_tsc[chan], nmax);
          }
          else
          {
            if (ch_mask_old[chan])
            {
              printf("channel %d: NaN\n", chan);
              for (k = 0; k < nmax; k++)
              {
                *((float *)p_val[chan] + k) = NAN;
                *((float *)p_tsc[chan] + k) = NAN;
              }
              dbPutLink(&p_vln[chan], DBR_FLOAT, (float *)p_val[chan], nmax);
              dbPutLink(&p_tln[chan], DBR_FLOAT, (float *)p_tsc[chan], nmax);
            }
          }
        }
        for (chan = 0; chan < MAX1270_CHAN; chan++)
          ch_mask_old[chan] = ch_mask[chan];
          
        state = ACQ_PROCESS;
        
        if (USB_Debug == 1)
        {
          gettimeofday(&t2, NULL);
          diff = deltaT(&t1, &t2);
          printf("Elapsed time (acq): %.3f ms\n", ((double)diff)/1000.0);
        }
      case ACQ_PROCESS:
        if (*single)
        {
          /* When single acquisition is enabled, process output link A */
          *(long *)pasub->vala = 0;
          dbPutLink(&pasub->outa, DBR_LONG, (long *)pasub->vala, 1);
        }
        async->rc            = 1;
        async->trigger = ASYNC_DONE;
        pthread_mutex_unlock(&async->mutex);

        /* Call process() to finish record processing */
        struct dbCommon *precord = (struct dbCommon *)pasub;
        struct rset *prset=(struct rset *)(precord->rset);
        dbScanLock(precord);
        (*prset->process)(precord);
        dbScanUnlock(precord);
        state = ACQ_IDLE;
    }
  }
  /* Never reached */
  return NULL;
}

static long subUSBbbacq(aSubRecord *pasub)
{
  static int first = 1;
  int rc = 0;
  static async_comm async;
  static pthread_t async_thread;
  
  if (first)
  {
    pthread_mutex_init(&async.mutex, NULL);
    pthread_cond_init(&async.cond, NULL);
    async.pasub = pasub;
    async.trigger = ASYNC_IDLE;
    pthread_create(&async_thread, NULL, subUSBbbacq_async, (void *)&async);
    first = 0;
  }
  
  /* As we get to this point, there are two possibilities
     1. This is an initial call to routine, need to trigger async thread
     2. A second call at the end of async processing
  */  
  pthread_mutex_lock(&async.mutex);
  if (async.trigger == ASYNC_DONE)
  {
    async.trigger = ASYNC_IDLE;
    pasub->pact   = 0;
    rc            = async.rc;
  }
  else if (async.trigger == ASYNC_IDLE)
  {
    pasub->pact   = 1;
    async.trigger = ASYNC_TRIGGER;
    pthread_cond_signal(&async.cond); /* Send a signal to the async thread */
  }
  else
  {
    fprintf(stderr, "Unexpected trigger state ASYNC_TRIGGER in subUSBbbacq()\n");
    rc = 1;
  }
  pthread_mutex_unlock(&async.mutex);

  return rc;
}

static long subUSBad9512(aSubRecord *pgsub)
{
  uchar bypass, iramp, cramp, delay;
  uchar out0pd, out0level;
  uchar out3pd, out3curr, out3logic, out3inv;
  uchar out4pd, out4curr, out4logic, out4inv;
  uchar divide, adc_div, dac_div, dac_div_bypass;
  uchar div3, out3_div, out3_div_bypass;
  unsigned addr[AD9512_LENGTH+2], data[AD9512_LENGTH+2];
  int idx = 0, k;

  if (USB_Debug == 2)
  {
    printf("Record %s called subUSBad9512(%p)\n",
           pgsub->name, (void*) pgsub);
  }
  
  bypass    = *(unsigned char *)pgsub->a;
  iramp     = *(unsigned char *)pgsub->b;
  cramp     = *(unsigned char *)pgsub->c;
  delay     = *(unsigned char *)pgsub->d;
  out0pd    = *(unsigned char *)pgsub->e;
  out0level = *(unsigned char *)pgsub->f;
  out3pd    = *(unsigned char *)pgsub->g;
  out3curr  = *(unsigned char *)pgsub->h;
  out3logic = *(unsigned char *)pgsub->i;
  out3inv   = *(unsigned char *)pgsub->j;
  out4pd    = *(unsigned char *)pgsub->k;
  out4curr  = *(unsigned char *)pgsub->l;
  out4logic = *(unsigned char *)pgsub->m;
  out4inv   = *(unsigned char *)pgsub->n;
  divide    = *(unsigned char *)pgsub->o;
  div3      = *(unsigned char *)pgsub->p;
  
  addr[idx] = AD9512_A_BYPASS; data[idx++] = bypass;
  addr[idx] = AD9512_A_RAMP; data[idx++]   = iramp << AD9512_RAMP_B_IRAMP | cramp << AD9512_RAMP_B_CRAMP;
  addr[idx] = AD9512_A_DELAY; data[idx++]	= delay << AD9512_DELAY_B_DELAY;
  addr[idx] = AD9512_A_OUT0; data[idx++]   = out0level << AD9512_OUT012_B_LEVEL | out0pd << AD9512_OUT012_B_PD;
  addr[idx] = AD9512_A_OUT1; data[idx++]   = AD9512_V_OUT012;
  addr[idx] = AD9512_A_OUT2; data[idx++]   = AD9512_V_OUT012;
  addr[idx] = AD9512_A_OUT3; data[idx++]   = out3pd    << AD9512_OUT34_B_PD |
                          out3curr  << AD9512_OUT34_B_CURR |
                          out3logic << AD9512_OUT34_B_LOGIC |
                          out3inv   << AD9512_OUT34_B_INV;
  addr[idx] = AD9512_A_OUT4; data[idx++]   = out4pd    << AD9512_OUT34_B_PD |
                          out4curr  << AD9512_OUT34_B_CURR |
                          out4logic << AD9512_OUT34_B_LOGIC |
                          out4inv   << AD9512_OUT34_B_INV;
  addr[idx] = AD9512_A_CLKSEL; data[idx++] = AD9512_V_CLKSEL;
  /* Configure divide ratios */
  adc_div = (divide-1)<<4 | (divide-1);
  if (divide == 1)
  {
    /* Use bypass */
    dac_div        = AD9512_V_DIV;
    dac_div_bypass = 1;
  }
  else
  {
    dac_div        = (divide/2-1)<<4 | (divide-1)>>1;
    dac_div_bypass = 0;
  }

  if (div3 == 1)
  {
    out3_div        = AD9512_V_DIV;
    out3_div_bypass = 1;
  }
  else
  {
    out3_div        = (div3/2-1)<<4 | (div3-1)>>1;
    out3_div_bypass = 0;
  }

  addr[idx] = AD9512_A_DIV0; data[idx++]   = adc_div;
  addr[idx] = AD9512_A_DIV1; data[idx++]   = AD9512_V_DIV;
  addr[idx] = AD9512_A_DIV2; data[idx++]   = AD9512_V_DIV;
  addr[idx] = AD9512_A_DIV3; data[idx++]   = out3_div;
  addr[idx] = AD9512_A_CFG3; data[idx++]   = out3_div_bypass << AD9512_CFG_B_BYPASS;
  addr[idx] = AD9512_A_DIV4; data[idx++]   = dac_div;
  addr[idx] = AD9512_A_CFG4; data[idx++]   = dac_div_bypass << AD9512_CFG_B_BYPASS;
  addr[idx] = AD9512_A_SYNC; data[idx++]    = 1 << AD9512_SYNC_B_SOFT;
  addr[idx] = AD9512_A_UPD;  data[idx++]    = 1;
  addr[idx] = AD9512_A_SYNC; data[idx++]    = 0;
  addr[idx] = AD9512_A_UPD;  data[idx++]    = 1;
  
  /* Add base address */
  for (k=0; k < idx; k++)
    addr[k] += CSR_A_AD9512;
    
  usbio_mult_write(sys, addr, data, idx);
  
  return 0;
}

static long subUSBad9512sync(aSubRecord *pgsub)
{
  unsigned addr[4], data[4];
  int idx = 0, k;

  if (USB_Debug == 2)
  {
    printf("Record %s called subUSBad9512sync(%p)\n",
           pgsub->name, (void*) pgsub);
  }
  
  addr[idx] = AD9512_A_SYNC; data[idx++]    = 1 << AD9512_SYNC_B_SOFT;
  addr[idx] = AD9512_A_UPD;  data[idx++]    = 1;
  addr[idx] = AD9512_A_SYNC; data[idx++]    = 0;
  addr[idx] = AD9512_A_UPD;  data[idx++]    = 1;
  
  /* Add base address */
  for (k=0; k < idx; k++)
    addr[k] += CSR_A_AD9512;
    
  usbio_mult_write(sys, addr, data, idx);
  return 0;
}

static long subUSBlmk01801_ext(aSubRecord *pgsub)
{
  unsigned addr[9], data[9];
  int idx = 0, k;

  if (USB_Debug == 2)
  {
    printf("Record %s called subUSBlmk01801(%p)\n",
           pgsub->name, (void*) pgsub);
  }
  
  
  data[idx++] = (0x000005e<<4) + 0xf; /* Unlock registers */
  data[idx++] = (0x4800301<<4) + 0x0; /* Reset */
  data[idx++] = (0x1030800<<4) + 0x3; /* SYNC1 active low to disable outputs */
  data[idx++] = (0x480030c<<4) + 0x0; /* Power down dividers/outputs 0-7, clkin1 div bypass */
  data[idx++] = (0x0000000<<4) + 0x1; /* Power down outputs 0-7 */
  data[idx++] = (0x0400000<<4) + 0x2; /* Power down outputs 8-12, 13 is LVPECL 1600 mV */
  data[idx++] = (0x0018000<<4) + 0x5; /* CG4 divide-by-12 */
  data[idx++] = (0x1030000<<4) + 0x3; /* Invert SYNC1 polarity to start */
  data[idx++] = (0x000005f<<4) + 0xf; /* Lock registers */
  
  
  for (k = 0; k < idx; k++)
    addr[k] = CSR_A_LMK01801_EXT; 
  
  usbio_mult_write(sys, addr, data, idx);
  return 0;
}

static long subUSBlmk01801_int(aSubRecord *pgsub)
{
  /*
   *          A = Input divider
   *          B = CG3 divider (ADC)
   *          C = CG4 divider (DAC)
   *          D = ADC sampling frequency (MHz)
   *          E = IF frequency (kHz)
   *          F = J26 (CLKout12) enable
   *          G = J24 (/CLKout8) enable
   *          H = J25 (CLKout9) enable
   *
   * Outputs: A = RF frequency (MHz)
   *          B = LO frequency (MHz)
   *
   */
  uint32_t div_in, div3, div4;
  double fsamp, f_if;
  int32_t J26, J24, J25, idx = 0, bypass = 1, k;
  uint32_t addr[11], data[11];

  if (USB_Debug == 2)
  {
    printf("Record %s called subUSBlmk01801_int(%p)\n",
           pgsub->name, (void*) pgsub);
  }
  
  div_in = *(uint32_t *)pgsub->a;
  div3   = *(uint32_t *)pgsub->b;
  div4   = *(uint32_t *)pgsub->c;
  fsamp  = *(double *)pgsub->d;
  f_if   = *(double *)pgsub->e;
  J26    = *(int32_t *)pgsub->f;
  J24    = *(int32_t *)pgsub->g;
  J25    = *(int32_t *)pgsub->h;

  data[idx++] = 0x000005e0 + 0xf; /* Unlock registers */
  data[idx++] = 0x48003010 + 0x0; /* Reset */
  data[idx++] = 0x11301800 + 0x3; /* SYNC1_POL=1, SYNC1_QUAL=3, SYNC1_FAST=1 */
  data[idx++] = 0x00000000 + 0x1; /* Power down outputs 0-7 */
  data[idx]   = 0x0d088000 + 0x2; /* 10-11: norm/norm, 13: norm/off */
  if (J24)
    data[idx] |= 0xa0; /* Turn on output 8: off/norm */
  if (J25)
    data[idx] |= 0x800; /* Output 9: norm/norm */
  else
    data[idx] |= 0xa00; /* Output 9: off/norm */
  if (J26)
    data[idx] |= 0xc00000; /* Output 12: norm/off */
  idx++;
  
  if (div_in == 1)
    bypass = 0;
  data[idx++] = 0x480030c0 | (div_in&7)<<19 | bypass<<22; /* Input divider */
  data[idx++] = ((div3 & 7) << 10 | div4<<17) + 0x5; /* CG3 and CG4 dividers */
  data[idx++] = 0x11309800 + 0x3; /* Set SYNC1 polarity to 0 */
  data[idx++] = 0x11301800 + 0x3; /* Invert SYNC1 polarity to get going */
  data[idx++] = 0x000005f0 + 0xf; /* Lock registers */

  for (k = 0; k < idx; k++)
    addr[k] = CSR_A_LMK01801_INT; 

  usbio_mult_write(sys, addr, data, idx);
  
  /* Compute LO frequency */
  *(double *)pgsub->valb = fsamp * div_in * div3;
  /* Compute RF frequency */
  *(double *)pgsub->vala = *(double *)pgsub->valb + f_if/1000.0;
  
  return 0;
}

static long subUSBlmk01801sync(aSubRecord *pgsub)
{
  /* This code is currently broken, sometimes DAC clock synchronizes
     with the falling edge of the ADC clock instead of the rising
     edge. Full configuration process is used instead */
     
  unsigned addr[9], data[9];
  int idx = 0, k;

  if (USB_Debug == 2)
  {
    printf("Record %s called subUSBlmk01801(%p)\n",
           pgsub->name, (void*) pgsub);
  }
  
  data[idx++] = 0x000005e0 + 0xf; /* Unlock registers */
  data[idx++] = 0x11309800 + 0x3; /* Set SYNC1 polarity to 0 */
  data[idx++] = 0x11301800 + 0x3; /* Invert SYNC1 polarity to get going */
  data[idx++] = 0x000005f0 + 0xf; /* Lock registers */
  
  for (k = 0; k < idx; k++)
    addr[k] = CSR_A_LMK01801_INT; 
  
  usbio_mult_write(sys, addr, data, idx);
  return 0;
}

static long subUSBpoll(aSubRecord *pgsub)
{
  /*
   *          A = CIC decimation
   *
   * Outputs: C = Raw I/Q/timestamp vector (int x11)
   *          Q = Acquisition timestamp
   *          R = CIC resync done
   *          K = MCP3208 vector
   *	      L = DS1822 ROM vector (LSB, MSB)
   *          M = DS1822 temperature
   *          N = DS1822 presence bit
   *          O = Frequency counter
   *          P = Fan monitor
   *          A = Ramp trigger enable
   *          B = Ramp trigger down
   *          G = Ramp trigger up
   *          H = Ramp counts/point
   *          I = Ramp address
   *          J = Ramping in progress
   *          D = Interlock capture vector (int x12)
   *          E = Interlock timestamp vector (int x13)
   *          F = Slow ADC vector (double x8)
   *
   */
  unsigned ch, setpt;
  int data[SCALAR_LENGTH];
  int32_t *p, cic_decim = *(int32_t *)pgsub->a;
  double *dp, *dp1;
  
  if (USB_Debug == 2)
  {
    printf("Record %s called subUSBpoll(%p)\n",
           pgsub->name, (void*) pgsub);
  }
  
  /* Read the memory */
  usbio_block_read(sys, SETPT_A_CTRL, (unsigned *)data, SCALAR_LENGTH);
  
  setpt = *data;
  *(int32_t *)pgsub->valh = ((setpt >> SETPT_B_CNTR) & SETPT_V_CNTR) + 1;
  setpt = data[1];
  *(int32_t *)pgsub->vala = (setpt >> SETPT_B_TRIGEN) & SETPT_V_TRIGEN;
  *(int32_t *)pgsub->valb = (setpt >> SETPT_B_TRIGDN) & SETPT_V_TRIGDN;
  *(int32_t *)pgsub->valg = (setpt >> SETPT_B_TRIGUP) & SETPT_V_TRIGUP;
  *(int32_t *)pgsub->vali = (setpt >> SETPT_B_ADDR) & SETPT_V_ADDR;
  *(int32_t *)pgsub->valj = (setpt >> SETPT_B_BUSY) & SETPT_V_BUSY;
  
  /* Copy out raw I/Q */
  memcpy(pgsub->valc, data+SCALAR_A_BASE-SETPT_A_CTRL, 11*sizeof(int32_t));
  *((int32_t *)pgsub->valc + 10) &= SCALAR_M_TS;

  /* Timestamp */
  *(int32_t *)pgsub->valq = data[SCALAR_A_TS - SETPT_A_CTRL] & SCALAR_M_TS;
  *(int32_t *)pgsub->valr = (data[SCALAR_A_TS - SETPT_A_CTRL] >> SCALAR_B_SYNC) &
                        SCALAR_V_SYNC;
  *(int32_t *)pgsub->vals = (data[SCALAR_A_TS - SETPT_A_CTRL] >> 4) & 0xffffff;
  
  /* Copy out MCP3208 data */
  memcpy(pgsub->valk, data + MCP3208_A_CH0 - SETPT_A_CTRL, 8*sizeof(int32_t));
  
  /* Get DS1822 data out */
  memcpy(pgsub->vall, data + (DS1822_A_ROM0 - SETPT_A_CTRL), 2*sizeof(int32_t));
  *(uint32_t *)pgsub->valm = data[DS1822_A_TEMP - SETPT_A_CTRL];
  *(int32_t *)pgsub->valn = data[DS1822_A_STAT - SETPT_A_CTRL];
  
  /* Copy out the frequency counter value */
  *(int32_t *)pgsub->valo = data[FREQCNT_A_VAL - SETPT_A_CTRL];
  
  /* Copy out fan monitor */
  *(int32_t *)pgsub->valp =  data[FANMON_A_BASE - SETPT_A_CTRL];
  
  /* Copy out the interlock capture */
  for (ch = 0, dp = (double *)pgsub->vald; ch < ILOCK_LENGTH; ch++)
    *dp++ = (data[ILOCK_A_BASE - SETPT_A_CTRL + ch] >> ILOCK_B_CAPTURE) & ILOCK_V_CAPTURE;

  /* Now copy the interlock timestamps */
  for (ch = 0, p = (int32_t *)pgsub->vale; ch < ILOCKTS_LENGTH; ch++)
  {
    int32_t val = data[ILOCKTS_A_BASE - SETPT_A_CTRL + ch];
    int32_t coarse = (val >> ILOCKTS_B_COARSE) & ILOCKTS_V_COARSE;
    int32_t fine   = (val >> ILOCKTS_B_FINE) & ILOCKTS_V_FINE;
    
    *p++ = (cic_decim - 2 - fine) + coarse*cic_decim;
  }
  
  /* Copy out MAX1270 readings: value and capture */
  dp1 = (double *)pgsub->vald + 4; /* Interlock capture value */
  for (ch = 0, dp = (double *)pgsub->valf; ch < MAX1270_CHAN; ch++)
  {
    int32_t val = data[MAX1270_A_BASE - SETPT_A_CTRL + ch];
    int range   = (val >> MAX1270_B_RNG) & MAX1270_V_RNG;
    int bipolar = (val >> MAX1270_B_BIP) & MAX1270_V_BIP;
    int adc_val = (val >> MAX1270_B_VAL) & MAX1270_V_VAL;
    int adc_cap = (val >> MAX1270CAP_B_VAL) & MAX1270CAP_V_VAL;
    
    double adc_fs = MAX1270_FS(range);
    double adc_lsb = (1 + bipolar) * adc_fs / MAX1270_COUNTS;
    if (bipolar)
    {
      /* Perform sign extension */
      int mask = (-1)<<11;
      adc_val = (adc_val + mask) ^ mask;
      adc_cap = (adc_cap + mask) ^ mask;
    }
    *dp++ = adc_val * adc_lsb;
    *dp1++  = adc_cap * adc_lsb;
  }
  
  return 0;
}

static long subUSBDDSConfig(aSubRecord *pgsub)
{
  /*
   * Inputs:  A = Sampling frequency (MHz)
   *          B = Waveform (0-sin, 1-sqr)
   *          C = Set frequency (kHz)
   *          D = Amplitude
   *          E = DDS base address
   *
   * Outputs: A = Actual frequency (kHz)
   *          B = Actual frequency string
   *          C = Frequency error string
   *          D = M factor
   *          E = N factor
   *
   */

  double fsamp, freq, fr_act, amp;
  unsigned int M, N, addr[3], regs[3], amp_int, square, base;
  int coeff;
  
  if (USB_Debug == 2)
  {
    printf("Record %s called subUSBDDSConfig(%p, 0x%08x)\n",
           pgsub->name, (void*) pgsub, *(uint32_t *)pgsub->e);
  }

  fsamp = *(double *)pgsub->a*1000.0;
  square = *(int32_t *)pgsub->b;
  freq  = fabs(*(double *)pgsub->c);
  amp   = *(double *)pgsub->d;
  base  = *(int32_t *)pgsub->e;
  if (freq > fsamp/2) freq = fsamp/2;  

  DDSConfig(freq, fsamp, DDS0_V_MN, &fr_act, &M, &N);

  if (square)
    amp_int = (unsigned int)(amp*DDS1_V_AMP/2);
  else
    amp_int = (unsigned int)(amp*DDS_V_AMPFS + 0.5);

  coeff = (int) (16384.0/2.0/cos((M_PI*M)/(1<<17)/N) + 0.5);

  addr[0] = base;
  regs[0] = (((M/N) & DDS0_V_ADV) << DDS0_B_ADV) |
            (square << DDS0_B_SQUARE) |
            (((DDS0_V_MN+1-N) & DDS0_V_MN) << DDS0_B_MN);
  
  addr[1] = base+1;
  regs[1] = (((M%N) & DDS1_V_REM) << DDS1_B_REM) |
            ((amp_int & DDS1_V_AMP) << DDS1_B_AMP);
            
  addr[2] = base+2;
  regs[2] = (coeff & DDS2_V_INTER) << DDS2_B_INTER;
            
  usbio_mult_write(sys, addr, regs, 3);

  if (USB_Debug >= 1)
  {
    printf("0x%02x <= 0x%08x, 0x%02x <= 0x%08x, 0x%02x <= 0x%08x\n",
           addr[0], regs[0], addr[1], regs[1], addr[2], regs[2]);
    printf("M=%d,N=%d,freq=%fkHz,fr_act=%fkHz,amp=%f/%d,coeff=%d\n",
           M, N, freq, fr_act, amp, amp_int, coeff);
  }

  *(double *)pgsub->vala = fr_act;
  printFrequency((char *)pgsub->valb, fr_act*1.0e3, PRINT_HZ);
  printFrequency((char *)pgsub->valc, fabs(freq - fr_act)*1.0e3, PRINT_mHZ);
  *(int32_t *)pgsub->vald = M;
  *(int32_t *)pgsub->vale = N;

  return 0;
}

static long subUSBRotator(aSubRecord *pgsub)
{
  /*
   * Control gain/phase block of the form A + B z^-1
   *
   * Inputs:  A = Sampling frequency (MHz)
   *          B = IF frequency (kHz)
   *          C = Gain (0 to 1)
   *          D = Phase (degrees)
   *          E = Rotator base address
   *
   * Outputs: A = Computed coefficient A
   *          B = Computed coefficient B
   *
   */
  unsigned int addr;
  short int val;
  unsigned int coeff;
  double gain, phase, A, B, fsamp1, f_if1;
  static double theta, gain_scale_inv, cos_theta, fsamp = -1.0, f_if = 0.0;
  
  
  fsamp1 = *(double *)pgsub->a;
  f_if1  = *(double *)pgsub->b;
  gain   = *(double *)pgsub->c;
  phase  = *(double *)pgsub->d;
  addr   = *(int32_t *)pgsub->e;

  if (USB_Debug == 2)
  {
    printf("Record %s called subUSBDDSRotator(%p, 0x%08x)\n",
           pgsub->name, (void*) pgsub, addr);
  }
  
  if ((fsamp1 != fsamp) || (f_if1 != f_if))
  {
    /* Update static matrix elements */
    fsamp = fsamp1; f_if = f_if1;
    
    theta          = M_PI * f_if / fsamp / 500.0;
    gain_scale_inv = 1.0/sin(theta);
    cos_theta      = cos(theta);
  }
  
  /* Compute the coefficients */
  A = gain * (cos(-phase/180.0*M_PI) -
              cos_theta * sin(-phase/180.0*M_PI) * gain_scale_inv);
  B = gain * sin(-phase/180.0*M_PI) * gain_scale_inv;
  
  val = (short int)(((1<<(ROT_COEFF_BITS-2))-1.0)*A+0.5);
  coeff = (unsigned short int)val;
  coeff |= ((int)(((1<<(ROT_COEFF_BITS-2))-1.0)*B+0.5)<<ROT_COEFF_BITS);
  usbio_block_write(sys, addr, &coeff, 1);

  *(double *)pgsub->vala = A;
  *(double *)pgsub->valb = B;

  return 0;
}

enum rtna_state {
  RTNA_IDLE,
  RTNA_LOAD,
  RTNA_WAIT,
  RTNA_READ,
  RTNA_PROCESS,
};

static void *subUSBrtna_async(void *ptr)
{
  /*
   * Real-time network analyzer routine. Generate frequency vector,
   * load drive blocks, trigger, read out the results, turn off
   * the excitation.
   *
   * Inputs:  A = Adaptive integration enable (int32)
   *          B = TF averages (int32)
   *          C = Single acquisition (int32)
   *          D = Frequency span (double)
   *          E = Acquisition enable (int32)
   *          F = Half-size (int32)
   *          G = Sampling frequency, MHz (double)
   *          H = IF frequency, kHz (double)
   *          I = Excitation right shift (int32)
   *          J = Maximum integration length (int32)
   *          K = Settling wait (int32)
   *          L = Input selector (int32)
   *          M = Idle output enable
   *          N = Default integration length (int32)
   *
   * Outputs: A = Frequency 1 (float)
   *          B = Magnitude 1 (float)
   *          C = Phase 1 (float)
   *          D = Frequency 2 (float)
   *          E = Magnitude 2 (float)
   *          F = Phase 2 (float)
   *          G = Enable control (int32)
   *          K = I vector (double)
   *          L = Q vector (double)
   *          M = M (int32)
   *          N = N (int32)
   *          O = cycles (uint32)
   *          P = Total time (s) (double)
   *          Q = Memory block (uint32)
   *
   */

  double f_s, f_if, freq, freq_sb, fr_act, fmin, delta;
  double settle_time, diff, scale;
  double f_s_old = -1.0, f_if_old = -1.0, span_old = -1.0, alpha=1.0;
  double span;
  uint32_t size, idx, k, m, sb;
  uint32_t cumsum;
  uint32_t out_shift_old = 16, Ncic_old = RTNA_CICMAX+1, adapt, tf_avg;
  uint32_t Ncic_max_old = RTNA_CICMAX+1;
  uint32_t acc_delay_old = RTNAC_V_ACCDEL+1;
  uint32_t input_mux_old = RTNAC_V_INMUX+1;
  uint32_t acq_single, out_shift, Ncic, Ncic_max, acc_delay, input_mux;
  uint32_t idle_enable;
  unsigned __int128 *image;
  double complex H;
  double complex *H_old;
  int state = RTNA_IDLE, freq_update = 1;
  async_comm *async = (async_comm *)ptr;
  aSubRecord *pasub = (aSubRecord *)async->pasub;
  double *total_time = (double *)pasub->valp;
  uint32_t *cycles = pasub->valo;
  double *accI = pasub->valk, *accQ = pasub->vall;
  int64_t accI_raw, accQ_raw;
  uint32_t *M = pasub->valm, *N = pasub->valn, done;
  uint32_t *memblk = (uint32_t *)pasub->valq;
  int max_wait;

  /* Timing structures */
  struct timeval t1, t2;

  /* Wait state timeout */
  struct timeval t_wait[2];
         

  size       = *(uint32_t *) pasub->f;
  /* Allocate memory */
  image = (unsigned __int128 *)malloc(size*2*sizeof(unsigned __int128));
  H_old = (double complex *)calloc(size*2, sizeof(double complex));
  alpha = 1.0;
  
  /* Data acquisition, readback, and processing state machine */
  while (1)
  {
    switch (state)
    {
      case RTNA_IDLE:
/*        printf("RTNA_IDLE\n"); */
        pthread_mutex_lock(&async->mutex);
        if (!async->trigger) /* No trigger yet */
          pthread_cond_wait(&async->cond, &async->mutex);
          
        if (*(int32_t *)pasub->e) /* Acquisition enabled */
        {
          state = RTNA_LOAD;
          if (USB_Debug & 0x8)
            gettimeofday(&t1, NULL);
        }
        else
          state = RTNA_PROCESS;
        break;
      case RTNA_LOAD:
/*        printf("RTNA_LOAD\n"); */

          f_s        = *(double *)pasub->g*1000.0; /* Convert to kHz */
          f_if       = *(double *)pasub->h;
          adapt      = *(uint32_t *) pasub->a;
          tf_avg     = *(uint32_t *) pasub->b;
          acq_single = *(uint32_t *) pasub->c;
          span       = *(double *)pasub->d;
          out_shift  = *(int32_t *)  pasub->i;
          Ncic_max   = *(uint32_t *) pasub->j;
          acc_delay  = *(uint32_t *) pasub->k;
          input_mux  = *(uint32_t *) pasub->l;
          idle_enable = *(uint32_t *) pasub->m;
          Ncic       = *(uint32_t *) pasub->n;

        /* Minimum offset from IF */
        fmin = f_s/2/Ncic_max;
  
        /* Settling time */
        settle_time = 2.0/f_s*acc_delay;
        
        cumsum = 0;
  
        for (k = 0; k < size; k++)
        {
          if (out_shift == 15) /* SA mode, place center points on RF */
            freq = -span/2.0 + k*(span/2.0 - fmin)/(size-2);
          else
            freq = -span/2.0 + k*(span/2.0 - fmin)/(size-1);
          /* Lower sideband */
          for (sb=0; sb < 2; sb++)
          {
            idx     = sb ? 2*size - 1 - k : k;
            freq_sb = sb ? f_if - freq : f_if + freq;

            if (out_shift == 15 && k == size-1)
              freq_sb = f_if;

            DDSConfig(freq_sb, f_s, RTNAM_V_MN, &fr_act, M + idx, N + idx);
            if (adapt && freq_sb != f_if)
            {
              delta = fabs(fr_act - f_if);
              m = floor(delta*2*Ncic/f_s + 0.5);
              m = (m==0) ? 1 : m;
              while(1)
              {
                cycles[idx] = floor(f_s/2/delta*m + 0.5);
                if (cycles[idx] > RTNA_CICMAX)
                {
                  if (m == 1)
                  {
                    cycles[idx] = RTNA_CICMAX;
                    break;
                  }
                  else
                    m--;
                }
                else
                  break;
              }
            }
            else
              cycles[idx] = Ncic;
        
            cumsum += cycles[idx];
            image[idx]  = ((unsigned __int128)((M[idx]/N[idx]) & RTNAM_V_ADV)) 
                          << RTNAM_B_ADV;
            image[idx] |= ((unsigned __int128)((DDS_N_FS-N[idx]) & RTNAM_V_MN))
                          << RTNAM_B_MN;
            image[idx] |= ((unsigned __int128)((M[idx]%N[idx]) & RTNAM_V_REM))
                          << RTNAM_B_REM;
            image[idx] |= ((unsigned __int128)((cycles[idx]-2) & RTNAM_V_CYC))
                          << RTNAM_B_CYC;
          }
        }
  
        /* Memory copy */
        for (k = 0; k < 2*size; k++)
        {
          uint32_t val;

          val = (uint32_t)(image[k] & 0x3ffff); /* 18 least significant bits */
          memblk[k] = val;
          val = (uint32_t)((image[k]>>18) & 0x3ffff); /* next 18 bits */
          memblk[k + 2*size] = val;
          val = (uint32_t)((image[k]>>36) & 0x3ffff); /* 18 more bits */
          memblk[k + 4*size] = val;
          val = (uint32_t)((image[k]>>54) & 0x3ffff); /* last 18 */
          memblk[k + 6*size] = val;
        }

        memblk[8*size]  = ((acc_delay-1) & RTNAC_V_ACCDEL) << RTNAC_B_ACCDEL;
        memblk[8*size] |= (out_shift & RTNAC_V_OUTSFT) << RTNAC_B_OUTSFT;
        memblk[8*size] |= (input_mux & RTNAC_V_INMUX ) << RTNAC_B_INMUX ;
        memblk[8*size] |= RTNAC_V_START << RTNAC_B_START ;
        memblk[8*size] |= idle_enable << RTNAC_B_IDLEEN;

        /* Write the excitation config and trigger measurement */
        usbio_block_write(sys, RTNA_A_BASE, (unsigned *)memblk,
                          RTNA_A_CTRL-RTNA_A_BASE+1);

        /* Compute measurement time */
        *total_time = 2.0e-3*size*settle_time + 2.0e-3/f_s*cumsum;
        
        /* If measurement time is more than half of T_RTNA_WAIT_MAX,
           set maximum wait time to twice that */
        if (*total_time*2.0e6 > T_RTNA_WAIT_MAX)
          max_wait = *total_time*2.0e6;
        else
          max_wait = T_RTNA_WAIT_MAX;
          
        /* Check controls and decide if we need to reset the averaging */
        if ((span      == span_old) &&
            (f_s       == f_s_old) &&
            (f_if      == f_if_old) &&
            (out_shift == out_shift_old) &&
            (Ncic      == Ncic_old) &&
            (Ncic_max  == Ncic_max_old) &&
            (acc_delay == acc_delay_old) &&
            (input_mux == input_mux_old))
          alpha = 1.0 / (double) tf_avg;
        else
          alpha = 1.0;
  
        /* Decide if we need to recalculate frequency */
        if ((span      == span_old) &&
            (f_if      == f_if_old) &&
            (f_s       == f_s_old) &&
            (Ncic      == Ncic_old) &&
            (Ncic_max  == Ncic_max_old))
          freq_update = 0;
        else
          freq_update = 1;

        /* Copy */
        span_old = span; f_s_old = f_s; f_if_old = f_if;
        out_shift_old = out_shift; Ncic_old = Ncic; Ncic_max_old = Ncic_max;
        acc_delay_old = acc_delay; input_mux_old = input_mux;

        gettimeofday(t_wait, NULL);
        state = RTNA_WAIT;
      case RTNA_WAIT:
        usbio_block_read(sys, RTNA_A_STAT, &done ,1);
        if (done)
          state = RTNA_READ;
        else
        {
          /* Don't wait more than a limit */
          gettimeofday(t_wait+1, NULL);
          if (deltaT(t_wait, t_wait+1) > max_wait)
          {
            uint32_t atrig[2], dtrig[2];
            /* Reset the state machine */
            atrig[0] = RTNA_A_CTRL; dtrig[0] = memblk[8*size] | RTNAC_M_FSMRST;
            atrig[1] = RTNA_A_CTRL; dtrig[1] = memblk[8*size] & ~RTNAC_M_FSMRST;
            unsigned int rc = usbio_mult_write(sys, atrig, dtrig, 2);
            if (rc != 2)
            {
              if (USB_Debug == 1)
                printf("Write error, resetting USB IO (2)\n");
              usbio_if_reset(sys);
            }
            state     = RTNA_LOAD;
          }
          else
          {
            usleep(T_RTNA_WAIT);
            break;
          }
        }
      case RTNA_READ:
/*        printf("RTNA_READ\n"); */
        /* If single selected, write 0 to acquisition enable */
        if (acq_single)
          *(int32_t *)pasub->valg = 0;
        else
          *(int32_t *)pasub->valg = 1;

        /* Reset trigger */
        *memblk = memblk[8*size] & ~RTNAC_M_START;
        usbio_block_write(sys, RTNA_A_CTRL, (unsigned *)memblk, 1);

        /* Read out the results */
        usbio_block_read(sys, RTNA_A_BASE, (unsigned *)memblk,
                         RTNA_A_CTRL-RTNA_A_BASE);
        
        /* Compute uniform factors (frequency independent) */
        scale = 0.5 / 8191.0; /* Full scale amplitude */
          
        if (out_shift < 15)
          scale *= (1<<out_shift); /* Output amplitude */
  
        /* Split into 36 bit I and Q, calculate TF */
        for (k = 0; k < 2*size; k++)
        {
          float mag, phase, phase_old;
          double theta = 2*M_PI*M[k]/N[k]/(1<<17);

          int64_t mask = (-1LL)<<(35);
          accI_raw = memblk[k] | ((uint64_t)memblk[k+2*size] <<18);
          accQ_raw = memblk[k+4*size] | ((uint64_t)memblk[k+6*size] <<18);
          accI[k] = (double)((accI_raw + mask) ^ mask);
          accQ[k] = (double)((accQ_raw + mask) ^ mask);
    
          /* Convert to complex value, perform calibration */
          H = accI[k] - I*accQ[k];
#if 0
          H *= scale/(cycles[k] * sin(theta) * sqrt(2.0 - 2.0*cos(theta)));
#else
          H *= scale/cycles[k]/sin(theta);
#endif
    
          /* Perform the averaging */
          if (out_shift < 15)
          {
            H = alpha*H + (1.0-alpha)*H_old[k];
            H_old[k] = H;
          }
    
          if (out_shift == 15)
          {
            /* Magnitude averaging only, phase is irrelevant */
            mag = (float)(alpha*10.0*log10(creal(H*conj(H))+1.0e-14) + (1.0-alpha)*H_old[k]);
            H_old[k] = mag;
            phase = NAN;
          }
          else
          {
            double delays[] = RTNA_DELAYS;
            double gains[] = RTNA_GAINS;
            mag   = (float)(10.0*log10(gains[input_mux]*creal(H*conj(H))+1.0e-14));
            double complex del = cexp_loc(I*delays[input_mux]*theta);
            phase = (float)(180.0*carg_loc(H*del)/M_PI);
          }
    
          /* Unwrap the phase */  
          if ((k != 0) && (k != size))
            if (fabsf(phase-phase_old) > 180.0)
              phase += copysignf(360.0, phase_old-phase);
    
          /* Wrap once we get to 200 */
          /*    if (fabsf(phase) > 200.0)
            phase -= copysignf(360.0, phase); */
          phase_old = phase;

          if (k < size)
          {
            if (freq_update)
              *((float *)pasub->vala+k) = (float)(theta/2/M_PI*f_s - f_if);
            *((float *)pasub->valb+k) = mag;
            *((float *)pasub->valc+k) = phase;
          }
          else
          {
            if (freq_update)
              *((float *)pasub->vald+k-size) = (float)(theta/2/M_PI*f_s - f_if);
            *((float *)pasub->vale+k-size) = mag;
            *((float *)pasub->valf+k-size) = phase;
          }
        }
        
        if (USB_Debug & 0x8)
        {
          gettimeofday(&t2, NULL);
          diff = deltaT(&t1, &t2);
          printf("Read/process time (rtna): %.3f ms\n", ((double)diff)/1000.0);
        }
        state = RTNA_PROCESS;
      case RTNA_PROCESS:
        async->trigger = ASYNC_DONE;
        pthread_mutex_unlock(&async->mutex);
      
        /* Call process() to finish record processing */
        struct dbCommon *precord = (struct dbCommon *)pasub;
        struct rset *prset=(struct rset *)(precord->rset);
        dbScanLock(precord);
        (*prset->process)(precord);
        dbScanUnlock(precord);
        state = RTNA_IDLE;
    }
  }
  
  /* Never reached */
  return NULL;
}

static long subUSBrtna(aSubRecord *pasub)
{
  static int first = 1;
  int rc = 0;
  static async_comm async;
  static pthread_t async_thread;
  
  if (first)
  {
    pthread_mutex_init(&async.mutex, NULL);
    pthread_cond_init(&async.cond, NULL);
    async.pasub = pasub;
    async.trigger = ASYNC_IDLE;
    pthread_create(&async_thread, NULL, subUSBrtna_async, (void *)&async);
    first = 0;
  }
  
  /* As we get to this point, there are two possibilities
     1. This is an initial call to routine, need to trigger async thread
     2. A second call at the end of async processing
  */  
  pthread_mutex_lock(&async.mutex);
  if (async.trigger == ASYNC_DONE)
  {
    async.trigger = ASYNC_IDLE;
    pasub->pact   = 0;
  }
  else if (async.trigger == ASYNC_IDLE)
  {
    pasub->pact   = 1;
    async.trigger = ASYNC_TRIGGER;
    pthread_cond_signal(&async.cond); /* Send a signal to the async thread */
  }
  else
  {
    fprintf(stderr, "Unexpected trigger state ASYNC_TRIGGER in subUSBrtna()\n");
    rc = 1;
  }
  pthread_mutex_unlock(&async.mutex);

  return rc;
}

enum ramp_state {
  RAMP_IDLE,
  RAMP_START,
  RAMP_WAITING,
  RAMP_PREP,
  RAMP_LOADING,
  RAMP_LOAD_ONCE
};

static void copy_ramp(int *amp, int *phase, unsigned *data, double *amp_in,
                      double *phase_in, double *scale, double *ph_offset)
{
  int k;

  for (k = 0; k < RAMP_LENGTH; k++)
  {
    amp[k] = (unsigned)(amp_in[k] * *scale *DAC_V_AMPFS + 0.5);
    if (amp[k] > DAC_V_AMPFS) amp[k] = DAC_V_AMPFS; /* Limit */
    phase[k] = (int)((phase_in[k] + *ph_offset)*65536.0/180.0 + 0.5);
    data[k] = amp[k] | (phase[k] << 15);
  }  
}

static long subUSBRampLoad(aSubRecord *pasub)
{
  /*
   *          A = Amplitude profile
   *          B = Phase profile
   *          C = Amplitude change rate
   *          D = Phase change rate
   *          E = Amplitude to reference scaling factor
   *          F = Ramp control register
   *          G = Load enable
   *          H = Negative channel 0 phase offset
   *
   * Outputs: A = Loading control
   *          B = Currently loaded amplitude profile
   *          C = Currently loaded phase profile
   *          D = Current amplitude start point
   *          E = Current amplitude end point
   *          F = Current phase start point
   *          G = Current phase end point
   *
   */
  static int state = RAMP_IDLE, phase_current, amp_done = 0, phase_done = 0;
  static int amp_current, goal;
  static double amp_current_d;
  static uint32_t ctrl, busy, addr, offset, stat;
  static uint32_t ctrl_old = 0xffffffff;
  double amp_step;
  unsigned data[RAMP_LENGTH], phase_step, data1[RAMP_LENGTH];
  int amp[RAMP_LENGTH], phase[RAMP_LENGTH], k, *load;
  
  double *scale = (double *)pasub->e;
  double *amp_d = (double *)pasub->a;
  double *ph_offset = (double *)pasub->h;
  
  ctrl = *(uint32_t *)pasub->f;
  load = (int *)pasub->g;

  /* Default to continue loading */
  *(int32_t *)pasub->vala = 1;

  /* Don't waste CPU cycles in idle state */
  if (state != RAMP_IDLE)
    copy_ramp(amp, phase, data, amp_d, (double *)pasub->b,
              scale, ph_offset);

/*  amp_step = (unsigned)(*(double *)pasub->c * *scale * DAC_V_AMPFS + 0.5);
  phase_step = (unsigned) (*(double *)pasub->d *65536.0/180.0 + 0.5);
*/
  amp_step   = *(double *)pasub->c;
  phase_step = (unsigned) (*(double *)pasub->d *65536.0/180.0 + 0.5);
  if (phase_step == 0) phase_step = 1;

  while (1)
  {
    switch (state)
    {
      case RAMP_IDLE:
        if (ctrl != ctrl_old)
          usbio_block_write(sys, SETPT_A_CTRL, &ctrl, 1);
        ctrl_old = ctrl;
        
        if (*load)
        {
          state = RAMP_START;
          break;
        }
        else
        {
          *(int32_t *)pasub->vala = 0;
          return 0;
        }
      case RAMP_START:
/*        printf("State RAMP_START\n"); */
        copy_ramp(amp, phase, data, amp_d, (double *)pasub->b,
                  scale, ph_offset);
        amp_done = phase_done = 0;

        /* Switch to internal trigger, dual trigger mode */
        ctrl = ctrl_old & ~SETPT_M_TRIGEN;
        ctrl &= ~SETPT_M_MODE;
        ctrl |= SETPT_MODE_DUAL<<SETPT_B_MODE;
        usbio_block_write(sys, SETPT_A_CTRL, &ctrl, 1);

        /* Read out the status, figure out where we are */
        usbio_read(sys, SETPT_A_STAT, &stat);
        
        busy = (stat >> SETPT_B_BUSY) & SETPT_V_BUSY;
        
        if (busy)
        {
          state = RAMP_WAITING;
          return 0;
        }
        else
          state = RAMP_PREP;
        break;
      case RAMP_WAITING:
/*        printf("State RAMP_WAITING\n"); */
        /* Read out the trigger, figure out where we are */
        usbio_read(sys, SETPT_A_STAT, &stat);
        busy = (stat >> SETPT_B_BUSY) & SETPT_V_BUSY;
        if (busy)
          return 0;
        
        /* Not busy, get ready to load active setpoint. Read out the
           current value */
        state = RAMP_PREP;
        break;
      
      case RAMP_PREP:
/*        printf("State RAMP_PREP\n"); */
        /* Read and parse current profiles */
        usbio_block_read(sys, SETPT_A_BLOCK, data1, RAMP_LENGTH);
        for (k = 0; k < RAMP_LENGTH; k++)
        {
          ((double *)pasub->valb)[k] = (double)(data1[k] & 0x3fff)/DAC_V_AMPFS/ *scale;
          ((double *)pasub->valc)[k] = phase_clip((double)((data1[k] >> 15) & 0x3ffff)*180.0/65536.0 - *ph_offset);
        }
        /* Copy start and end points */
        *(double *)pasub->vald = *(double *)pasub->valb;
        *(double *)pasub->vale = ((double *)pasub->valb)[RAMP_LENGTH-1];
        *(double *)pasub->valf = *(double *)pasub->valc;
        *(double *)pasub->valg = ((double *)pasub->valc)[RAMP_LENGTH-1];
        
        /* Read out the status, figure out where we are */
        usbio_read(sys, SETPT_A_STAT, &stat);
        
        /* Not busy, let's start loading */
        addr = (stat >> SETPT_B_ADDR) & SETPT_V_ADDR;
        amp_current = data1[addr] & 0x3fff;
        amp_current_d = (double)amp_current/DAC_V_AMPFS/ *scale;
        phase_current = (data1[addr] >> 15) & 0x3ffff;
        /* Sign extend phase */
        struct {signed int s:17;} foo;
        foo.s = phase_current; phase_current = foo.s;
        
        /* Figure out the short way to the goal */
        int delta = phase[addr] - phase_current;
        if (abs(delta) > SETPT_PHASE_180)
          goal = phase[addr] + SETPT_PHASE_180*2*((delta<0)?1:-1);
        else
          goal = phase[addr];
        
        state = RAMP_LOADING;
        break;
      
      case RAMP_LOADING:
/*
        printf("State RAMP_LOADING (amp %d %d %d  phase %d %d %d)\n", 
               amp_current, amp[addr], amp_step, phase_current, phase[addr],
               phase_step);
*/
        /* Now we are loading the active setpoint. Take rate limiting into
           account */
        if (abs(goal - phase_current) <= phase_step || amp_current == 0)
        {
          phase_current = goal;
          phase_done = 1;
        }
        else
          phase_current += (goal-phase_current > 0) ? phase_step : -phase_step;

        if (abs(amp_d[addr] - amp_current_d) <= amp_step)
        {
          amp_current_d = amp_d[addr];
          amp_done = 1;
        }
        else
          /* Ramp in double space, not integer */
          amp_current_d += (amp_d[addr]-amp_current_d > 0.0) ? amp_step : -amp_step;
        
        /* Convert to integer */
        amp_current = (unsigned)(amp_current_d * *scale * DAC_V_AMPFS + 0.5);
        if (amp_current > DAC_V_AMPFS) /* Limit */
          amp_current   = DAC_V_AMPFS;
        
        /* Write the value */
        k = amp_current | (phase_current << 15);
        usbio_block_write(sys, SETPT_A_BLOCK + addr, (unsigned *)&k, 1);

        /* Update current start/end point and profile */
        if (addr == 0) /* Start */
        {
          *(double *)pasub->valb = (double)amp_current/DAC_V_AMPFS/ *scale;
          *(double *)pasub->valc = phase_clip((double)phase_current*180.0/65536.0 - *ph_offset);
          *(double *)pasub->vald = *(double *)pasub->valb;
          *(double *)pasub->valf = *(double *)pasub->valc;
        }
        else /* End */
        {
          ((double *)pasub->valb)[addr] = (double)amp_current/DAC_V_AMPFS/ *scale;
          ((double *)pasub->valc)[addr] = phase_clip((double)phase_current*180.0/65536.0 - *ph_offset);
          *(double *)pasub->vale = ((double *)pasub->valb)[addr];
          *(double *)pasub->valg = ((double *)pasub->valc)[addr];
        }
                
        if (amp_done & phase_done)
          state = RAMP_LOAD_ONCE;
        else
          return 0;
      case RAMP_LOAD_ONCE:
/*        printf("State RAMP_LOAD_ONCE\n"); */
        
        /* Load the rest of the profile */
        if (addr == 0)
          offset = 1;
        else if (addr == 511)
          offset = 0;
        else
        {
          printf("Address at 0x%x, expect 0 or 511\n", addr);
          return 1;
        }
#if 1
        usbio_block_write(sys, SETPT_A_BLOCK + offset, 
                          data + offset, RAMP_LENGTH-1);
#else
        for (k = 0; k < RAMP_LENGTH-1; k++)
          usbio_block_write(sys, SETPT_A_BLOCK + offset + k, data + offset +k, 1);
#endif
        /* Restore the control register */
        usbio_block_write(sys, SETPT_A_CTRL, &ctrl_old, 1);

        /* Read and parse current profiles */
        usbio_block_read(sys, SETPT_A_BLOCK, data1, RAMP_LENGTH);
        for (k = 0; k < RAMP_LENGTH; k++)
        {
          ((double *)pasub->valb)[k] = (double)(data1[k] & 0x3fff)/DAC_V_AMPFS/ *scale;
          ((double *)pasub->valc)[k] = phase_clip((double)((data1[k] >> 15) & 0x3ffff)*180.0/65536.0 - *ph_offset);
        }
        /* Copy start and end points */
        *(double *)pasub->vald = *(double *)pasub->valb;
        *(double *)pasub->vale = ((double *)pasub->valb)[RAMP_LENGTH-1];
        *(double *)pasub->valf = *(double *)pasub->valc;
        *(double *)pasub->valg = ((double *)pasub->valc)[RAMP_LENGTH-1];

        /* Stop processing */
        *(int32_t *)pasub->vala = 0;
        state = RAMP_IDLE;
        return 0;
    }
  }
        
  return 0;
}

static long subUSBreadI2C(aSubRecord *pasub)
{
  /*
  * This function reads hardware constants from FX2 I2C EEPROM and
  * outputs them to individual PVS
  *
  * EEPROM layout (16 bit integers)
  * 0x20 - Channel 0 full scale (dBm * 1e4)
  * 0x22 - Channel 1 full scale (dBm * 1e4)
  * 0x24 - Channel 2 full scale (dBm * 1e4)
  * 0x26 - Channel 3 full scale (dBm * 1e4)
  * 0x28 - Channel 0 phase offset (deg/180*32768) 
  * 0x2a - Channel 1 phase offset (deg/180*32768) 
  * 0x2c - Channel 2 phase offset (deg/180*32768) 
  * 0x2e - LO power meter slope (mV/V)
  * 0x30 - LO power meter offset (mV)
  * 0x32 - LO loss factor (db*1e3)
  * 0x34 - Output power meter slope (mV/uV)
  * 0x36 - Output power meter offset divided by 2 (uV)
  *
  * Outputs: A = Channel 0 full scale (dBm)
  *          B = Channel 1 full scale (dBm)
  *          C = Channel 2 full scale (dBm)
  *          D = Channel 3 full scale (dBm)
  *          E = Channel 0 phase offset (deg)
  *          F = Channel 1 phase offset (deg)
  *          G = Channel 2 phase offset (deg)
  *          H = LO power meter slope (mV/V)
  *          I = LO power meter offset (mV)
  *          J - LO loss factor (dB)
  *          K - Output power meter slope (mV/mV)
  *          L - Output power meter offset (mV)
  */
  
  char buf[32];
  uint16_t *pa = (uint16_t *)buf;
  int16_t *pp = (int16_t *)buf;
  int rc;
  
  rc = usbio_eeprom_read(sys, EEPROM_OFFSETS, buf, 32, 0);
  if (rc != 32)
    fprintf(stderr, "subUSBreadI2C: I2C read failed, rc = %d\n", rc);
  
  *(double *)pasub->vala = (double)pa[0] / 10000.0;
  *(double *)pasub->valb = (double)pa[1] / 10000.0;
  *(double *)pasub->valc = (double)pa[2] / 10000.0;
  *(double *)pasub->vald = (double)pa[3] / 10000.0;
  *(double *)pasub->vale = (double)pp[4] / 32768.0 * 180;
  *(double *)pasub->valf = (double)pp[5] / 32768.0 * 180;
  *(double *)pasub->valg = (double)pp[6] / 32768.0 * 180;
  *(double *)pasub->valh = (double)pp[7];
  *(double *)pasub->vali = (double)pp[8];
  *(double *)pasub->valj = (double)pp[9] / 1000.0;
  *(double *)pasub->valk = (double)pp[10] / 1000.0;
  *(double *)pasub->vall = (double)pp[11] / 500.0;

  return 0;  
}

static long subUSBrates(aSubRecord *pasub)
{
  /*
  * Read word counters from usbio and calculates transfer rates
  *
  * Outputs: A = Write to FPGA (kiB/s)
  *          B = Read from FPGA (kiB/s)
  */
  unsigned long long write, read;
  static unsigned long write_old, read_old;
  static char first = 1;
  
  usbio_get_counts(sys, &write, &read);
  if (first)
  {
    write_old = write;
    read_old  = read;
    first     = 0;
  }
  
  *(double *)pasub->vala = ((double)(write-write_old))/256.0;
  *(double *)pasub->valb = ((double)(read-read_old))/256.0;
  
  /* Save the values */
  write_old = write; read_old = read;

  return 0;  
}

static registryFunctionRef subUSBRef[] = {
  {"subUSBinit",   (REGISTRYFUNCTION)subUSBinit},
  {"subUSBwrite",  (REGISTRYFUNCTION)subUSBwrite},
  {"subUSBread",   (REGISTRYFUNCTION)subUSBread},
  {"subUSBacq",   (REGISTRYFUNCTION)subUSBacq},
  {"subUSBbbacq",   (REGISTRYFUNCTION)subUSBbbacq},
  {"subUSBpoll",   (REGISTRYFUNCTION)subUSBpoll},
  {"subUSBlmk01801_ext", (REGISTRYFUNCTION)subUSBlmk01801_ext},
  {"subUSBlmk01801_int", (REGISTRYFUNCTION)subUSBlmk01801_int},
  {"subUSBad9512", (REGISTRYFUNCTION)subUSBad9512},
  {"subUSBad9512sync", (REGISTRYFUNCTION)subUSBad9512sync},
  {"subUSBlmk01801sync", (REGISTRYFUNCTION)subUSBlmk01801sync},
  {"subUSBDDSConfig", (REGISTRYFUNCTION)subUSBDDSConfig},
  {"subUSBRotator", (REGISTRYFUNCTION)subUSBRotator},
  {"subUSBrtna", (REGISTRYFUNCTION)subUSBrtna},
  {"subUSBreadI2C", (REGISTRYFUNCTION)subUSBreadI2C},
  {"subUSBrates", (REGISTRYFUNCTION)subUSBrates},
  {"subUSBRampLoad", (REGISTRYFUNCTION)subUSBRampLoad}
};

static void subUSBRegistrar(void)
{
  registryFunctionRefAdd(subUSBRef, NELEMENTS(subUSBRef));
}
epicsExportRegistrar(subUSBRegistrar);
