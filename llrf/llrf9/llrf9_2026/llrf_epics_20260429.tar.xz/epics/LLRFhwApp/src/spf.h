/*
 Signal processing functions
 
 Copyright (c) 2009 Dimtel, Inc., All Rights Reserved

 $Id: spf.h,v 1.1 2017/03/10 19:44:56 dim Exp $
 $Date: 2017/03/10 19:44:56 $
 $Author: dim $
 $Revision: 1.1 $
 $Log: spf.h,v $
 Revision 1.1  2017/03/10 19:44:56  dim
 Initial import

*/

#ifndef _SPF_H_
#define _SPH_H_

void spf_mean(double *in, double *out, int step, int turns);
void spf_rms(double *in, double *out, int step, int turns);
int spf_max(double *in, double *mval, int nelm);
int spf_min(double *in, double *mval, int nelm);
void spf_mean_f(float *in, double *out, int step, int turns);
void spf_rms_f(float *in, double *out, int step, int turns);
int spf_max_f(float *in, double *mval, int nelm);
int spf_min_f(float *in, double *mval, int nelm);
void spf_fir(double *in, double *out, int step, int turns,
             double *coeff, int clen);

#endif /* _SPF_H_ */
