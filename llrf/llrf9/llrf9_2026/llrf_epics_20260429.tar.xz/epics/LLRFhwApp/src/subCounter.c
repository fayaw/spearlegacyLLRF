/*
 Error/event counters
 
 Copyright (c) 2010 Dimtel, Inc., All Rights Reserved

 $Id: subCounter.c,v 1.1 2017/03/10 19:44:56 dim Exp $
 $Date: 2017/03/10 19:44:56 $
 $Author: dim $
 $Revision: 1.1 $
 $Log: subCounter.c,v $
 Revision 1.1  2017/03/10 19:44:56  dim
 Initial import

*/

#include   <dbDefs.h>
#include   <registryFunction.h>
#include   <subRecord.h>
#include   <epicsExport.h>
#include   <stdio.h>

typedef long (*processMethod)(subRecord *precord);

static long subCounterInit(subRecord *psub, processMethod process)
{
  psub->val = 0;
  return 0;
}

static long subCounter(subRecord *psub)
{
  /*
   * Inputs:  A = Reset input
   *          B = Enable input
   *          VAL = (A) ? 0 : (B) ? VAL++ : VAL
   */

  if (psub->a)
    psub->val = 0;
  else if (psub->b)
    psub->val++;

  return 0;
}

static registryFunctionRef subCounterRef[] = {
  {"subCounterInit", (REGISTRYFUNCTION)subCounterInit},
  {"subCounter", (REGISTRYFUNCTION)subCounter}
};

static void subCounterRegistrar(void)
{
  registryFunctionRefAdd(subCounterRef, NELEMENTS(subCounterRef));
}
epicsExportRegistrar(subCounterRegistrar);
