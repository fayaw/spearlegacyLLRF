/*
 Miscellaneous subroutines
 
 Copyright (c) 2006-2015 Dimtel, Inc., All Rights Reserved

 $Id: subMisc.c,v 1.6 2023/09/08 19:19:08 dim Exp $
 $Date: 2023/09/08 19:19:08 $
 $Author: dim $
 $Revision: 1.6 $
 $Log: subMisc.c,v $
 Revision 1.6  2023/09/08 19:19:08  dim
 Series 2 and 3 merge

 Revision 1.5  2022/11/13 23:33:22  dim
 Added configuration register parsing

 Revision 1.4  2022/08/31 18:35:35  dim
 Series 3 changes

 Revision 1.3  2019/11/19 04:31:57  dim
 Fixed ramp length calculation, added long value copy aSub

 Revision 1.2  2019/11/15 05:50:51  dim
 subMiscStringCp expanded to 6 outputs

 Revision 1.1  2017/03/10 19:44:57  dim
 Initial import

*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <netdb.h>

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <dbAccess.h>
#include <math.h>
#include <complex.h>

#include "LLRFhw.h"
#include "common.h"
#include "dacq.h"
#include "cmath.h"
#include "map.h"

typedef long (*processMethod)(subRecord *precord);

static long subMiscInit(subRecord *psub, processMethod process)
{
  psub->val = 0;
  return 0;
}

static long subIPaddr(aSubRecord *pgsub)
{
  /*
   * Outputs: A = IP address string
   */
  char host_name[256], ip_addr[16];
  struct hostent *host;
  
  gethostname(host_name, 256);
  host = gethostbyname(host_name);
  
  sprintf(ip_addr, "%hhu.%hhu.%hhu.%hhu", host->h_addr[0], host->h_addr[1],
          host->h_addr[2], host->h_addr[3]);

  memcpy(pgsub->vala, ip_addr, strlen(ip_addr)+1);
  
  return 0;
}

/* Fan out an input through channel access */
static long subMiscFanout(subRecord *psub)
{
  /*
   * Outputs: A = Input value
   *          B = Number of output links
   *          C = Links...
   */
  int n = (int)psub->b;
    
  if (n > 0)
    dbPutLink(&psub->inpc, DBR_DOUBLE, &psub->a, 1);
  if (n > 1)
    dbPutLink(&psub->inpd, DBR_DOUBLE, &psub->a, 1);
  if (n > 2)
    dbPutLink(&psub->inpe, DBR_DOUBLE, &psub->a, 1);
  if (n > 3)
    dbPutLink(&psub->inpf, DBR_DOUBLE, &psub->a, 1);
  if (n > 4)
    dbPutLink(&psub->inpg, DBR_DOUBLE, &psub->a, 1);
  if (n > 5)
    dbPutLink(&psub->inph, DBR_DOUBLE, &psub->a, 1);
  if (n > 6)
    dbPutLink(&psub->inpi, DBR_DOUBLE, &psub->a, 1);
  if (n > 7)
    dbPutLink(&psub->inpj, DBR_DOUBLE, &psub->a, 1);
  if (n > 8)
    dbPutLink(&psub->inpk, DBR_DOUBLE, &psub->a, 1);
  if (n > 9)
    dbPutLink(&psub->inpl, DBR_DOUBLE, &psub->a, 1);
  
  return 0;
}

static long subMiscDS1822ROM(aSubRecord *pgsub)
{
  /*
   * Input:   A = ROM array (2x32)
   * Outputs: A = Serial number string
   *          B = Checksum status (0 - OK)
   *          C = Device ID
   *          D = Future scan disable
   */
  unsigned char rom[8], crc;
  unsigned char table[256] = 
  {0, 94, 188, 226, 97, 63, 221, 131, 194, 156, 126, 32, 163, 253, 31, 65,
   157, 195, 33, 127, 252, 162, 64, 30, 95, 1, 227, 189, 62, 96, 130, 220,
   35, 125, 159, 193, 66, 28, 254, 160, 225, 191, 93, 3, 128, 222, 60, 98,
   190, 224, 2, 92, 223, 129, 99, 61, 124, 34, 192, 158, 29, 67, 161, 255,
   70, 24, 250, 164, 39, 121, 155, 197, 132, 218, 56, 102, 229, 187, 89, 7,
   219, 133, 103, 57, 186, 228, 6, 88, 25, 71, 165, 251, 120, 38, 196, 154,
   101, 59, 217, 135, 4, 90, 184, 230, 167, 249, 27, 69, 198, 152, 122, 36,
   248, 166, 68, 26, 153, 199, 37, 123, 58, 100, 134, 216, 91, 5, 231, 185,
   140, 210, 48, 110, 237, 179, 81, 15, 78, 16, 242, 172, 47, 113, 147, 205,
   17, 79, 173, 243, 112, 46, 204, 146, 211, 141, 111, 49, 178, 236, 14, 80,
   175, 241, 19, 77, 206, 144, 114, 44, 109, 51, 209, 143, 12, 82, 176, 238,
   50, 108, 142, 208, 83, 13, 239, 177, 240, 174, 76, 18, 145, 207, 45, 115,
   202, 148, 118, 40, 171, 245, 23, 73, 8, 86, 180, 234, 105, 55, 213, 139,
   87, 9, 235, 181, 54, 104, 138, 212, 149, 203, 41, 119, 244, 170, 72, 22,
   233, 183, 85, 11, 136, 214, 52, 106, 43, 117, 151, 201, 74, 20, 246, 168,
   116, 42, 200, 150, 21, 75, 169, 247, 182, 232, 10, 84, 215, 137, 107, 53};
  unsigned *inrom = (unsigned *)pgsub->a, k;
  unsigned long long serial;
  
  /* Convert in host-independent way */
  rom[0] = (inrom[0]      ) & 0xff;
  rom[1] = (inrom[0] >>  8) & 0xff;
  rom[2] = (inrom[0] >> 16) & 0xff;
  rom[3] = (inrom[0] >> 24) & 0xff;
  rom[4] = (inrom[1]      ) & 0xff;
  rom[5] = (inrom[1] >>  8) & 0xff;
  rom[6] = (inrom[1] >> 16) & 0xff;
  rom[7] = (inrom[1] >> 24) & 0xff;

  for (k = 0, crc = 0; k < 8; k++)
    crc = table[crc ^ rom[k]];
    
  *(char *) pgsub->valb = crc ? 1 : 0;
  *(char *) pgsub->valc = rom[0];
  *(char *) pgsub->vald = 1; /* Only first pass needed */

  serial = (unsigned long long)((inrom[0] >> 8) & 0xffffff) | 
           ((unsigned long long)(inrom[1] & 0xffffff) << 24);
  sprintf(pgsub->vala, "%012llx", serial);
/*  printf("DS1822: 0x%08x, 0x%08x, %llx\n", inrom[0], inrom[1], serial);*/ 

  return 0;
}

static long subMiscIQ2AmpPhase(aSubRecord *pgsub)
{
  /*
   * Input:   A = I vector (double x5, ADC counts)
   *          B = Q vector (double x5, ADC counts)
   * Outputs: A = Raw amplitude (double x5)
   *          B = Raw phase (double x5)
              C = Calibrated phase (double x4)
              D = Calibrated amplitude (double x4)
   */
  int ch;
  double *p_I, *p_Q, *p_amp_raw, *p_phs_raw;
  double *p_amp, *p_phs, delta;
  double complex z;

  p_I = pgsub->a; p_Q = pgsub->b;
  p_amp_raw = pgsub->vala; p_phs_raw = pgsub->valb;
  for (ch = 0; ch < 5; ch++)
  {
    /* This assignment evaluates p_Q 4 times, leading to wild
       increment if p_Q++ is used */
    z            = *p_I - *p_Q*I;
    p_I++; p_Q++;
    *p_amp_raw++ = cabs(z);
    *p_phs_raw++  = carg(z)/M_PI*180.0;
  }
  
  /* Now perform calibration */
  p_amp_raw = pgsub->vala; p_phs_raw = pgsub->valb;
  p_amp = pgsub->valc; p_phs = pgsub->vald;

  for (ch = 0; ch < 5; ch++)
  {
    if (ch != LLRF_REF_CHAN) /* Skip reference channel */
    {
      delta = phase_clip(p_phs_raw[ch] - p_phs_raw[LLRF_REF_CHAN]);
      *p_phs++ = delta;
    
      /* No amplitude calibration */
      *p_amp++ = p_amp_raw[ch];
    }
  }
  return 0;
}

static long subMiscADC2Phys(aSubRecord *pgsub)
{
  /*
   * Input:   A = Amplitude (ADC counts)
   *          B = Phase (relative to reference)
              C = Input full-scale level (dBm)
              D = Coupling (dB)
              E = Format (0 - volts, 1 - watts)
              F = Phase offset
   * Outputs: A = Converted amplitude
   *          B = Offset phase
   *          C = Conversion factor, EGU/count
   */
  double phase;
  double amp = *(double *)pgsub->a;
  double Pfs = *(double *)pgsub->c;
  double C   = *(double *)pgsub->d;
  
  /* Copy the phase */
  phase = *(double *)pgsub->b + *(double *)pgsub->f;
  *(double *)pgsub->valb = phase_clip(phase);

#if 0  
  double dBm_in, dBm_src;
  /* Convert ADC counts to dBm */
  dBm_in = Pfs + 20*log10(amp) - 20*log10(ADC_FS);
  dBm_src = dBm_in + C;
  
  if (*(int *)pgsub->e == 1)
    /* Power output, aim for W */
    *(double *)pgsub->vala = pow(10.0, dBm_src/10.0 - 3);
  else
    /* Voltage output, volts amplitude into 50 ohms */
    *(double *)pgsub->vala = pow(10.0, dBm_src/20.0) * V_AMP_0DBM;
#else
  double scale;
  
  if (*(int *)pgsub->e == 0) /* Voltage */
  {
    scale = V_AMP_0DBM * pow(10.0, (Pfs+C)/20.0) / ADC_FS;
    *(double *)pgsub->vala = scale * amp;
  }
  else
  {
    scale = pow(10.0, (Pfs+C)/10.0 - 3) / ADC_FS / ADC_FS;
    *(double *)pgsub->vala = scale * amp * amp;
  }
  *(double *)pgsub->valc = scale;
#endif
    
  return 0;
}

static long subMiscPhys2ADC(aSubRecord *pgsub)
{
  /*
   * Input:   A = Value to convert (physical units)
   *          B = Conversion scale (generated by ADC2Phys)
              C = Voltage/power switch
   * Outputs: A = Converted amplitude, ADC counts
   */
  double value = *(double *)pgsub->a;
  double scale = *(double *)pgsub->b;
  double type  = *(double *)pgsub->c;
  double *out = (double *)pgsub->vala;
  
  if (scale == 0.0)
  {
    *out = ADC_FS;
    return 0;
  }
  
  *out = value / scale;
  if (type)
  {
    if (*out >= 0.0)
      *out = sqrt(*out);
    else
      *out = 0.0;
  }
  
  return 0;
}

static long subMiscStringCp(aSubRecord *pgsub)
{
  /*
   * Input:   A = Input string
   * Outputs: A = Output copy 1
   *          B = Output copy 2
   *          C = Output copy 3
   *          D = Output copy 4
   *          E = Output copy 5
   *          F = Output copy 6
   */
  
  strncpy(pgsub->vala, pgsub->a, 39);
  
  if (pgsub->ftvb == DBR_STRING) /* Check if we need the second output */
    strncpy(pgsub->valb, pgsub->a, 39);
  if (pgsub->ftvc == DBR_STRING) /* Check if we need the third output */
    strncpy(pgsub->valc, pgsub->a, 39);
  if (pgsub->ftvd == DBR_STRING) /* Check if we need the fourth output */
    strncpy(pgsub->vald, pgsub->a, 39);
  if (pgsub->ftve == DBR_STRING) /* Check if we need the fifth output */
    strncpy(pgsub->vale, pgsub->a, 39);
  if (pgsub->ftvf == DBR_STRING) /* Check if we need the sixth output */
    strncpy(pgsub->valf, pgsub->a, 39);
  
  return 0;
}

static long subMiscLongCp(aSubRecord *pasub)
{
  /*
   * Input:   A = Input long
   * Outputs: A = Output copy 1
   *          B = Output copy 2
   *          C = Output copy 3
   *          D = Output copy 4
   *          E = Output copy 5
   *          F = Output copy 6
   */
  int32_t *in = (int32_t *)pasub->a;
  
  *(int32_t *)pasub->vala = *in;
  
  if (pasub->ftvb == DBR_LONG) /* Check if we need the second output */
    *(int32_t *)pasub->valb = *in;
  if (pasub->ftvc == DBR_LONG) /* Check if we need the third output */
    *(int32_t *)pasub->valc = *in;
  if (pasub->ftvd == DBR_LONG) /* Check if we need the fourth output */
    *(int32_t *)pasub->vald = *in;
  if (pasub->ftve == DBR_LONG) /* Check if we need the fifth output */
    *(int32_t *)pasub->vale = *in;
  if (pasub->ftvf == DBR_LONG) /* Check if we need the sixth output */
    *(int32_t *)pasub->valf = *in;
  
  return 0;
}

#define UnitySat(x)	((x>1.0)?1.0:(x<-1.0)?-1.0:x)

static long subMiscServo(aSubRecord *pgsub)
{
  /*
   * Inputs: A - Mode (0 - off, 1 - on)
             B - Measurement
             C - Setpoint
             D - Proportional gain
             E - Integral gain
             F - Derivative gain
             G - Output amplitude
             H - Output zero point
             I - Anti-windup gain
             J - Measurement averaging factor
     Outputs:
             A - Integrator ([-1..1])
             B - DAC drive
             C - Normalized output ([-1..1])
             D - Full (unsaturated) output
             E - Last error value
             F - Averaged measurement
  */
  char mode;
  double setpoint, gain_i, gain_p, gain_d, gain_w, avgc;
  double diff, meas, swing, zero, err;

  double integrator  = *(double *)pgsub->ovla;
  double output      = *(double *)pgsub->ovld;
  double output_sat  = *(double *)pgsub->ovlc;
  double last_err    = *(double *)pgsub->ovle;
  double meas_avg    = *(double *)pgsub->ovlf;
  
  static char first = 1;
  
  mode     = *(char *)  pgsub->a;
  meas     = *(double *)pgsub->b;
  setpoint = *(double *)pgsub->c;
  gain_p   = *(double *)pgsub->d;
  gain_i   = *(double *)pgsub->e;
  gain_d   = *(double *)pgsub->f;
  swing    = *(double *)pgsub->g;
  zero     = *(double *)pgsub->h;
  gain_w   = *(double *)pgsub->i;
  avgc     = *(double *)pgsub->j;

  // Zero degrees C is invalid
  if (meas == 0.0)
    meas = setpoint;
  
  if (first)
  {
    /* Reset handling */
    integrator = output = output_sat = 0.0;
    meas_avg = meas;
  }

  meas_avg = meas_avg*avgc + meas*(1-avgc);

  if (mode == 1)
  {
    err = setpoint - meas_avg;
    if (first)
      last_err = err;
    
    if (gain_i == 0.0)
      integrator = 0.0;
    else
      integrator += gain_i * err +  gain_w * (output_sat - output);
    integrator = UnitySat(integrator);
    
    diff = gain_d *(err - last_err);
    
    output = integrator + diff + gain_p*err;
  }
  first = 0;

  output_sat = UnitySat(output);

  *(double *)pgsub->vala = integrator;
  *(int *)pgsub->valb = (int)(swing*output_sat + zero + 0.5);
  *(double *)pgsub->valc = output_sat;
  *(double *)pgsub->vald = output;
  *(double *)pgsub->vale = err;
  *(double *)pgsub->valf = meas_avg;
  *(char *)pgsub->valg = mode;

#if 0
  printf("%s: meas=%f,avgc=%f,meas_avg=%f,set=%f,err=%f,int=%f,output=%f,out=%d\n",
         pgsub->name, meas, avgc, meas_avg,
         setpoint, err, integrator, output, *(int *)pgsub->valb);
#endif

  return 0;
}

static long subMiscRampGen(aSubRecord *pasub)
{
  /*
   * Input:   A = Start value
   *          B = End value
   * Outputs: A = Profile array
   *
   */
  int k, points = pasub->nova;
  double start = *(double *)pasub->a;
  double end   = *(double *)pasub->b;
  
  for (k = 0; k < points; k++)
    ((double *)pasub->vala)[k] = start + k*(end-start)/(points-1);
  
  return 0;
}

static long subMiscRampTime(aSubRecord *pasub)
{
  /*
   * Input:   A = Clocks per point
   *          B = Sampling frequency
   * Outputs: A = Time vector
   *          B = Step length (us)
   *          C = Step length (string in us)
   *          D = Ramp length (ms)
   *          E = Ramp length (string in milliseconds)
   *
   */
  int k, points = pasub->nova;
  int32_t counts = *(int32_t *)pasub->a;
  double fsamp = *(double *)pasub->b;
  double Tstep;
  double *Ttot  = (double *)pasub->vald;
  
  Tstep = counts/fsamp/1.0e6;
  *(double *)pasub->valb = Tstep * 1.0e6;
  printTime(pasub->valc, Tstep, PRINT_USEC);
  
  Tstep *= 1.0e3; /* ms */
  
  for (k = 0; k < points; k++)
    ((double *)pasub->vala)[k] = Tstep * k;
  
  *Ttot = points * Tstep;
  printTime(pasub->vale, *Ttot*1.0e-3, PRINT_MSEC);
  
  return 0;
}

static long subMiscInterlockState(aSubRecord *pasub)
{
  /*
   * Input:   A = Interlock poll bit
              B = Ramp counts value
              C = Ramp maginitude waveform
              D = Magnitude ramp loading step
   * Outputs: A = Feedback loop control
   *          B = Ramp magnitude waveform
   *          C = Ramp load control
   *          D = Ramp trigger source control
   *          E = Ramp down trigger
   *          F = Ramp counts value drive
   *          G = Magnitude ramp loading step
   *
   */
  int32_t *ilock = (int32_t *)pasub->a, k, rc = 1;

  static int ilock_cnt = 0, ramp_counts;
  static double *ramp = NULL, mag_step;
  
  if (ramp == NULL)
    ramp = (double *)malloc(pasub->noc*sizeof(double));
  
  if (*ilock && ilock_cnt == 0) /* First event detection */
  {
    *(int32_t *)pasub->vala = 0; /* Open the loop */
    *(int32_t *)pasub->vald = 0; /* Internal trigger */
    
    /* Reset the magnitude */
    for (k = 0; k < pasub->novb; k++)
    {
      ramp[k] = ((double *)pasub->c)[k];
      ((double *)pasub->valb)[k] = 0.0;
    }
    
    ramp_counts = *(int32_t *)pasub->b; /* Save the value */
    mag_step    = *(double *)pasub->d; /* Save the value */
    *(int32_t *)pasub->valf   = 2; /* Super short ramp */
    *(double *)pasub->valg = 10000.0; /* 10 MV/step */

    *(int32_t *)pasub->valc = 0; /* No ramp loading yet */
    *(int32_t *)pasub->vale = 0; /* No trigger down yet */
    
    rc = 0;
  }
  
  if (*ilock && ilock_cnt == 1) /* Second pass */
  {
    *(int32_t *)pasub->vale = 1; /* Trigger down */
    rc = 0;
  }
  
  if (*ilock && ilock_cnt == 2) /* Third pass */
  {
    *(int32_t *)pasub->vale = 0; /* Release the trigger down */
    *(int32_t *)pasub->valf = ramp_counts; /* Restore the ramp length */
    *(int32_t *)pasub->valc = 1; /* Load the ramp */
    rc = 0;
  }
  
  if (*ilock && ilock_cnt == 3) /* Fourth pass */
  {
    *(double *)pasub->valg = mag_step; /* Restore the step size */
    *(int32_t *)pasub->valc   = 0; /* Reset loading control */
    for (k = 0; k < pasub->novb; k++)
      ((double *)pasub->valb)[k] = ramp[k];
    rc = 0;
  }
  
  
  if (*ilock)
    ilock_cnt = (ilock_cnt == 4) ? 4 : ilock_cnt + 1;
  else
    ilock_cnt = 0;

  return rc;
}

static long subMiscRampAdd(aSubRecord *pasub)
{
  /*
   * Input:   A = Profile
   *          B = Base
   * Outputs: A = Full vector
   *
   */
  int k, points = pasub->nova;
  double base = *(double *)pasub->b;
  
  for (k = 0; k < points; k++)
    ((double *)pasub->vala)[k] = phase_clip(((double *)pasub->a)[k]+base);
  
  return 0;
}

static long subMiscWaveSel(aSubRecord *pasub)
{
  /*
   * Input:   A = Waveform
   *          B = Index
   * Outputs: A = Selected value
   *
   */
  int32_t idx = *(int32_t *)pasub->b, points = pasub->noa;

  /* Clip the index */  
  if (idx < 0) idx = 0;
  if (idx >= points) idx = points -1;
  
  *(double *)pasub->vala = ((double *)pasub->a)[idx];
  
  return 0;
}

#if 0
#define MCP3208_FS 4096

static long subMiscNTCConvert(aSubRecord *pasub)
{
  /*
   * Input:   A = ADC readback channel (long)
   *          B = DAC drive channel (long)
   *          C = R_NTC @ 25 degC (ohms)
   *          D = R_bias (ohms)
   *          F = A1
   *          G = B1
   *          H = C1
   *          I = D1
   *
   * Outputs: A = Temperature, degC (double)
   *
   */

  /* Expected topology: NTC to ground, R_bias to 3.3 V */


  int32_t adc   = *(int32_t *)pasub->a;
  double R_NTC0 = *(double *)pasub->c;
  double R_bias = *(double *)pasub->d;
  double A1     = *(double *)pasub->f;
  double B1     = *(double *)pasub->g;
  double C1     = *(double *)pasub->h;
  double D1     = *(double *)pasub->i;
  double R_NTC, lnRT;
  
  /* Calculate the NTC resistance */
  R_NTC = R_bias*adc/(MCP3208_FS-adc);
  
  lnRT = log(R_NTC/R_NTC0);
  
  *(double *)pasub->vala = 1/(A1+B1*lnRT+C1*lnRT*lnRT+D1*lnRT*lnRT*lnRT) - 273.15;
  
  return 0;
}
#else
#define MCP3208_FS 4096
#define MCP3208_MINV 30
#define AD5644_OFFSET 8192
#define AD5644_FS  16384

static long subMiscNTCConvert(aSubRecord *pasub)
{
  /*
   * Input:   A = ADC readback channel (long)
   *          B = DAC drive channel (long)
   *          C = R_NTC @ 25 degC (ohms)
   *          D = R_bias (ohms)
   *          E = topology: 0 - NTC to ground, 1 - NTC between DAC & ADC
   *          F = A1
   *          G = B1
   *          H = C1
   *          I = D1
   *
   * Outputs: A = Temperature, degC (double)
   *
   */
  int32_t adc   = *(int32_t *)pasub->a;
  int32_t dac   = *(int32_t *)pasub->b + AD5644_OFFSET;
  double R_NTC0 = *(double *)pasub->c;
  double R_bias = *(double *)pasub->d;
  int32_t topo  = *(int32_t *)pasub->e;
  double A1     = *(double *)pasub->f;
  double B1     = *(double *)pasub->g;
  double C1     = *(double *)pasub->h;
  double D1     = *(double *)pasub->i;
  double R_NTC, lnRT;
  
  /* Scale ADC to DAC range */
  if (adc < MCP3208_MINV || adc >= (MCP3208_FS-MCP3208_MINV)) /* Voltage too low to measure */
    R_NTC = R_NTC0;
  else
  {
    adc *= AD5644_FS/MCP3208_FS;
    if (topo)
      R_NTC = R_bias*(dac-adc)/adc;
    else
      R_NTC = R_bias*adc/(dac-adc);
  }
  
  lnRT = log(R_NTC/R_NTC0);
  
  *(double *)pasub->vala = 1/(A1+B1*lnRT+C1*lnRT*lnRT+D1*lnRT*lnRT*lnRT) - 273.15;
  
  return 0;
}
#endif

static long subMiscV2SADC(aSubRecord *pasub)
{
  /*
   * Input:   A = Voltage
   *          B = Configuration value
   * Outputs: A = ADC counts
   *
   */
  double V = *(double *)pasub->a;
  int32_t cfg = *(int32_t *)pasub->b;
  short int val, minv, maxv;
  
  double lsb = 5.0*(1<<((cfg+1)>>1))/4096.0;
  
  val = V/lsb;
  
  if (cfg & MAX1270_V_BIP)
  {
    minv = -2048;
    maxv = 2047;
  }
  else
  {
    minv = 0;
    maxv = 4095;
  }
  
  if (val > maxv) val = maxv;
  if (val < minv) val = minv;
  
  /* Proper masking */
  *(int16_t *)pasub->vala = val & MAX1270_V_VAL;
  return 0;
}

static long subMiscConfig(subRecord *psub)
{
  /*
   * Inputs:  A = Config register
   * Outputs: B = CIC decimation
   *          C = Gateware revision
   *
  */
  uint32_t cfg = (uint32_t)psub->a, decim;
  uchar rev, rev_maj, rev_min;
  char revision[6];
   
  decim = (cfg & CFG_M_DECIM) + 2;
  rev      = (cfg >> CFG_B_REV) & CFG_V_REV;
  rev_maj  = rev/16;
  rev_min  = rev % 16;
  sprintf(revision, "%2d.%02d", rev_maj, rev_min);
  
  dbPutLink(&psub->inpb, DBR_LONG, &decim, 1);
  dbPutLink(&psub->inpc, DBR_STRING, revision, strlen(revision));

  return 0;
}

static registryFunctionRef subMiscRef[] = {
  {"subMiscInit", (REGISTRYFUNCTION)subMiscInit},
  {"subIPaddr", (REGISTRYFUNCTION)subIPaddr},
  {"subMiscFanout", (REGISTRYFUNCTION)subMiscFanout},
  {"subMiscDS1822ROM", (REGISTRYFUNCTION)subMiscDS1822ROM},
  {"subMiscIQ2AmpPhase", (REGISTRYFUNCTION)subMiscIQ2AmpPhase},
  {"subMiscADC2Phys", (REGISTRYFUNCTION)subMiscADC2Phys},
  {"subMiscPhys2ADC", (REGISTRYFUNCTION)subMiscPhys2ADC},
  {"subMiscV2SADC", (REGISTRYFUNCTION)subMiscV2SADC},
  {"subMiscStringCp", (REGISTRYFUNCTION)subMiscStringCp},
  {"subMiscLongCp", (REGISTRYFUNCTION)subMiscLongCp},
  {"subMiscServo", (REGISTRYFUNCTION)subMiscServo},
  {"subMiscInterlockState", (REGISTRYFUNCTION)subMiscInterlockState},
  {"subMiscRampGen", (REGISTRYFUNCTION)subMiscRampGen},
  {"subMiscRampAdd", (REGISTRYFUNCTION)subMiscRampAdd},
  {"subMiscWaveSel", (REGISTRYFUNCTION)subMiscWaveSel},
  {"subMiscNTCConvert", (REGISTRYFUNCTION)subMiscNTCConvert},
  {"subMiscRampTime", (REGISTRYFUNCTION)subMiscRampTime},
  {"subMiscConfig", (REGISTRYFUNCTION)subMiscConfig}
};

static void subMiscRegistrar(void)
{
  registryFunctionRefAdd(subMiscRef, NELEMENTS(subMiscRef));
}
epicsExportRegistrar(subMiscRegistrar);
