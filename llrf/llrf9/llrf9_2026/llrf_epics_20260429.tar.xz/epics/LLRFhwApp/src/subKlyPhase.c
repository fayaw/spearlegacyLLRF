/*
 Klystron phase loop
 
 Copyright (c) 2012-2016 Dimtel, Inc., All Rights Reserved

 $Id: subKlyPhase.c,v 1.2 2019/08/24 16:57:17 dim Exp $
 $Date: 2019/08/24 16:57:17 $
 $Author: dim $
 $Revision: 1.2 $
 $Log: subKlyPhase.c,v $
 Revision 1.2  2019/08/24 16:57:17  dim
 Added forward channel phase offset and drive phase calculation

 Revision 1.1  2017/03/10 19:44:57  dim
 Initial import

*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <stdint.h>

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <dbAccess.h>

#include "cmath.h"

static long subKlyPhaseLoop(aSubRecord *pasub)
{
  /*
   * Input:   A = I/Q vector (I_Q_TS, 11 elements)
   *          B = Drive channel index
   *          C = Klystron forward channel index
   *          D = Loop control
   *          E = Drive to klystron phase setpoint
   *          F = Direct loop phase base
   *          G = Minimum klystron output (kW)
   *          H = Klystron forward amplitude
   *          I = Direct loop OL phase
   *          J = Direct loop CL phase
   *          K = Max step size (deg)
   *          L = Klystron forward phase offset
   *          M = Klystron forward hardware offset
   *          N = Reference channel index
   *           
   * Outputs: A = Direct loop OL phase
   *          B = Direct loop CL phase
   *          C = Loop control pipeline (to OL OMSL)
   *          D = Loop control pipeline (to CL OMSL)
   *          E = Fwd to drive delta
   *          F = Error relative to setpoint
   *          G = Drive phase (DDC 4 - DDC 3)
   *
   * Dead band of 1 degree is hard-coded
   *        
   */

  int slewing = 0;
  int32_t *pIQ = (int32_t *)pasub->a;
  int drive_idx = *(int32_t *)pasub->b;
  int kly_idx   = *(int32_t *)pasub->c;
  int ctrl      = *(int32_t *)pasub->d;
  double setpt  = *(double *)pasub->e;
  double base   = *(double *)pasub->f;
  double minfwd = *(double *)pasub->g;
  double pwrfwd = *(double *)pasub->h;
  double p_ol   = *(double *)pasub->i;
  double p_cl   = *(double *)pasub->j;
  double step   = *(double *)pasub->k;
  double ph_offset = *(double *)pasub->l;
  double hwph   = *(double *)pasub->m;
  int ref_idx   = *(int32_t *)pasub->n;
  
  /* Compute probe and forward phases, calculate tuning error */
  double drive_ph, klyfwd_ph, ref_ph, delta, direct;
  double ol_sign, cl_sign;
  double complex z;
  
  z = (double)pIQ[drive_idx] - (double)pIQ[drive_idx+1]*I;
  drive_ph = carg(z)/M_PI*180.0;
  z = (double)pIQ[kly_idx] - (double)pIQ[kly_idx+1]*I;
  klyfwd_ph = carg(z)/M_PI*180.0 + ph_offset + hwph;
  z = (double)pIQ[ref_idx] - (double)pIQ[ref_idx+1]*I;
  ref_ph = carg(z)/M_PI*180.0;
  
  *(double *)pasub->valg = phase_clip(drive_ph - ref_ph);

  delta = phase_clip(klyfwd_ph - drive_ph);
  *(double *)pasub->vale = delta;
  *(double *)pasub->valf = phase_clip(setpt - delta);
  
  direct = phase_clip(base + *(double *)pasub->valf);

  if (pwrfwd < minfwd)
  {
    ctrl  = 0;
  }
  
  if (ctrl == 0)
    direct = base;

  /* Process rate limiting */
  if (*(int32_t *)pasub->ovlc)
  {
    /* Already in closed loop, use ovl */
    p_ol = *(double *)pasub->ovla;
    p_cl = *(double *)pasub->ovlb;
  }

  /* Make sure we pick the shortest route */
  double dist = direct-p_ol;
  if (fabs(dist) > 180.0)
    ol_sign = -1.0;
  else
    ol_sign = 1.0;

  dist = direct-p_cl;
  if (fabs(dist) > 180.0)
    cl_sign = -1.0;
  else
    cl_sign = 1.0;
  
  /* OK to move fast below minimum power */
  if (pwrfwd >= minfwd && fabs(direct - p_ol) > step)
  {
    p_ol = phase_clip(p_ol + ol_sign*copysign(step, direct - p_ol));
    slewing = 1;
  }
  else
    p_ol = direct;

  if (pwrfwd >= minfwd && fabs(direct - p_cl) > step)
  {
    p_cl = phase_clip(p_cl + cl_sign*copysign(step, direct - p_cl));
    slewing = 1;
  }
  else
    p_cl = direct;
  
  if (ctrl && !slewing && fabs(p_ol - *(double *)pasub->ovla) < 1.0)
    p_ol = *(double *)pasub->ovla;
  if (ctrl && !slewing && fabs(p_cl - *(double *)pasub->ovlb) < 1.0)
    p_cl = *(double *)pasub->ovlb;
    
  /* Write the output */
  *(double *)pasub->vala = p_ol;
  *(double *)pasub->valb = p_cl;
  
  /* Make sure to reset loop phases before clearing OMSL */
  if ((*(double *)pasub->ovla != base) && (ctrl == 0) &&
      (*(int32_t *)pasub->valc == 1))
  {
    *(int32_t *)pasub->valc = 1;
    *(int32_t *)pasub->vald = 1;
  }
  else
  {
    *(int32_t *)pasub->valc = ctrl;
    *(int32_t *)pasub->vald = ctrl;
  }

  return 0;
}
static registryFunctionRef subKlyPhaseRef[] = {
  {"subKlyPhaseLoop", (REGISTRYFUNCTION)subKlyPhaseLoop}
};

static void subKlyPhaseRegistrar(void)
{
  registryFunctionRefAdd(subKlyPhaseRef, NELEMENTS(subKlyPhaseRef));
}
epicsExportRegistrar(subKlyPhaseRegistrar);
