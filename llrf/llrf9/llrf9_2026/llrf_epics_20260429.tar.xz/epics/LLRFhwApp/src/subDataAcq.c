/*
 Subroutines for data acquisition and processing
 
 Copyright (c) 2008-2016 Dimtel, Inc., All Rights Reserved

 $Id: subDataAcq.c,v 1.4 2025/11/07 17:24:26 dim Exp $
 $Date: 2025/11/07 17:24:26 $
 $Author: dim $
 $Revision: 1.4 $
 $Log: subDataAcq.c,v $
 Revision 1.4  2025/11/07 17:24:26  dim
 DDC acquisition support, LMK01801

 Revision 1.3  2025/09/27 23:34:34  dim
 Added DDC waveform acquisition mode, setpoint ramping moved from integer to double domain

 Revision 1.2  2023/09/08 19:19:08  dim
 Series 2 and 3 merge

 Revision 1.1  2017/03/10 19:44:56  dim
 Initial import

*/

/* To get NAN defined */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <epicsExport.h>
#include <dbAccess.h>
#include <aSubRecord.h>
#include <recSup.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
#include <sys/time.h>

/* FFT code definitions */
#include <complex.h>
#include <fftw3.h>

/* Local stuff */
#include "LLRFhw.h"
#include "cmath.h"
#include "spf.h"
#include "dacq.h"

extern acq_data snapshot;
extern pthread_mutex_t snapshot_mutex;

extern int USB_Debug;

proc_data vectors;

typedef long (*processMethod)(subRecord *precord);

static long subDataAcqInit(subRecord *psub, processMethod process)
{
  psub->val = 0;
  return 0;
}

void *FFTProcThread(void *ptr)
{
  char mask = 0;
  int k, m, diff, length;
  uint32_t adc_length;
  double *tmp = NULL;

  /* FFTW structures */
  fftw_complex *fftout;
  fftw_plan p;
  
  /* Timing structures */
  struct timeval t1, t2;

  adc_length = ((aSubRecord *)vectors.pasub)->nova;
  while (1)
  {
    /* Lock the data structure before processing */
    pthread_mutex_lock(&vectors.data_mutex);
    
    if (vectors.trigger != TRIG_NEW) /* No new data */
    {
      pthread_mutex_unlock(&vectors.data_mutex);
      usleep(T_PROC_WAIT); /* Sleep */
    }
    else
    {
      if (USB_Debug == 1)
        gettimeofday(&t1, NULL);

      if (vectors.first | (length != vectors.length))
      {
        length = vectors.length;
        if (vectors.first == 0)
        {
          fftw_destroy_plan(p);
          fftw_free(fftout);
        }
        else
          tmp = (double *)memalign(DACQ_SIMD_ALIGN, adc_length*sizeof(double));
        
        fftout  = fftw_malloc(sizeof(fftw_complex)*(length/2 + 1));
        /* FFT computation - use tmp as input data vector */
        p = fftw_plan_dft_r2c_1d(length, tmp, fftout, FFTW_WISDOM_ONLY);
        if (p == NULL)
	{
	  printf("No wisdom found for length %d\n", length);
          p = fftw_plan_dft_r2c_1d(length, tmp, fftout, FFTW_ESTIMATE);
	}
	if (USB_Debug == 4)
	{
          fftw_print_plan(p); printf("\n");
        }
        
        vectors.first = 0;
      }

      for (k = 0; k < 4; k++)
      {
        if (vectors.mask & (1<<k))
        {
          /* Fill in the input data */
          for (m = 0; m < length; m++)
            tmp[m] = (double)vectors.adc[k][m];
          
          /* Transform it */    
          fftw_execute(p);
    
          /* Save squares of absolute values in mag */
          for (m = 0; m <= length/2; m++)
          {
            vectors.mag[k][m] = creal_loc(fftout[m]*
                                conj_loc(fftout[m]))/length;
            /* Convert to dB */
            vectors.mag[k][m] = 10.0*log10(vectors.mag[k][m]+1e-10);
          }

          for (; m <= adc_length/2; m++)
            vectors.mag[k][m] = vectors.mag[k][length/2];
          
          vectors.mag[k][0] = vectors.mag[k][1];
        }
        else
        {
          for (m = 0; m < adc_length; m++)
            vectors.adc[k][m] = 0;
          for (m = 0; m <= adc_length/2; m++)
            vectors.mag[k][m] = NAN;
        }
      }
  
      /* Do the averaging */
      if (!vectors.scale_update)
        for (k = 0; k < 4; k++)
        {
          if (vectors.mask & (1<<k) && mask & (1<<k))
            for (m = 0; m <= adc_length/2; m++)
                vectors.mag[k][m] = vectors.alpha*vectors.mag_old[k][m] +
                                  (1.0 - vectors.alpha)*vectors.mag[k][m];
        }
      
      for (k = 0; k < 4; k++)
        if (vectors.mask & (1<<k))
          for (m = 0; m <= adc_length/2; m++)
            vectors.mag_old[k][m] = vectors.mag[k][m];
      
      if (vectors.scale_update)
      {
        for (m = 0; m <= length/2; m++)
          vectors.freq[m] = (float)m/vectors.us_per_sample/length;
        for (; m <= adc_length/2; m++)
          vectors.freq[m] = vectors.freq[length/2];
          
        for (m = 0; m < adc_length; m++)
          vectors.tsc[m] = (float)(m * vectors.us_per_sample);

        dbPutLink(vectors.db_tsc, DBR_FLOAT, vectors.tsc, adc_length);
        dbPutLink(vectors.db_freq, DBR_FLOAT, vectors.freq, adc_length/2+1);
        vectors.scale_update = 0;
      }

      if (USB_Debug == 1)
      {
        gettimeofday(&t2, NULL);
        diff = deltaT(&t1, &t2);
        printf("Elapsed time (FFTProcThread): %.3f ms\n", ((double)diff)/1000.0);
      }

      for (k = 0; k < 4; k++)
      {
        /* Update disabled channel only once, to load 0/NAN */
        if (vectors.mask & (1<<k) || mask & (1<<k))
        {
          dbPutLink(vectors.db_adc[k], DBR_SHORT,
                    &vectors.adc[k][0], adc_length);
          dbPutLink(vectors.db_mag[k], DBR_DOUBLE,
                    &vectors.mag[k][0], adc_length/2+1);
        }
      }

      mask = vectors.mask;
      vectors.trigger = 0;
      /* Unlock the data structure. subDataAcqbeamproc will get
         the mutex, copy out the results and reload the new data,
         if available  */
      pthread_mutex_unlock(&vectors.data_mutex);
      
      struct dbCommon *precord = (struct dbCommon *)vectors.pasub;
      struct rset *prset = (struct rset *)(precord->rset);
      dbScanLock(precord);
      (*prset->process)(precord);
      dbScanUnlock(precord);
    }
  }
  return NULL;
}

static long subDataAcqFFTProc(aSubRecord *pasub)
{
  /*
   * Inputs:  A = Sampling frequency
              B = Averaging factor
              C = Processing length
   * Outputs:
   *          A = ADC0 data
   *          B = ADC1 data
   *          C = ADC2 data
   *          D = ADC3 data
   *          E = time vector
   *          F = ADC0 spectrum
   *          G = ADC1 spectrum
   *          H = ADC2 spectrum
   *          I = ADC3 spectrum
   *          J = frequency vector
   *          K = Raw ADC data vector preceeded by acquisition ID
   *          
   */
  
  int m;
  static int first = 1;
  static double fsamp;
  static pthread_t proc_thread;
  static short acq_id = 0;
  short *raw = (short *)pasub->valk;

  if (USB_Debug == 2)
  {
        printf("Record %s called subDataAcqbeamproc(%p)\n",
               pasub->name, (void*) pasub);
  }

  if (first)
  {
    /* First-time init */
    pthread_mutex_init(&vectors.data_mutex, NULL);
    vectors.trigger = 0;
    fsamp = *(double *) pasub->a;
    vectors.us_per_sample = 1.0/fsamp;
    vectors.scale_update = 1;
    vectors.first = 1;
    first = 0;
    
    /* DB links */
    vectors.db_adc[0] = &pasub->outa;
    vectors.db_adc[1] = &pasub->outb;
    vectors.db_adc[2] = &pasub->outc;
    vectors.db_adc[3] = &pasub->outd;
    vectors.db_tsc    = &pasub->oute;
    vectors.db_mag[0] = &pasub->outf;
    vectors.db_mag[1] = &pasub->outg;
    vectors.db_mag[2] = &pasub->outh;
    vectors.db_mag[3] = &pasub->outi;
    vectors.db_freq   = &pasub->outj;
    vectors.pasub     = pasub;

    /* Create the processing thread */
    pthread_create(&proc_thread, NULL, FFTProcThread, NULL);
  }
  
  /* Try to get the lock */
  if (pthread_mutex_trylock(&vectors.data_mutex) == 0)
  {
    pasub->pact = 0;
    if (pthread_mutex_trylock(&snapshot_mutex) == 0)
    {
      if ((snapshot.trigger != 0) & (snapshot.ddc_acq == 0)) /* New data */
      {
        for (m=0; m < 4; m++)
          memcpy(vectors.adc[m], snapshot.adc[m], MAX_ADC_LENGTH*sizeof(short));
        vectors.alpha = 1.0 - 1.0 / *(double *)pasub->b;
        vectors.mask  = 0xf;
        if (vectors.length != *(int32_t *)pasub->c)
        {
          vectors.length = *(int32_t *)pasub->c;
          vectors.scale_update  = 1;
        }
        vectors.trigger = TRIG_NEW;
        pasub->pact = 1;
        if (fsamp != *(double *)pasub->a)
        {
          fsamp                 = *(double *)pasub->a;
          vectors.us_per_sample = 1.0/fsamp;
          vectors.scale_update  = 1;
        }
        
        /* Copy raw data to output K */
        *raw = acq_id++;
        for (m = 0; m < 4; m++)
          memcpy(raw+1+m*MAX_ADC_LENGTH, snapshot.adc[m], MAX_ADC_LENGTH*sizeof(short));
        
        snapshot.trigger = 0;
      }
      pthread_mutex_unlock(&snapshot_mutex);
    }    
    /* Unlock the mutex. If data is available processing will start
       within T_PROC_WAIT microseconds */
    pthread_mutex_unlock(&vectors.data_mutex);
  }
  
  return 1;
}

static long subDataAcqMask(aSubRecord *pasub)
{
  /*
   * Inputs:  A = data vector (short)
   *          B = data vector (float)
   *          C = Mode select, 0 - short, 1 - float
   *          D = enable
   * Outputs: A = data vector (short)
   *          B = data vector (float)
   *          C = enable (old)
   *          D = pass (0 on first pass, 1 otherwise)
   */
  int32_t *enable = (int32_t *)pasub->d;
  int32_t *enable_old = (int32_t *)pasub->valc;
  int32_t *pass = (int32_t *)pasub->vald;
  int k;
  
  if (*enable)
  {
    if (*(int32_t *)pasub->c == 0)
      dbPutLink(&pasub->outa, DBR_SHORT, pasub->a, pasub->noa*sizeof(int16_t));
    else
      dbPutLink(&pasub->outb, DBR_FLOAT, pasub->b, pasub->nob*sizeof(float));
  }
  else if (*enable_old | (*pass == 0))
  {
    /* Done on first pass for disabled channels or on transition */
    if (*(int32_t *)pasub->c == 0)
    {
      memset(pasub->vala, 0, pasub->noa*sizeof(int16_t));
      dbPutLink(&pasub->outa, DBR_SHORT, pasub->vala, pasub->noa*sizeof(int16_t));
    }
    else
    {
      for (k=0; k < pasub->nob; k++)
        ((float *)pasub->valb)[k] = NAN;
      dbPutLink(&pasub->outb, DBR_FLOAT, pasub->valb, pasub->nob*sizeof(float));
    }
  }
  
  /* Copy enable value */
  *enable_old = *enable;
  *pass = 1;
    
  return 1;
}

void *DDCProcThread(void *ptr)
{
  char mask = 0;
  int k, m, diff, length;
  uint32_t adc_length;
  double *tmp = NULL;

  /* FFTW structures */
  fftw_complex *fftout;
  fftw_plan p;
  
  /* Timing structures */
  struct timeval t1, t2;

  adc_length = ((aSubRecord *)vectors.pasub)->nova;
  while (1)
  {
    /* Lock the data structure before processing */
    pthread_mutex_lock(&vectors.data_mutex);
    
    if (vectors.trigger != TRIG_NEW) /* No new data */
    {
      pthread_mutex_unlock(&vectors.data_mutex);
      usleep(T_PROC_WAIT); /* Sleep */
    }
    else
    {
      if (USB_Debug == 1)
        gettimeofday(&t1, NULL);

      if (vectors.first | (length != vectors.length))
      {
        length = vectors.length;
        if (vectors.first == 0)
        {
          fftw_destroy_plan(p);
          fftw_free(fftout);
        }
        else
          tmp = (double *)memalign(DACQ_SIMD_ALIGN, adc_length*sizeof(double));
        
        fftout  = fftw_malloc(sizeof(fftw_complex)*(length/2 + 1));
        /* FFT computation - use tmp as input data vector */
        p = fftw_plan_dft_r2c_1d(length, tmp, fftout, FFTW_WISDOM_ONLY);
        if (p == NULL)
	{
	  printf("No wisdom found for length %d\n", length);
          p = fftw_plan_dft_r2c_1d(length, tmp, fftout, FFTW_ESTIMATE);
	}
	if (USB_Debug == 4)
	{
          fftw_print_plan(p); printf("\n");
        }
        
        vectors.first = 0;
      }

      for (k = 0; k < 4; k++)
      {
        if (vectors.mask & (1<<k))
        {
          /* Fill in the input data */
          for (m = 0; m < length; m++)
            tmp[m] = (double)vectors.adc[k][m];
          
          /* Transform it */    
          fftw_execute(p);
    
          /* Save squares of absolute values in mag */
          for (m = 0; m <= length/2; m++)
          {
            vectors.mag[k][m] = creal_loc(fftout[m]*
                                conj_loc(fftout[m]))/length;
            /* Convert to dB */
            vectors.mag[k][m] = 10.0*log10(vectors.mag[k][m]+1e-10);
          }

          for (; m <= adc_length/2; m++)
            vectors.mag[k][m] = vectors.mag[k][length/2];
          
          vectors.mag[k][0] = vectors.mag[k][1];
        }
        else
        {
          for (m = 0; m < adc_length; m++)
            vectors.adc[k][m] = 0;
          for (m = 0; m <= adc_length/2; m++)
            vectors.mag[k][m] = NAN;
        }
      }
  
      /* Do the averaging */
      if (!vectors.scale_update)
        for (k = 0; k < 4; k++)
        {
          if (vectors.mask & (1<<k) && mask & (1<<k))
            for (m = 0; m <= adc_length/2; m++)
                vectors.mag[k][m] = vectors.alpha*vectors.mag_old[k][m] +
                                  (1.0 - vectors.alpha)*vectors.mag[k][m];
        }
      
      for (k = 0; k < 4; k++)
        if (vectors.mask & (1<<k))
          for (m = 0; m <= adc_length/2; m++)
            vectors.mag_old[k][m] = vectors.mag[k][m];
      
      if (vectors.scale_update)
      {
        for (m = 0; m <= length/2; m++)
          vectors.freq[m] = (float)m/vectors.us_per_sample/length;
        for (; m <= adc_length/2; m++)
          vectors.freq[m] = vectors.freq[length/2];
          
        for (m = 0; m < adc_length; m++)
          vectors.tsc[m] = (float)(m * vectors.us_per_sample);

        dbPutLink(vectors.db_tsc, DBR_FLOAT, vectors.tsc, adc_length);
        dbPutLink(vectors.db_freq, DBR_FLOAT, vectors.freq, adc_length/2+1);
        vectors.scale_update = 0;
      }

      if (USB_Debug == 1)
      {
        gettimeofday(&t2, NULL);
        diff = deltaT(&t1, &t2);
        printf("Elapsed time (FFTProcThread): %.3f ms\n", ((double)diff)/1000.0);
      }

      for (k = 0; k < 4; k++)
      {
        /* Update disabled channel only once, to load 0/NAN */
        if (vectors.mask & (1<<k) || mask & (1<<k))
        {
          dbPutLink(vectors.db_adc[k], DBR_SHORT,
                    &vectors.adc[k][0], adc_length);
          dbPutLink(vectors.db_mag[k], DBR_DOUBLE,
                    &vectors.mag[k][0], adc_length/2+1);
        }
      }

      mask = vectors.mask;
      vectors.trigger = 0;
      /* Unlock the data structure. subDataAcqbeamproc will get
         the mutex, copy out the results and reload the new data,
         if available  */
      pthread_mutex_unlock(&vectors.data_mutex);
      
      struct dbCommon *precord = (struct dbCommon *)vectors.pasub;
      struct rset *prset = (struct rset *)(precord->rset);
      dbScanLock(precord);
      (*prset->process)(precord);
      dbScanUnlock(precord);
    }
  }
  return NULL;
}

static long subDataAcqDDCProc(aSubRecord *pasub)
{
  /*
   * Inputs:  A = Sampling frequency (MHz)
              B = IF frequency (kHz)
              C = Phase display threshold (counts)

              Next inputs are to be moved to difference processing aSub
	      D = Channel 0 scale
              E = Channel 0 phase offset
              F = Channel 0 hardware phase offset
              G = Channel 0 power switch
              H = Channel 1 scale
              I = Channel 1 phase offset
              J = Channel 1 hardware phase offset
              K = Channel 1 power switch
              L = Channel 2 scale
              M = Channel 2 phase offset
              N = Channel 2 hardware phase offset
              O = Channel 2 power switch
   * Outputs:
   *          A = CH0 amplitude
   *          B = CH1 amplitude
   *          C = CH2 amplitude
   *          D = CH3 amplitude
   *          E = CH0 phase relative to CH3
   *          F = CH1 phase relative to CH3
   *          G = CH2 phase relative to CH3
   *          H = CH3 phase 
   *          I = time vector
   *          J = Raw I/Q data vector preceeded by acquisition ID
   *          
   */
  
  int m, n, outlen, ph_valid, rc = 1;
  static double theta, gain_scale_inv, fsamp1 = -1.0, f_if1 = 0.0;
  double *fsamp = (double *)pasub->a;
  double *f_if  = (double *)pasub->b;
  double *ph_min = (double *)pasub->c;
  double Ts, sum;
  static float acq_id = 0;
  float *raw = (float *)pasub->valj;
  complex iq[4][MAX_ADC_LENGTH];

  outlen = pasub->nova;
  if (USB_Debug == 2)
  {
        printf("Record %s called subDataAcqDDCProc(%p)\n",
               pasub->name, (void*) pasub);
  }

  if ((fsamp1 != *fsamp) || (f_if1 != *f_if))
  {
    /* Update static matrix elements */
    fsamp1 = *fsamp; f_if1 = *f_if;
    
    theta          = M_PI * f_if1 / fsamp1 / 500.0;
    gain_scale_inv = 1.0/sin(theta);
  }

  if ((snapshot.trigger == 1) & (snapshot.ddc_acq == 1)) /* New data */
  {
    *raw = acq_id++;
    for (m = 0; m < 4; m++)
      for (n = 0; n < MAX_ADC_LENGTH; n++)
      {
        /* Copy raw data to output K */
        raw[1 + m*MAX_ADC_LENGTH + n] = (float)snapshot.ddc[m][n];
        
        if (n % 2) // I value, Q precedes it
        {
          int out = n >> 1;
          iq[m][out] = snapshot.ddc[m][n] - I * snapshot.ddc[m][n-1];
          iq[m][out] *= gain_scale_inv / 2.0 / snapshot.ddc_cnt;
          iq[m][out] *= (1<<snapshot.ddc_sft);
        }
      }
    for (m = 0; m < 4; m++) /* Extract signal channels */
    {
      void **p_amp = &(pasub->vala);
      void **p_phs = &(pasub->vale);
      for (n = 0, ph_valid=0, sum = 0.0; n < outlen; n++)
      {
        float ph;
        if (m == 3) /* Reference channel */
          ph = carg(iq[m][n]) / M_PI * 180.0;
        else
          ph = phase_clip((carg(iq[m][n]) - carg(iq[3][n])) / M_PI * 180.0);
          
        *((float *)p_amp[m]+n) = cabs(iq[m][n]);
        *((float *)p_phs[m]+n) = ph;
        if (*((float *)p_amp[m]+n) > *ph_min)
        {
          ph_valid++;
          sum += ph;
        }
      }
      if (ph_valid)
        sum /= ph_valid; /* mean phase */
      for (n = 0; n < outlen; n++)
        if (*((float *)p_amp[m]+n) <= *ph_min) /* Below threshold, set to mean */
          *((float *)p_phs[m]+n) = sum;
    }
    Ts = snapshot.ddc_cnt * 2 / fsamp1;
    for (n = 0; n < outlen; n++)
      *((float *)pasub->vali + n) = n * Ts;
       
    snapshot.trigger = rc = 0;
  }
  
  return rc;
}


static registryFunctionRef subDataAcqRef[] = {
  {"subDataAcqInit", (REGISTRYFUNCTION)subDataAcqInit},
  {"subDataAcqFFTProc", (REGISTRYFUNCTION)subDataAcqFFTProc},
  {"subDataAcqDDCProc", (REGISTRYFUNCTION)subDataAcqDDCProc},
  {"subDataAcqMask", (REGISTRYFUNCTION)subDataAcqMask}
};


static void subDataAcqRegistrar(void)
{
  registryFunctionRefAdd(subDataAcqRef, NELEMENTS(subDataAcqRef));
}
epicsExportRegistrar(subDataAcqRegistrar);
