/*
 Data acquisition structures and constants
 
 Copyright (c) 2008-2015 Dimtel, Inc., All Rights Reserved

 $Id: dacq.h,v 1.6 2025/09/27 23:34:34 dim Exp $
 $Date: 2025/09/27 23:34:34 $
 $Author: dim $
 $Revision: 1.6 $
 $Log: dacq.h,v $
 Revision 1.6  2025/09/27 23:34:34  dim
 Added DDC waveform acquisition mode, setpoint ramping moved from integer to double domain

 Revision 1.5  2023/09/08 19:19:08  dim
 Series 2 and 3 merge

 Revision 1.4  2022/11/13 23:35:23  dim
 Baseband ADC acqusition support

 Revision 1.3  2022/08/31 18:35:35  dim
 Series 3 changes

 Revision 1.2  2021/11/04 06:27:57  dim
 A shorter maximum wait can be used since sweep time is now
 calculated and accounted for

 Revision 1.1  2017/03/10 19:44:56  dim
 Initial import

*/

#ifndef _DACQ_H_
#define _DACQ_H_

#include <pthread.h>

/* Maximum length across all platforms */
#define MAX_ADC_LENGTH	 63488

#define LPF_LENGTH 	 10
#define GET_DEMUX(a) 	 (4 + 2*a)

#define DACQ_FFTW_THREADS 2
#define DACQ_SIMD_ALIGN  16

/* At most spend this many microseconds in wait state (int. trigger) */
#define T_ACQ_WAIT_MAX	120000
/* Wait for this many uS*/
#define T_ACQ_WAIT	20000

typedef struct int18_t
{
  int x:18;
} int18_t;

typedef struct acq_data
{
  short adc[4][MAX_ADC_LENGTH];
  int32_t ddc[4][MAX_ADC_LENGTH];
  char trigger;
  int postlen;
  char ddc_acq;
  int ddc_cnt;
  int ddc_sft;
} acq_data;

#define TRIG_NEW	0x1
#define TRIG_PROC	0x2
#define T_PROC_WAIT	100000

#define T_RTNA_WAIT_MAX 10000000 /* 10 s */
#define T_RTNA_WAIT	20000 /* 20 ms */

typedef struct proc_data
{
  char   trigger, first, scale_update, mask;
  int    length;
  double us_per_sample;
  double alpha;
  short adc[4][MAX_ADC_LENGTH];
  float tsc[MAX_ADC_LENGTH];
  double mag[4][MAX_ADC_LENGTH/2+1], mag_old[4][MAX_ADC_LENGTH/2+1];
  float  freq[MAX_ADC_LENGTH/2+1];
  
  struct link *db_adc[4];
  struct link *db_mag[4];
  struct link *db_tsc, *db_freq;
  
  void *pasub;
  
  pthread_mutex_t data_mutex;
} proc_data;

typedef struct async_comm
{
  void            *pasub;
  int             rc; /* Return value after processing */
  pthread_mutex_t mutex;
  pthread_cond_t  cond;
  
  int             trigger;
} async_comm;

enum async_trigger_state {
  ASYNC_IDLE,
  ASYNC_TRIGGER,
  ASYNC_DONE
};

/* At most spend this many microseconds in wait state (int. trigger) */
#define T_BBACQ_WAIT_MAX	150000
#define BB_ADC_LENGTH		12288
/* Sampling and readout take 18 clock cycles at 2 MHz (in ms) */
#define BBACQ_TS		(500e-6*18)

#endif /* _DACQ_H_ */
