/*
 Common functions
 
 Copyright (c) 2012 Dimtel, Inc., All Rights Reserved

 $Id: common.c,v 1.1 2017/03/10 19:44:56 dim Exp $
 $Date: 2017/03/10 19:44:56 $
 $Author: dim $
 $Revision: 1.1 $
 $Log: common.c,v $
 Revision 1.1  2017/03/10 19:44:56  dim
 Initial import

*/

#include <stdio.h>

/* Local stuff */
#include "LLRFhw.h"
#include "common.h"
#include "map.h"

/* Compute rational approximation of the ratio value.
   Approximation stops when at the next step denominator N exceeds Nmax
*/
void cfrac(double ratio, int Nmax, unsigned int *M, unsigned int *N)
{
  /* Past, current, and next values */
  int i;
  unsigned long long int M2, M1, Mn, N2, N1, Nn, a1, a2;
  double x1, x2, y1, y2;
  
  M2 = 0; N2 = 1;
  M1 = 1; N1 = 0;
  
  a1 = (unsigned int) ratio;
  x1 = 1.0;
  y1 = ratio - a1; /* fractional part */
  
  for (i = 0; i < 20; i++)
  {
    /* Next state computation */
    a2 = (unsigned int) (x1/y1);
    x2 = y1;
    y2 = x1 - a2*y1;
    Mn = a1*M1 + M2;
    Nn = a1*N1 + N2;
    if (Nn > Nmax)
      break;
    
    /* State update */
    a1 = a2; x1 = x2; y1 = y2;
    M2 = M1; M1 = Mn; N2 = N1; N1 = Nn;
    if (a1 == 0)
      break;
  }

  if (N1 == 0) /* Input was an integer */
  {
    M1 = a1;
    N1 = 1;
  }
  *M = M1;
  *N = N1;
}

void DDSConfig(double freq, double fsamp, int Nmax, double *fr_act, unsigned int *M,
               unsigned int *N)
{
  double ratio;
  
  ratio = freq*(1<<17)/fsamp;
  cfrac(ratio, Nmax, M, N);
  *fr_act = ((double)*M/(double)*N)/(1<<17)*fsamp;
}

void printFrequency(char *output, double freq, char units)
{
  long long fr;
  long frac, mHz, Hz, kHz, MHz;

  if (units == PRINT_HZ)
  {
    /* Round to 0.1 Hz */
    fr= (long long)(freq*10.0 + 0.5);
    frac = fr % 10;
    Hz  = (fr/10) % 1000;
    kHz = (fr/10000) % 1000;
    MHz = fr/10000000;
  
    /* Create the string */
    if (MHz == 0)
    {
      if (kHz == 0)
        sprintf(output, "%3ld.%01ld Hz", Hz, frac);
      else
        sprintf(output, "%3ld,%03ld.%01ld Hz", kHz, Hz, frac);
    }
    else
        sprintf(output, "%3ld,%03ld,%03ld.%01ld Hz", MHz,
            kHz, Hz, frac);
  }
  else
  {
    fr = (long long)(freq*1000.0 + 0.5);
    mHz = fr % 1000;
    Hz  = (fr/1000) % 1000;
    kHz = (fr/1000000) % 1000;
    MHz = fr/1000000000;
    
    /* Create the string */
    if (MHz == 0)
    {
      if (kHz == 0)
      {
        if (Hz == 0)
          sprintf(output, "%3ld mHz", mHz);
        else
          sprintf(output, "%3ld,%03ld mHz", Hz, mHz);
      }
      else
        sprintf(output, "%3ld,%03ld,%03ld mHz", kHz, Hz, mHz);
    }
    else
        sprintf(output, "%3ld,%03ld,%03ld,%01ld mHz", MHz,
            kHz, Hz, mHz);
  }
}

void printTime(char *output, double time, char units)
{
  long long tm;
  long frac, s, ms, us, ks, Ms;

  if (units == PRINT_SEC)
  {
    /* Round to 0.1 s */
    tm= (long long)(time*10.0 + 0.5);
    frac = tm % 10;
    s = (tm/10) % 1000;
    ks = (tm/10000) % 1000;
    Ms = tm/10000000;
  
    /* Create the string */
    if (Ms == 0)
    {
      if (ks == 0)
        sprintf(output, "%3ld.%01ld s", s, frac);
      else
        sprintf(output, "%3ld,%03ld.%01ld s", ks, s, frac);
    }
    else
        sprintf(output, "%3ld,%03ld,%03ld.%01ld Hz", Ms,
            ks, s, frac);
  }
  else if (units == PRINT_MSEC)
  {
    tm = (long long)(time*1000.0 + 0.5);
    ms = tm % 1000;
    s  = (tm/1000) % 1000;
    
    /* Create the string */
    if (s == 0)
       sprintf(output, "%3ld ms", ms);
    else
       sprintf(output, "%3ld,%03ld ms", s, ms);
  }
  else if (units == PRINT_USEC)
  {
    tm = (long long)(time*1000000.0 + 0.5);
    
    us = tm % 1000;
    ms = (tm/1000) % 1000;
    s  = (tm/1000000) % 1000;
    
    /* Create the string */
    if (s == 0)
    {
      if (ms == 0)
        sprintf(output, "%3ld us", us);
      else
        sprintf(output, "%3ld,%03ld us", ms, us);
    }
    else
      sprintf(output, "%3ld,%3ld,%03ld us", s, ms, us);
  }
    
}
