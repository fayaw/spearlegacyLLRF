spf.o: ../spf.c
