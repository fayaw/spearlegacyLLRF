common.o: ../common.c ../LLRFhw.h ../common.h ../map.h
