subCounter.o: ../subCounter.c /opt/epics/base/include/dbDefs.h \
 /opt/epics/base/include/registryFunction.h \
 /opt/epics/base/include/shareLib.h /opt/epics/base/include/subRecord.h \
 /opt/epics/base/include/epicsTypes.h /opt/epics/base/include/link.h \
 /opt/epics/base/include/dbDefs.h /opt/epics/base/include/epicsMutex.h \
 /opt/epics/base/include/epicsAssert.h \
 /opt/epics/base/include/os/Linux/osdMutex.h \
 /opt/epics/base/include/ellLib.h /opt/epics/base/include/epicsTime.h \
 /opt/epics/base/include/os/Linux/osdTime.h \
 /opt/epics/base/include/epicsExport.h /opt/epics/base/include/shareLib.h
