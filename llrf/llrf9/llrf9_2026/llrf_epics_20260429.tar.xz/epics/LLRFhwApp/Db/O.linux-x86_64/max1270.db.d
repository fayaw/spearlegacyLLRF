# DO NOT EDIT: This file created by mkmf.pl,v 1.5 2002/03/25 21:33:24 jba Exp $ 



../O.Common/max1270.db : ../max1270.template
max1270.db.d: ../max1270.template
