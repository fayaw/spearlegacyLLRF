# DO NOT EDIT: This file created by mkmf.pl,v 1.5 2002/03/25 21:33:24 jba Exp $ 



../O.Common/ad5644_s2.db : ../regs.template
ad5644_s2.db.d: ../regs.template
