# DO NOT EDIT: This file created by mkmf.pl,v 1.5 2002/03/25 21:33:24 jba Exp $ 



../O.Common/rotators.db : ../rotators.template
rotators.db.d: ../rotators.template
