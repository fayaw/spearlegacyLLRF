# DO NOT EDIT: This file created by mkmf.pl,v 1.5 2002/03/25 21:33:24 jba Exp $ 



../O.Common/interlock_slow_adc.db : ../interlock_slow_adc.template
interlock_slow_adc.db.d: ../interlock_slow_adc.template
