# DO NOT EDIT: This file created by mkmf.pl,v 1.5 2002/03/25 21:33:24 jba Exp $ 



../O.Common/channel.db : ../channel.template
channel.db.d: ../channel.template
