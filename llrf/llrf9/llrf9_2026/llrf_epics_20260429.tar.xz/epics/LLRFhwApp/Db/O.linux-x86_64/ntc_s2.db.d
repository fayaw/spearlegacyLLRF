# DO NOT EDIT: This file created by mkmf.pl,v 1.5 2002/03/25 21:33:24 jba Exp $ 



../O.Common/ntc_s2.db : ../ntc.template
ntc_s2.db.d: ../ntc.template
