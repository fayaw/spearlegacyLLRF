# DO NOT EDIT: This file created by mkmf.pl,v 1.5 2002/03/25 21:33:24 jba Exp $ 



../O.Common/ntc_s3.db : ../ntc.template
ntc_s3.db.d: ../ntc.template
