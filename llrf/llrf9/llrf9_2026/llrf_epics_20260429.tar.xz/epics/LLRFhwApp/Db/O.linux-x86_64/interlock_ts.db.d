# DO NOT EDIT: This file created by mkmf.pl,v 1.5 2002/03/25 21:33:24 jba Exp $ 



../O.Common/interlock_ts.db : ../interlock_ts.template
interlock_ts.db.d: ../interlock_ts.template
