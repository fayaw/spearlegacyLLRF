/*
 Galil string out logic
 
 Copyright (c) 2016 Dimtel, Inc., All Rights Reserved

 $Id: subGalil.c,v 1.3 2025/11/07 17:51:28 dim Exp $
 $Date: 2025/11/07 17:51:28 $
 $Author: dim $
 $Revision: 1.3 $
 $Log: subGalil.c,v $
 Revision 1.3  2025/11/07 17:51:28  dim
 Support for controllers without AIN, bug fixes

 Revision 1.2  2019/08/22 09:11:44  dim
 Updated delays to be inline with the code operating at SESAME

 Revision 1.1  2017/03/10 19:44:57  dim
 Initial import

*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <stdint.h>
#include <stdlib.h>

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <dbAccess.h>

static long subGalilControl(aSubRecord *pasub)
{
  /*
   * Input:   A = Drive speed (native counts/s units for stepper, mV for DC)
   *          B = LLS
   *          C = HLS
   *          D = Enable
   *          E = Axis
   *          F = Motor type (0 - stepper, 1 - DC)
   *           
   * Outputs: A = Control string
   *          B = First pass flag
   *          C = Motor state (0 - off, 1 - on)
   *          D = Motor disable flag
   *          E = Direction
   */

  int speed  = *(int32_t *)pasub->a;
  int lls    = *(int32_t *)pasub->b;
  int hls    = *(int32_t *)pasub->c;
  int enable = *(int32_t *)pasub->d;
  char *axis = (char *)pasub->e;
  int type   = *(int32_t *)pasub->f;
  
  int32_t *first = (int32_t *)pasub->valb;
  int32_t *state = (int32_t *)pasub->valc;
  int32_t *flag  = (int32_t *)pasub->vald;
  int32_t *dir   = (int32_t *)pasub->vale;
  char *cmd = (char *)pasub->vala;

/*  printf("Entering GalilControl: speed=%d lls=%d hls=%d enable=%d axis=%s\n",
         speed, lls, hls, enable, axis); */
  if (*first == 0)
  {
    *first = 1; /* Reset the flag */
    *state = 0;
    /* Enable motor turn off record */
    if (type)
      sprintf(cmd, "OF%s=0;MO%s;", axis, axis);
    else
      sprintf(cmd, "ST%s;AM%s;MO%s", axis, axis, axis);
    *flag = 0;
  }
  else
  {
    if ((hls & (speed > 0)) || (lls & (speed < 0)) || (speed == 0) || !enable)
    {
      if (*state == 1)
        *state = 0;
      if (*flag == 1) /* Disable the motor */
      {
        if (type)
          sprintf(cmd, "OF%s=0;MO%s;", axis, axis);
        else
          sprintf(cmd, "ST%s;AM%s;MO%s", axis, axis, axis);
        *flag = 0;
      }
    }
    else
    {
      if (type)
      {
        if (speed > 9999) speed = 9999;
        if (speed < -9999) speed = -9999;

        double voltage = (double)speed/1000.0;
        sprintf(cmd, "SH%s;OF%s=%0.3f;", axis, axis, voltage);
      }
      else
        sprintf(cmd, "SH%s;JG%s=%d;BG%s", axis, axis, speed, axis);
      *state = 1;
      *flag  = 1;
      *dir = (speed >= 0);
    }
  }
//  printf("CMD: [%s]\n", cmd);
  return 0;
}

static long subGalilAnalog(aSubRecord *pasub)
{
  /*
   * Input:   A = Response string to analog read request
   *           
   * Outputs: A = SCAN output to AIN
   */

  int32_t *scan = (int32_t *)pasub->vala;
  char *resp = (char *)pasub->a;

  if (*resp == '?')
    *scan = 0; /* Passive */
  else
    *scan = 9; /* .1 second */

  return 0;
}

static registryFunctionRef subGalilRef[] = {
  {"subGalilControl", (REGISTRYFUNCTION)subGalilControl},
  {"subGalilAnalog", (REGISTRYFUNCTION)subGalilAnalog}
};

static void subGalilRegistrar(void)
{
  registryFunctionRefAdd(subGalilRef, NELEMENTS(subGalilRef));
}
epicsExportRegistrar(subGalilRegistrar);
