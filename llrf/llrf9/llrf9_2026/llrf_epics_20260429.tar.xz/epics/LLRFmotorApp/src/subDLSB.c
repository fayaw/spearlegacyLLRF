/*
 Diamond booster motor driver (EPICS stepper controls)
 
 Copyright (c) 2012-2016 Dimtel, Inc., All Rights Reserved

 $Id: subDLSB.c,v 1.1 2021/02/08 01:48:01 dim Exp $
 $Date: 2021/02/08 01:48:01 $
 $Author: dim $
 $Revision: 1.1 $

*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <dbAccess.h>

#define MAX_STEPS 600.0

static long subDLSBTunerCtrl(aSubRecord *pasub)
{
  /*
   * Input:   A = Incremental distance value
   *          C = In range bit
   *          D = Interlock bit
   *           
   * Outputs: A = Tuner motor enable
   *          B = Tuner motor direction
   *          C = Distance remaining
   */

  double delta_dist  = *(double *)pasub->a;
  int in_range    = *(int32_t *)pasub->c;
  int interlock   = *(int32_t *)pasub->d;
  int enable, dir;
  double dist;

  dist = *(double *)pasub->ovlc;
  dist += delta_dist;
  if (dist > MAX_STEPS)
    dist = MAX_STEPS;
  
  if (dist < -MAX_STEPS)
    dist = -MAX_STEPS;

  if (in_range & interlock) /* Both must be set to proceed */
  {
    if (fabs(dist) >=  1.0)
    {
      if (dist > 0.0)
      {
        dir = 0;
        dist -= 1.0;
      }
      else
      {
        dir = 1;
        dist += 1.0;
      }
      enable = 0;
    }
    else
      enable = 1;
  }
  else
    enable = 1; /* Motor disabled */
    
  *(int16_t *)pasub->vala = enable;
  *(int16_t *)pasub->valb = dir;
  *(double *)pasub->valc  = dist;

  return 0;
}

static registryFunctionRef subDLSBRef[] = {
  {"subDLSBTunerCtrl", (REGISTRYFUNCTION)subDLSBTunerCtrl}
};

static void subDLSBRegistrar(void)
{
  registryFunctionRefAdd(subDLSBRef, NELEMENTS(subDLSBRef));
}
epicsExportRegistrar(subDLSBRegistrar);
