dynamic_restore.o: ../dynamic_restore.c \
 /opt/epics/base/include/epicsPrint.h /opt/epics/base/include/errlog.h \
 /opt/epics/base/include/shareLib.h \
 /opt/epics/base/include/compilerDependencies.h \
 /opt/epics/base/include/dbAccess.h /opt/epics/base/include/dbDefs.h \
 /opt/epics/base/include/epicsTime.h /opt/epics/base/include/epicsTypes.h \
 /opt/epics/base/include/os/Linux/osdTime.h \
 /opt/epics/base/include/caeventmask.h \
 /opt/epics/base/include/dbFldTypes.h /opt/epics/base/include/link.h \
 /opt/epics/base/include/dbBase.h /opt/epics/base/include/ellLib.h \
 /opt/epics/base/include/dbAddr.h /opt/epics/base/include/dbLock.h \
 /opt/epics/base/include/dbAccessDefs.h /opt/epics/base/include/errMdef.h \
 /opt/epics/base/include/dbCa.h /opt/epics/base/include/dbCommon.h \
 /opt/epics/base/include/epicsMutex.h \
 /opt/epics/base/include/epicsAssert.h \
 /opt/epics/base/include/os/Linux/osdMutex.h \
 /opt/epics/base/include/db_field_log.h ../restore_utils.h \
 /opt/epics/base/include/epicsVersion.h \
 /opt/epics/base/include/initHooks.h \
 /opt/epics/base/include/epicsExport.h /opt/epics/base/include/shareLib.h \
 /opt/epics/base/include/cadef.h /opt/epics/base/include/epicsThread.h \
 /opt/epics/base/include/os/Linux/osdThread.h \
 /opt/epics/base/include/caerr.h /opt/epics/base/include/db_access.h
