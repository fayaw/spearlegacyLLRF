# 0 "../sncGalil.st"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "../sncGalil.st"
# 16 "../sncGalil.st"
program sncGalil

%%#include <stdlib.h>





int stat;
assign stat to "{sys}:{dev}:STAT";
monitor stat;


string message;
assign message to "{sys}:{ctrl}:MSG";

int disconnect;
assign disconnect to "{sys}:{ctrl}:ASYN.CNCT";

ss Galil_TCPIP_Control {
  state START
  {
    entry
    {
      sprintf(message, "Startup delay");
      pvPut(message);
    }
    when (delay(10)) {} state IDLE
  }
  state IDLE
  {
    entry
    {
      sprintf(message, "Controller connection OK");
      pvPut(message);
    }
    when (pvStatus(stat) != pvStatOK)
    {
      sprintf(message, "PV status %d, 5 seconds to resync", pvStatus(stat));
      pvPut(message);
    } state WAIT
  }
  state WAIT
  {
    when (delay(5))
    { } state CHECK
  }
  state CHECK
  {
    when (pvStatus(stat) == pvStatOK)
    {
      sprintf(message, "PV status pvStatOK, connection restored");
      pvPut(message);
    } state IDLE
    when (pvStatus(stat) != pvStatOK)
    {
      disconnect = 0; pvPut(disconnect);
      sprintf(message, "PV status %d, re-connecting", pvStatus(stat));
      pvPut(message);
    } state WAIT
  }
}
