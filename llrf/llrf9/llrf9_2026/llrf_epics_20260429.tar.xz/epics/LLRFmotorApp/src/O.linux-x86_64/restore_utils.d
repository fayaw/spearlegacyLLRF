restore_utils.o: ../restore_utils.c /opt/epics/base/include/epicsPrint.h \
 /opt/epics/base/include/errlog.h /opt/epics/base/include/shareLib.h \
 /opt/epics/base/include/compilerDependencies.h \
 /opt/epics/base/include/cadef.h /opt/epics/base/include/epicsThread.h \
 /opt/epics/base/include/os/Linux/osdThread.h \
 /opt/epics/base/include/shareLib.h /opt/epics/base/include/caerr.h \
 /opt/epics/base/include/epicsTypes.h /opt/epics/base/include/db_access.h \
 /opt/epics/base/include/epicsTime.h \
 /opt/epics/base/include/os/Linux/osdTime.h \
 /opt/epics/base/include/caeventmask.h ../restore_utils.h
