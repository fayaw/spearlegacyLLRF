/*
 SPEAR3 tuner stepper motor interface
 
 Copyright (c) 2021 Dimtel, Inc., All Rights Reserved

 $Id: subSPEAR3.c,v 1.2 2023/09/08 19:21:02 dim Exp $
 $Date: 2023/09/08 19:21:02 $
 $Author: dim $
 $Revision: 1.2 $
 $Log: subSPEAR3.c,v $
 Revision 1.2  2023/09/08 19:21:02  dim
 Added enable control

 Revision 1.1  2021/11/04 06:42:37  dim
 SPEAR3 support added


*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <dbAccess.h>

static long subSPEAR3TunerCtrl(aSubRecord *pasub)
{
  /*
   * Input:   A = Incremental distance value
   *          B = OMSL for channel A
   *          C = Position control
   *          D = Position readback
   *          E = Enable
   *           
   * Outputs: A = Position control output
   *          B = Motor position error (C-D)
   *          C = Heartbeat
   */

  double move    = *(double *)pasub->a;
  int32_t ctrl   = *(int32_t *)pasub->b;
  double pos     = *(double *)pasub->c;
  double rbv     = *(double *)pasub->d;
  int32_t enable = *(int32_t *)pasub->e;

  /* Heartbeat */
  (*(int32_t *)pasub->valc)++;

  if (enable == 0)
    return 1; /* Do not process if the loop is open or disabled */
  
  /* Process control loop */
  double error = pos - rbv;
  *(double *)pasub->valb = error;
  if (fabs(error) < fabs(move))
    *(double *)pasub->vala = pos + move;
    
  return 0;
}

static registryFunctionRef subSPEAR3Ref[] = {
  {"subSPEAR3TunerCtrl", (REGISTRYFUNCTION)subSPEAR3TunerCtrl}
};

static void subSPEAR3Registrar(void)
{
  registryFunctionRefAdd(subSPEAR3Ref, NELEMENTS(subSPEAR3Ref));
}
epicsExportRegistrar(subSPEAR3Registrar);
