#!../../bin/linux-x86_64/LLRFmotor

## LLRF motor IOC startup script
##
## Copyright (c) 2015 Dimtel, Inc., All Rights Reserved
##
## $Id: motor.cmd,v 1.3 2025/11/07 18:47:51 dim Exp $
## $Date: 2025/11/07 18:47:51 $
## $Author: dim $
## $Revision: 1.3 $
## $Log: motor.cmd,v $
## Revision 1.3  2025/11/07 18:47:51  dim
## Connection monitor support
##
## Revision 1.2  2021/11/04 07:01:11  dim
## Added generation of PV lists on startup
##
## Revision 1.1  2017/03/10 18:56:09  dim
## Initial import
##

< envPaths_custom

dbLoadDatabase("$(TOP)/dbd/LLRFmotor.dbd")
LLRFmotor_registerRecordDeviceDriver(pdbbase)

epicsEnvSet POST_IOCINIT "#"
epicsEnvSet POST_IOCINIT2 "#"

< motor_cfg.cmd

# Save/restore setup
epicsEnvSet(DYNAMIC_RESTORE_FILE, "${TOP}/pvs/bumpless_motor.${SYS}.pvs")

# Get it going
cd ${TOP}/iocBoot/${IOC}
date
dbl > ${logdir}/PVnames.motor
epicsEnvShow > ${logdir}/PVenv.motor
iocInit
${POST_IOCINIT}
${POST_IOCINIT2}
