## MDrive/MDrive Plus motorRecord setup
##
## Copyright (c) 2012-2017 Dimtel, Inc., All Rights Reserved
##
## $Id: mdrive.cmd,v 1.1 2017/03/10 18:56:09 dim Exp $
## $Date: 2017/03/10 18:56:09 $
## $Author: dim $
## $Revision: 1.1 $
## $Log: mdrive.cmd,v $
## Revision 1.1  2017/03/10 18:56:09  dim
## Initial import
##

# Not used by motorRecord, prevents a warning from StreamDevice
epicsEnvSet("STREAM_PROTOCOL_PATH", "$(TOP)/proto")

# Debugging aid
#dbLoadRecords("$(ASYN)/db/asynRecord.db","P=IOC:,R=Record,PORT="L0",ADDR=0,OMAX=0,IMAX=0")

# The following commands are for a local serial line
drvAsynSerialPortConfigure("L0","/dev/ttyUSB0",0,0,0)
asynSetOption("L0", -1, "baud", "9600")
asynSetOption("L0", -1, "bits", "8")
asynSetOption("L0", -1, "parity", "none")
asynSetOption("L0", -1, "stop", "1")
asynSetOption("L0", -1, "clocal", "N")
asynSetOption("L0", -1, "crtscts", "N")
asynOctetSetOutputEos("L0",-1,"\n")
asynOctetSetInputEos("L0",-1,"\r\n")

#asynSetTraceIOMask("L0",0,2)
#asynSetTraceMask("L0",0,4)

# IMS MDrive driver setup parameters: 
#     (1) maximum number of controllers in system
#     (2) motor task polling rate (min=1Hz,max=60Hz)
MDriveSetup(1, 60)

# IMS MDrive driver configuration parameters: 
#     (1) controller# being configured,
#     (2) ASYN port name
MDriveConfig(0, "L0")
#var drvMDrivedebug 3

dbLoadRecords("$(TOP)/db/motor.db", "SYS=${SYS}")
