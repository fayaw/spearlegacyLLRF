#!../../bin/linux-x86_64/LLRFhw

## LLRF4 board IOC startup script
##
## Copyright (c) 2012-2015 Dimtel, Inc., All Rights Reserved
##
## $Id: board.cmd,v 1.5 2025/11/07 18:46:38 dim Exp $
## $Date: 2025/11/07 18:46:38 $
## $Author: dim $
## $Revision: 1.5 $
## $Log: board.cmd,v $
## Revision 1.5  2025/11/07 18:46:38  dim
## S2/S3 integration, LMK01801
##
## Revision 1.4  2022/11/13 23:38:28  dim
## Baseband acquisition database added
##
## Revision 1.3  2022/08/31 18:38:40  dim
## ADC/FFT lengths moved to config
##
## Revision 1.2  2021/11/04 07:01:11  dim
## Added generation of PV lists on startup
##
## Revision 1.1  2017/03/10 18:56:09  dim
## Initial import
##

< envPaths_custom

cd ${TOP}

## Register all support components
dbLoadDatabase("dbd/LLRFhw.dbd")
LLRFhw_registerRecordDeviceDriver(pdbbase)

## Load record instances
dbLoadRecords("db/clocking.db",   "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/regs.db",       "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/ad5644_${SERIES}.db", "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/calcs.db",      "SYS=${SYS},DEV=${DEV},SN=${BOARD_SERNO}");
dbLoadRecords("db/ctrl.db",       "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/ctrl_${SERIES}.db", "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/acq.db",        "SYS=${SYS},DEV=${DEV},ADC_BLOCK=${ADC_BLOCK},ADC_LENGTH=${ADC_LENGTH},FFT_LENGTH=${FFT_LENGTH},DDC_LENGTH=${DDC_LENGTH}");
dbLoadRecords("db/acq_mask.db",   "SYS=${SYS},DEV=${DEV},ADC_LENGTH=${ADC_LENGTH},FFT_LENGTH=${FFT_LENGTH},DDC_LENGTH=${DDC_LENGTH}");
dbLoadRecords("db/rtna.db",       "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/drive.db",      "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/scalar.db",     "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/scalar_cal.db", "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/channel.db",    "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/feedback.db",   "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/rotators.db",   "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/ntc_${SERIES}.db",        "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/TEC_servo.db",  "SYS=${SYS},DEV=${DEV},TEC_DAC=${TEC_DAC}");
dbLoadRecords("db/interlock.db",  "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/interlock_ts.db", "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/ramp.db",       "SYS=${SYS},DEV=${DEV},NUMCAV=${NUMCAV}");
dbLoadRecords("db/max1270.db",    "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/bb_acq.db",    "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/interlock_slow_adc.db",  "SYS=${SYS},DEV=${DEV}");
dbLoadRecords("db/klystron_phase.db", "SYS=${SYS},DEV=${DEV}");
${LOAD_SERX} dbLoadRecords("db/serx.db", "SYS=${SYS},DEV=${DEV}")

# Save/restore setup
epicsEnvSet(DYNAMIC_RESTORE_FILE, "${TOP}/pvs/bumpless.${SYS}.${DEV}.pvs")

cd ${TOP}/iocBoot/${IOC}
date
dbl > ${logdir}/PVnames.${DEV}
epicsEnvShow > ${logdir}/PVenv.${DEV}
iocInit()
