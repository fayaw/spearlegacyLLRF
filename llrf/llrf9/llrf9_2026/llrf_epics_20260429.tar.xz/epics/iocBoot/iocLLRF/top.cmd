#!../../bin/linux-x86_64/LLRFtop

## LLRF top IOC startup script
##
## Copyright (c) 2012-2015 Dimtel, Inc., All Rights Reserved
##
## $Id: top.cmd,v 1.4 2025/11/07 18:46:59 dim Exp $
## $Date: 2025/11/07 18:46:59 $
## $Author: dim $
## $Revision: 1.4 $
## $Log: top.cmd,v $
## Revision 1.4  2025/11/07 18:46:59  dim
## New config support
##
## Revision 1.3  2021/11/03 09:22:36  dim
## State machine parameterization, tuner type handling, PV names list
##
## Revision 1.2  2019/09/18 14:59:32  dim
## Added sequencer tasks
##
## Revision 1.1  2017/03/10 18:56:09  dim
## Initial import
##

< envPaths_custom

dbLoadDatabase("$(TOP)/dbd/LLRFtop.dbd")
LLRFtop_registerRecordDeviceDriver(pdbbase)

dbLoadRecords("$(TOP)/db/scalar_sync.db", "SYS=${SYS}")
dbLoadRecords("$(TOP)/db/chan_map.db", "SYS=${SYS}")
dbLoadRecords("$(TOP)/db/tuner.db", "SYS=${SYS},TTYPE=${TUNER_TYPE},TCOUNT=${TUNER_COUNT}")
${LOAD_PROBE_BAL} dbLoadRecords("$(TOP)/db/probe_balance.db", "SYS=${SYS}")
${LOAD_VS} dbLoadRecords("$(TOP)/db/vector_sum_${NUMCAV}.db", "SYS=${SYS}")
dbLoadRecords("$(TOP)/db/interlock_summary.db", "SYS=${SYS}")
dbLoadRecords("$(TOP)/db/misc.db", "SYS=${SYS},IOC_DATE=${IOC_DATE},IOC_REV=${IOC_REV},FPGA_SUM=${FPGA_SUM},TOPO=${TOPO},CFG=${HW_CFG}")
dbLoadRecords("$(TOP)/db/hwmon.db", "SYS=${SYS}")
dbLoadRecords("$(TOP)/db/power_meter.db", "SYS=${SYS}")
dbLoadRecords("$(TOP)/db/state_machine.db", "SYS=${SYS}")
dbLoadRecords("$(TOP)/db/hvps.db", "SYS=${SYS}")

# Save/restore setup
epicsEnvSet(DYNAMIC_RESTORE_FILE, "${TOP}/pvs/bumpless_top.${SYS}.pvs")

cd ${TOP}/iocBoot/${IOC}
date
dbl > ${logdir}/PVnames.top
epicsEnvShow > ${logdir}/PVenv.top
iocInit

seq sncRFState "sys=${SYS},stn=1,nc=${NUMCAV}"
${LOAD_SEQ2} seq sncRFState "sys=${SYS},stn=2,nc=${NUMCAV}"
